# Task 8 Report — Day 7: Fourier Intuition and Wave Packets

## Fix pass (post-review)

Coordinator review found 4 must-fix issues (1 critical, 3 important) and 5
minor issues in the first draft. All applied. Final line counts:
`content/day07.md` 562 lines, `code/day07_wave_packet_builder.py` 110 lines
(both still within their respective budgets).

**1 (CRITICAL — spreading rate misattributed).** The "Dispersion and packet
spreading" Theory subsection and panel (c)'s predict-prompt both said the
spreading rate is set by how much phase velocity $v_{\mathrm{ph}}(k)=
\omega(k)/k$ varies across the band. That's wrong: the counterexample
$\omega=ck+b$ has a $k$-dependent phase velocity ($v_{\mathrm{ph}}=c+b/k$)
but a constant group velocity ($v_g=c$ for every $k$), and such a packet
translates rigidly with zero spreading — so phase-velocity variation is
neither necessary nor sufficient for spreading. Rewrote the Theory
paragraph to attribute spreading correctly to how $v_g(k)=d\omega/dk$ varies
across the band (i.e. to the curvature $d^2\omega/dk^2$), using the
sub-band/sub-packet picture and including the $\omega=ck+b$ counterexample
explicitly. Rewrote the panel-(c) predict-prompt to ask which edge of the
spreading packet ends up carrying higher- vs lower-$k$ content, given
$v_g(k)=2\alpha k$ increases with $k$ — the correct question, framed in
terms of group velocity rather than phase velocity.

**2 (IMPORTANT — Δt·Δν≳1 didn't follow from Δω·Δt≳1 by substitution).**
Reworded the time-domain bandwidth paragraph: the direct $x\to t$, $k\to
\omega$ substitution gives $\Delta\omega\,\Delta t\gtrsim1$ (same
standard-deviation convention, Gaussian equality $\tfrac12$) — that part is
an honest derivation. The engineering rule $\Delta t\,\Delta\nu\sim1$ is now
introduced explicitly as a *named, separate convention* (the
"time–bandwidth product," full-width/ordinary-frequency bookkeeping), with
an explicit note that it is *not* obtained by substituting $\omega=2\pi\nu$
into the std-dev bound (which would instead give $\gtrsim1/2\pi$). Updated
Exercise 4's Hint and Solution to name the time–bandwidth-product
convention rather than presenting it as the same inequality as $\Delta x\,
\Delta k\gtrsim1$. The $1\,$MHz answer is unchanged.

**3 (IMPORTANT — Exercise 2 solution used unlearned physics; Hint 2
enumerated answers).** Replaced the single-slit-diffraction solution
example with an in-scope one: plucking a guitar string sharply excites many
of Day 6's modes $\sin(k_nx)$ at once (bright, percussive attack), and the
higher modes damp faster than the fundamental as the note sustains and
narrows toward one tone — built entirely from today's/Day 6's material, no
optics needed. Trimmed Hint 2 from an example list ("a short pulse, a
narrow slit, a brief flash...") down to "think about what a short-duration
signal must be built from," with no examples given away.

**4 (IMPORTANT — missing third predict-prompt, sum→integral bridge).**
Added `NK` as a module-level constant in `day07_wave_packet_builder.py`
(previously the k-grid sample count, 300, was hardcoded inside
`build_packet`), added a fourth `TWEAK` docstring line ("set NK=3..."), and
replaced the day-file's panel-(a)-only third predict-prompt with the
brief's intended one: "reduce NK to 3 — does it still look like a single
localized envelope, or a coarse multi-wave beat pattern?" Verified by
actually running with NK monkey-patched to 3: panel (b) at NK=3 renders as
a many-cycle beat pattern spanning the whole window (measured $\Delta x
\approx8.6$ for *both* bandwidths, no longer tracking $\Delta k$ at all) —
confirms the prompt's claim and the pedagogical point (the continuum
picture needs enough samples to look continuous).

**5–6 (MINOR — "sharp edges" claim, missing bridge sentence).** Dropped
"a band with sharp edges" from the "somewhat larger than 1/2" list and
replaced it with an explicit note that a rectangular band's packet is a
$\sin(x)/x$ profile whose standard-deviation width is actually divergent,
so its product can be made arbitrarily large, not just "somewhat" larger.
Added the explicit bridging sentence distinguishing $\Delta x\Delta k
\gtrsim1$ (convention-agnostic rule of thumb) from $\Delta x\Delta k=
\tfrac12$ (exact Gaussian floor, standard-deviation convention only).

**7 (MINOR — unattributed $\omega=\sqrt{gk}$).** Added a half-sentence
noting it's deep water's measured dispersion relation, taken as given, not
derived here.

**8 (MINOR — three different $\Delta k$'s).** Added a parenthetical at the
Gaussian-band $\Delta k$ definition distinguishing it from the mode spacing
$\pi/L$ (sum-to-integral section) and the beat's frequency separation
$k_1-k_2$ (group-velocity section).

**9 (MINOR — width() docstring).** Added a clause noting `width()` measures
the real cosine-sum signal's intensity standard deviation, which
numerically matches the complex-envelope $\Delta x$ derived in the Theory
section only because $k_0\gg\Delta k$ here (carrier frequency far from any
near-degenerate negative-$k$ mirror image).

**Deferred by controller (not done, per instruction):** worked-examples
1–2 vs. Theory restructuring; panel (b) x-range/normalization/y-labels;
Exercise 5 hint redundancy.

### Sim re-run after fixes

```
MPLBACKEND=Agg python3 code/day07_wave_packet_builder.py
```
```
panel (b): bandwidth theorem check (dx = std dev of intensity)
  narrow band: dk=0.50  dx=1.000  dx*dk=0.500
  wide band: dk=2.00  dx=0.250  dx*dk=0.500
panel (c): v_g = 2*alpha*k0 = 1.000
```
Exit code 0. Same benign `FigureCanvasAgg is non-interactive` `UserWarning`
at `plt.show()` as before (identical to the already-accepted
`day03_oscillator_zoo.py` under headless Agg) — not a defect. Numbers
unchanged from the pre-fix run since `NK` defaults to the same value (300)
that was previously hardcoded; re-rendered and visually re-inspected all
three panels, no regressions.

## Files produced

- `physics_fundamental/content/day07.md` — 519 lines
- `physics_fundamental/code/day07_wave_packet_builder.py` — 97 lines

## Structure / anatomy check

Section order (verified via header grep): Learning objectives → Reference
material → Theory (7 subsections: modes-as-basis, square-wave computation,
Fourier-transform-as-limit, carrier/envelope, group velocity from beats,
bandwidth theorem, dispersion spreading) → Worked examples (3) → Simulation
→ Exercises → Hints → Solutions → Connection to QM. Matches the contract's
required order, including Simulation placed between Worked examples and
Exercises.

## Per-day checklist results

1. **Anatomy present, in order, correctly headed.** Pass — see header list
   above.
2. **Every named equation derived or motivated.** Pass — orthogonality
   integral derived; $b_n=4/(n\pi)$ derived by direct integration; the
   Fourier-transform-as-continuum-limit step is explicitly flagged as
   informal/non-rigorous per the brief's instruction to say so honestly;
   $v_g=d\omega/dk$ derived from the two-wave beat via sum-to-product;
   Gaussian $\Delta x\,\Delta k=\tfrac12$ derived by direct Gaussian-integral
   computation with the intensity-standard-deviation convention stated
   explicitly; dispersion-spreading argument derived from the packet's
   time-dependent phase.
3. **Exercise count/tiers/hints/solutions.** Pass — 5 exercises: Retrieval
   (1–2), Standard (3–4), Stretch (5). Every exercise has a matching
   non-spoiling hint and a full solution. Hints name the first move
   (identity to use, formula to apply) without giving final numbers.
4. **Exercises solvable from this day + prior days only.** Pass — all use
   only today's derivations (beat superposition, bandwidth theorem,
   dispersion-relation algebra) plus day 5/6 products (dispersion relation
   concept, superposition/beats, mode basis $k_n=n\pi/L$) as licensed by the
   brief. Exercise 2's solution example (single-slit diffraction) is an
   open "name an example" recall question, analogous to the text's own
   click/radar examples, not a derivation requiring outside material.
5. **Notation matches conventions.** Pass — plain $k$ (no $k_s$ collision,
   day 7 is not in the spring-constant-collision list), $\omega$, $\Delta x,
   \Delta k, \Delta t,\Delta\nu,\Delta\omega$, $\psi$, $\hbar$ only in the
   closing QM section.
6. **≥2 Misconception callouts.** Pass — 3: Gibbs-phenomenon-is-numerical-
   error (line 110), group-velocity-always-less-than-phase-velocity (line
   202), uncertainty-principle-is-quantum-weirdness (line 270), the latter
   two required verbatim by the brief.
7. **Time budget stated and plausible.** Pass — "~3.5 hours," correct for a
   day-5–15 file.
8. **Sim day requirements.** Pass — script exists, runs clean (see below),
   `## Simulation` section present with 3 predict-before-run prompts.

## Exercise verification (worked myself)

- **Ex 1 (v_g derivation):** sum-to-product on the two-wave superposition
  gives an envelope factor $\cos(\tfrac{\Delta k}2(x-ut))$ with
  $u=\Delta\omega/\Delta k\to d\omega/dk$. Confirmed.
- **Ex 2 (bandwidth theorem + new example):** stated correctly; solution
  example is single-slit diffraction (narrow slit ⇒ wide angular spread),
  distinct from the text's click/radar examples.
- **Ex 3 ($\omega=\alpha k^2$):** $v_g=2\alpha k$, $v_{\mathrm{ph}}=\alpha k$,
  ratio $v_g/v_{\mathrm{ph}}=2$. Confirmed $v_g=2v_{\mathrm{ph}}$, labeled as
  foreshadowing matter waves.
- **Ex 4 (radar pulse):** $\Delta t\,\Delta\nu\gtrsim1$ with
  $\Delta t=1\,\mu\text{s}$ gives $\Delta\nu\gtrsim1\,$MHz.
- **Ex 5 (triangle wave):** derived $b_n = 8(-1)^{(n-1)/2}/(n^2\pi^2)$, odd
  $n$, via $g'(x)=(2/L)$ times the square wave shifted by a quarter period,
  then integrated term by term. **Caught and fixed an algebra error during
  self-review**: an earlier draft had a spurious factor of $L$ survive into
  the final coefficient ($4L/(n^2\pi^2)$ instead of the correct
  $8/(n^2\pi^2)$, which must be $L$-independent since $g$ is a dimensionless
  $\pm1$ amplitude). Verified the corrected formula numerically by direct
  trapezoidal integration of an explicit triangle wave at an arbitrary
  $L=2.3$ for $n=1,3,5,7,9$ — matched the analytic prediction to 8+ digits
  in every case.
- **Square-wave coefficients** ($b_n=4/(n\pi)$, odd $n$): re-derived by
  direct integration; independently cross-checked via the Leibniz-series
  identity at $x=L/2$ (Worked Example 1), where the full series sums to
  exactly $f(L/2)=1$.
- **Gaussian $\Delta x\Delta k=\tfrac12$:** re-derived analytically (Gaussian
  Fourier-integral formula, with $\Delta x,\Delta k$ defined as standard
  deviations of the intensity profiles $|\psi|^2,|A(k)|^2$) and confirmed
  numerically by the simulation itself (see below).
- **$\omega=\sqrt{gk}$:** $v_g=v_{\mathrm{ph}}/2$ confirmed by direct
  differentiation.

## Sim run output

Environment note: numpy/matplotlib were not pre-installed on this machine
(system pip's TLS to PyPI failed due to a corporate cert/clock issue); I
built a throwaway venv in the scratchpad using Homebrew's python3.14
(`brew install numpy` bottle, then `pip install matplotlib` inside the
venv) purely to verify the script. No repo files depend on this venv.

```
MPLBACKEND=Agg python3 code/day07_wave_packet_builder.py
```
Output:
```
panel (b): bandwidth theorem check (dx = std dev of intensity)
  narrow band: dk=0.50  dx=1.000  dx*dk=0.500
  wide band: dk=2.00  dx=0.250  dx*dk=0.500
panel (c): v_g = 2*alpha*k0 = 1.000
```
Exit code 0. One `UserWarning: FigureCanvasAgg is non-interactive, and thus
cannot be shown` at the final `plt.show()` — confirmed this is the same
benign, expected warning already present in the accepted `day03_oscillator_
zoo.py` sim under the identical headless invocation, not a defect.

Rendered and visually inspected all three panels (saved to a scratch PNG):
(a) partial sums converge to the square wave with the expected narrowing
Gibbs overshoot; (b) narrow-$k$-band → visibly wider packet, wide-$k$-band →
visibly narrower packet, both reporting $\Delta x\,\Delta k \approx 0.500$,
matching the Theory section's exact Gaussian result; (c) three time
snapshots in the group-velocity-comoving window show clear, increasing
spreading with time, centered throughout (confirming the moving-window
approach isolates dispersion from translation).

## Concerns

- None outstanding. The one substantive issue found (Exercise 5's algebra
  slip) was caught during self-review and corrected in place, then verified
  independently by numerical integration.
- Exercise 2's "give a non-quantum example" is intentionally open-ended;
  the shipped solution uses single-slit diffraction, which a physics-
  fundamentals learner may or may not have independently derived, but the
  question only asks for a recognized example, not a derivation.
