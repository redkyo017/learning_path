### Task 21: README.md

**Files:**
- Create: `README.md`

**Interfaces:**
- Consumes: every file in the project (it indexes them).
- Produces: the path's front page.

- [ ] **Step 1: Draft `README.md` (~120–180 lines):**

1. Title + three-sentence pitch (who it's for, what it assumes — the linear algebra and quantum computing paths by name — where it lands: ready for a photonics-flavored QM course).
2. "Start here": read STRATEGY.md first; the daily rhythm; total budget ~62.5 h over 18 days at 3–4 h/day; note that days 16–18 may overlap the course's first weeks by design.
3. **Phase map:** the five phases with one-line descriptions and day ranges (from the spec).
4. **Day index table:** Day | Title | Hours | Simulation — 18 rows, sim column linking `code/` files where they exist, "—" elsewhere.
5. Prerequisites paragraph: calculus fluency, linear algebra (path), complex numbers; what is NOT assumed (remembering any physics).
6. Simulations: how to run (`python3 code/<file>.py`), dependency line (`pip install numpy matplotlib`).
7. Pointer to the cut list in STRATEGY.md and to `content/GLOSSARY.md`.
8. Course-overlap note: which days to prioritize if the course starts before day 18 (answer: never skip 9–11 or 16; days 12–14 compress best — one honest paragraph).

- [ ] **Step 2: Verify the index against the corpus:** every table row's title matches the actual `# Day N — <Title>` heading in the corresponding file (fix the README, not the day files); every linked sim file exists; hours match the phase budgets.

---

