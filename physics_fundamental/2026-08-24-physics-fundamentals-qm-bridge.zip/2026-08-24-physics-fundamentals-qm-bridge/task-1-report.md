# Task 1 report — STRATEGY.md

## What was written

`physics_fundamental/STRATEGY.md` (254 lines), following the brief's exact
five-part structure:

1. Title + framing paragraph naming the learner (rusty former physics
   student, fresh math from `linear_algebra/`, completed
   `quantum_computing_foundations/`, QM course starting in ~15 days,
   3–4 h/day, 18 days).
2. `## The protocol` — five subsections, each ending in a bolded
   "**Do this today:**" concrete instruction:
   - Learn backwards from the target (spine stated explicitly: mechanics →
     waves → Hamiltonians → quantum evidence → Schrödinger → Dirac).
   - Derive, don't re-read (10-minute blank-paper morning ritual on
     yesterday's boxed equations).
   - Retrieval beats review (closed-book exercises; hint-before-solution
     escalation).
   - One Fermi estimate per day (18-row table, one estimate per day,
     matched to that day's topic; used the brief's two given examples for
     day 3 and day 13 verbatim).
   - Interleave (stretch problems reach back; every 4th day — 4, 8, 12,
     16 — re-derive an equation from ≥3 days prior).
3. `## The time-wasters` — six subsections (grinding projectile/statics
   sets, passive lecture videos, rigor-before-intuition, skipping
   analytical mechanics, historical experiments as trivia, note-taking as
   transcription), each with a named specific replacement behavior, not
   just "don't do X."
4. `## What we cut and why` — five-row table: fluids, thermodynamic
   cycles, DC/AC circuits, geometric-optics instruments, rigid-body
   dynamics beyond angular momentum — each with one line tying the cut to
   why it doesn't block the QM course (pulled from the spec's stated
   downstream needs, e.g. equilibrium thermal facts feeding day 13
   blackbody radiation).
5. `## How a day works` — walked the day-file anatomy from the learner's
   side (learning goals + time budget → reference material → theory with
   inline misconception callouts → 2–3 worked examples → sim section on
   the 7 sim days → 4–6 closed-book exercises → hints → solution sketches
   → Connection-to-QM box), then stated the phase time budgets (days 1–4
   ~3 h, days 5–15 ~3.5 h, days 16–18 ~4 h, ~62.5 h total) and the
   days 16–18 course-overlap-by-design note.

## Verification (brief's Step 2, run directly)

- **All five sections present:** confirmed. Headings found at the expected
  points: `## The protocol` (line 20), `## The time-wasters` (line 135),
  `## What we cut and why` (line 196), `## How a day works` (line 211);
  title + framing paragraph precede them (lines 1–19).
- **Every protocol subsection has a concrete instruction:** confirmed —
  all 5 subsections (Learn backwards from the target, Derive don't
  re-read, Retrieval beats review, One Fermi estimate per day, Interleave)
  end in an explicit "**Do this today:**" action.
- **18 Fermi estimates listed:** confirmed by row count
  (`grep -c "^| [0-9]"` → 18), one per day 1–18, each tied to that day's
  named topic from the brief.
- **Cut-list table matches the spec's five items:** confirmed — fluids,
  thermodynamic cycles, DC/AC circuits, geometric-optics instruments,
  rigid-body dynamics beyond angular momentum all present as table rows,
  matching `docs/superpowers/specs/2026-08-24-physics-fundamentals-qm-bridge-design.md`
  verbatim.
- **No git or commit references anywhere:** confirmed —
  `grep -ni "git\|commit"` returned no matches.
- Additional self-imposed checks: no `%`/"studies show" style fake
  statistics (`grep` clean), no TBD/TODO/placeholder text (`grep` clean).

## Self-review findings

- Line count is 254, four lines over the brief's "~150–250" target. This is
  a soft/approximate range and the overage is minor (under 2%); I judged
  trimming further would cost clarity (e.g. shortening the Fermi-estimate
  table rows) for no real benefit, so left it as-is. Flagging in case the
  reviewer wants it tightened.
- The task-description's "Facts I know" anatomy list includes a "reference
  material" step between learning objectives and theory that the design
  spec's own anatomy section omits. I included it in "How a day works"
  since the task brief's context explicitly calls it out as a fact I
  should know; day files (a later task) will need to actually include a
  reference-material subsection for this to stay consistent — noting this
  as a downstream dependency, not a defect in this file.
- Verified the two Fermi estimates the brief specified verbatim (day 3:
  car-suspension resonant frequency; day 13: light-bulb photon count) are
  present in matching, non-altered form.
- Confirmed tone: second person throughout, no hype language, "top 1%" /
  "80%" framing from the task's own brief was not echoed as invented
  statistics — I avoided using percentage figures anywhere in the file.

## Concerns

None blocking. The only note is the minor line-count overage described
above, left intentionally for clarity.

## Fix report (post-review)

The task review approved STRATEGY.md contingent on four fixes. All four
applied, nothing else touched (heading, overrun advice, and Unicode
notation deferred per the controller's instruction).

1. **Interleave overpromise (was L128–129).** Old text claimed every
   day's stretch problem reaches back, which day 1 can't satisfy. New
   line:
   > **Do this today:** from day 2 on, each day's stretch problem is
   > written to reach back into an earlier day's result (or push one step
   > further) — treat that reach-back as the point of the stretch tier,
   > not an inconvenience.

2. **Day 8 Fermi estimate — ambiguous input polarization (was L105).**
   Added a clause fixing the input state so the intensity ratio is
   unambiguous. New table row:
   > | 8 | Light and polarization as a two-state system | Estimate the
   > intensity remaining after light polarized along the first
   > polarizer's axis passes through three polarizers, each rotated 30°
   > from the last. |

3. **Day 11 Fermi estimate — backwards ratio, wrong floor (was L108).**
   Rewritten so the learner computes Δx·Δp directly and expresses it as a
   multiple of ħ/2 (not ħ). New table row:
   > | 11 | Poisson brackets and the quantum preview | Estimate Δx·Δp for
   > a dust grain located and weighed to ordinary precision, and express
   > it as a multiple of ħ/2, to see how far it sits from the uncertainty
   > floor. |

4. **Day 14 Fermi estimate — missing Coulomb constant (was L111).** Added
   the Coulomb constant so the estimate works in SI, not just Gaussian
   units. New table row:
   > | 14 | Atoms, spectra, atom–light interaction | Estimate the radius
   > of a hydrogen atom from ħ, the electron mass, the electron charge,
   > and the Coulomb constant 1/(4πε₀) alone. |

Post-fix verification: file is now 255 lines (was 254; the Interleave fix
added one line). Re-ran the git/commit grep — still clean. All four new
lines confirmed present via targeted grep against the file.
