### Task 20: GLOSSARY.md

**Files:**
- Create: `content/GLOSSARY.md`

**Interfaces:**
- Consumes: all 18 day files (terms must actually appear in the corpus).
- Produces: the glossary README links to.

- [ ] **Step 1: Read `quantum_computing_foundations/content/GLOSSARY.md`** and match its entry format and tone exactly (plain-English house style).

- [ ] **Step 2: Draft `content/GLOSSARY.md`:** 60–80 terms, alphabetical, each entry = **term** — one/two plain-English sentences a non-physicist could follow, ending with "(Day N)" locating first serious use. Must include at minimum: action, amplitude, angular momentum, beats, blackbody, Boltzmann factor, Born rule, bound state, boundary condition, commutator (as previewed), conservative force, dispersion relation, eigenstate, equipartition, evanescent wave, Fourier series, group velocity, Hamiltonian, harmonic oscillator, interference, Jones vector, Lagrangian, Mach–Zehnder interferometer, Malus's law, matter wave, mode, normal mode, normalization, partition function, phase space, phase velocity, photon, Planck's constant, Poisson bracket, polarization, population inversion, potential well, resonance, separatrix, standing wave, stationary state, stimulated emission, superposition, tunneling, turning point, two-level system, uncertainty principle, wave packet, wavefunction, work function, zero-point energy.

- [ ] **Step 3: Verify checklist↔corpus reconciliation** (the lesson from the glossaries project): for every entry, `grep -il` the term across `content/day*.md` and confirm at least one hit AND that the cited day is the right one; remove or re-day any entry that fails; spot-add glaring omissions found while grepping.

---

