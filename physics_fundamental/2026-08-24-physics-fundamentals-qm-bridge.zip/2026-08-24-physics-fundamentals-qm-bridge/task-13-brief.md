### Task 13: Day 12 — Minimal Thermal Physics

**Files:**
- Create: `content/day12.md`

**Interfaces:**
- Consumes: day 3's oscillator (equipartition applied to it), day 10's phase-space teaser.
- Produces: Boltzmann factor $e^{-E/k_BT}$; partition-function average $\langle E\rangle = \sum E_i e^{-E_i/k_BT}/\sum e^{-E_i/k_BT}$; equipartition ($\tfrac12 k_BT$ per quadratic term). Day 13's Planck derivation consumes all three directly.

- [ ] **Step 1: Draft `content/day12.md` (~3.5h day) with this content brief:**

*Learning objectives:* explain temperature as a statement about average energy; motivate and use the Boltzmann factor; compute thermal averages from a partition function for discrete levels; state and apply equipartition; predict where equipartition must fail.

*Theory beats:*
1. Framing: "this day exists to make day 13's blackbody derivation honest — it is the minimum thermal physics a QM course assumes, no more."
2. Temperature operationally; $k_BT$ as the thermal energy scale; numbers ($k_BT \approx 1/40$ eV at room temperature — an anchor value used repeatedly in days 13–15).
3. Boltzmann factor motivated by the small-system-plus-reservoir argument (lightweight version: reservoir entropy/state-counting told in words and one exponential step — flag the full derivation as stat-mech-course material); result: $P(E_i)\propto e^{-E_i/k_BT}$.
4. Partition function $Z = \sum_i e^{-E_i/k_BT}$; averages $\langle E\rangle = \sum_i E_i P(E_i)$; the two-level system fully worked as the running example (populations vs. $T$, saturation at high $T$, freeze-out at low $T$).
5. Equipartition: each quadratic degree of freedom carries $\langle E\rangle = \tfrac12 k_BT$ — derived for one quadratic term via the Gaussian integral (state the integral result; don't develop integral tables); classical oscillator gets $k_BT$ total (two quadratic terms).
6. Where it must fail: equipartition is temperature-independent per mode — if a system has infinitely many modes, classical physics predicts infinite energy. One paragraph, deliberately ominous: "hold this thought for exactly one day."
7. *Consolidation survey* (labeled): entropy in two paragraphs (state-counting flavor); the laws of thermodynamics in four sentences.
- Misconceptions: "temperature measures total energy" (average per mode, not total; a spark vs. a bathtub); "at temperature T every particle has energy $k_BT$" (it's a distribution — some far above, most below).

*Worked examples:* (1) two-level system, gap $\Delta$: populations at $k_BT = 0.1\Delta, \Delta, 10\Delta$; (2) classical oscillator average energy via equipartition = $k_BT$; (3) RMS speed of a nitrogen molecule at room temperature.

*Exercises:* Retrieval: (1) write the Boltzmann factor and compute the ratio of populations for a given gap and temperature; (2) state equipartition and count quadratic terms for a 3D ideal-gas atom. Standard: (3) three-level system: compute $Z$ and $\langle E\rangle$ at one temperature; (4) diatomic molecule heat-capacity puzzle: count modes (translation, rotation, vibration), note the experimental "freeze-out" and flag it as quantum. Stretch: (5) for the two-level system derive $\langle E\rangle(T)$ in closed form and show it saturates at $\Delta/2$ as $T\to\infty$; explain in one paragraph why a classical continuum of levels would never saturate (this is the exact mathematical move Planck makes tomorrow).

*Connection to QM:* Planck's blackbody fix (tomorrow) is nothing but today's discrete-level average applied to light; freeze-out (exercises 4–5) is quantization visible in 1900-era data; and the two-level thermal system returns in your course as the maximally mixed qubit state.

- [ ] **Step 2: Run the per-day verification checklist**; fix failures.

---

