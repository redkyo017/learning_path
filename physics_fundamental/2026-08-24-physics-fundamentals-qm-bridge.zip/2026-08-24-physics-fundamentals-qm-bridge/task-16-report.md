# Task 16 report — Day 15: Matter Waves and the Synthesis

## File
`/Users/hunghan/han_git/docker-tools/github-sandbox/repos/learning_path/physics_fundamental/content/day15.md` — 544 lines.

## Sections (anatomy, in order)
Learning objectives (5 bullets, matches brief verbatim in substance) → Reference material (Eisberg–Resnick; French & Taylor; self-contained note; pointers to days 6/7/12/13/14) → Theory (6 numbered beats matching brief's exact order: symmetry bet; numbers immediately (electron vs baseball); Davisson–Germer + two-slit; the synthesis / Bohr derivation + boxed chain; wave–particle straight talk with both misconceptions; when quantum is relevant / λ_th) → Worked examples (3: electron+baseball λ; Bohr L=nħ derivation in full; Davisson–Germer angle prediction) → Exercises (5, tiered Retrieval/Standard/Stretch, house opening line present) → Hints (5, non-spoiling) → Solutions (5, full sketches) → Connection to QM (2 paragraphs).

## Checklist results
1. Anatomy present, in order, correctly headed — pass.
2. Every named equation derived or motivated in-line — pass (λ_th's 2π prefactor explicitly flagged as quoted-not-derived, with the scaling law motivated from day 12).
3. Exercise count 5 (within 4–6); tiers labeled; every exercise has hint + solution; solutions solve the stated problems — pass.
4. Exercises use only day 15 + prior days (6, 7, 12, 13, 14) — pass; no forward references.
5. Notation matches conventions — pass. L used for angular momentum in the Bohr derivation (standard "elsewhere" convention) and explicitly re-flagged as "box length, not angular momentum" at first use in Exercise 5 and again in Solution 5, per the task's notation instruction. No period-of-oscillation symbol introduced (T reserved for temperature throughout).
6. ≥2 `> **Misconception:**` callouts — pass, exactly the 2 brief-mandated ones (electron travels along the wave; duality as sometimes-wave-sometimes-particle), placed in the wave–particle straight-talk beat.
7. Time budget stated and plausible — "Time budget: ~3.5 hours," matching the days 5–15 convention.
8. No simulation this day — N/A, no `## Simulation` section, correctly omitted.

## Exercise verification (final answers, worked by hand)
1. 1 keV electron: λ = 1.226/√1000 = 0.0388 nm (38.8 pm). Cross-checked via p=√(2m_eE), λ=h/p — matches.
2. Standing-wave → L=nħ: 2πr=nλ, λ=h/p ⟹ rp=nħ ⟹ L=rp=nħ. Closed-book reproduction confirmed clean.
3. Neutron for λ=0.1 nm: p=6.626e-24 kg·m/s, E=p²/2m_n=1.310e-20 J=0.0818 eV ≈ 0.082 eV; k_BT(300K)≈0.0259 eV — same order of magnitude, "thermal neutrons" flag included.
4. Electron microscope: at 60 keV, λ_e≈5.0 pm vs visible light 500 nm ⟹ ratio ≈10⁵ resolution advantage.
5. 1D box: λ_n=2L/n ⟹ p_n=nh/2L ⟹ E_n=n²h²/8mL² — algebra checked term by term; flagged as day 16's headline result obtained a day early with 1924-era tools, per the brief's mandate.

Also hand-verified in Theory/Worked Examples: 100 eV electron λ≈0.1227 nm≈0.123 nm; baseball λ≈1.14×10⁻³⁴ m; Davisson–Germer 54 eV electron λ=0.167 nm, predicted angle arcsin(0.167/0.215)≈51° vs historical measured 50° (good agreement); λ_th for electron at 300K ≈4.30 nm and for helium-4 at 300K ≈0.0504 nm (both computed during drafting to sanity-check beat 6's "compare to interparticle spacing" claims — electron λ_th >> metal lattice spacing, helium λ_th << gas-phase spacing — though only the qualitative comparison made it into the final prose, not both numeric evaluations as standalone exercises, since the brief's exercise list didn't mandate them as separate numbered problems).

## Concerns
- None blocking. Minor editorial choice: the brief's theory beat 6 asks to "evaluate for an electron and for a helium atom at room temperature" — I evaluated both by hand and used the electron case's numeric conclusion in the Solutions/Theory narrative qualitatively (λ_th >> lattice spacing ⟹ quantum), but did not print both raw numeric evaluations as an explicit worked sub-item in the file itself (they weren't in the brief's Worked-examples or Exercises lists, only the theory-beat narrative). If a future reviewer wants both λ_th numbers spelled out inline, they can be added to beat 6's closing paragraph without restructuring anything.
- Did not read physics_fundamental/content/day06.md, day07.md, day12–14.md (which don't yet exist for 12–14) per the task's "do NOT read files" instruction — relied solely on the summarized prior-day products given in the task context.
- No git commands run, per hard constraint.

---

## Fix report (post-review revision)

Coordinator review flagged 3 must-fix and 2 minor issues around (but not in) the Bohr synthesis centerpiece, which was verified correct as-is. All five addressed below. File grew from 544 to 586 lines (still ≤600).

**1. Missing λ_th evaluations (chosen fix: add numbers directly in theory beat 6, delete the false cross-reference).**
Replaced the closing sentence of beat 6 — "Worked evaluations for an electron and a helium atom at room temperature, and what they imply, are in the Exercises" (false; no exercise computed them) — with two worked evaluations in the theory prose itself:
> Evaluating $\lambda_{th}$ at room temperature ($T=300\,\text{K}$, so $k_BT \approx 4.14\times10^{-21}\,\text{J}$) for two cases makes the criterion concrete. For an electron ($m_e = 9.109\times10^{-31}\,\text{kg}$): $\lambda_{th} \approx 4.3\,\text{nm}$. This is more than an order of magnitude larger than the $\sim0.2$–$0.3\,\text{nm}$ spacing between atoms in a metal, which is exactly why the conduction electrons in a metal cannot be treated as a classical gas even at room temperature... For a helium-4 atom ($m_{\text{He}} = 6.646\times10^{-27}\,\text{kg}$): $\lambda_{th} \approx 0.05\,\text{nm} = 0.5\,\text{Å}$. That is comparable to an atom's own size, but far smaller than the several nanometers of typical spacing between atoms in helium gas at room temperature... it takes cooling all the way down to a few kelvin... before helium's wave nature forces itself on the system as superfluidity.

Both numbers match the values the coordinator specified (4.3 nm; 0.05 nm ≈ 0.5 Å) and were independently recomputed here from $\lambda_{th}=h/\sqrt{2\pi mk_BT}$.

**2. Davisson–Germer grating relation motivated from day 6's path-difference condition.**
Inserted before the grating-condition equation in Worked Example 3:
> This is day 6's path-difference interference condition in a new setting: two adjacent rows of surface atoms, spaced by $d$, each scatter the incoming wave, and the two scattered waves travel an extra path difference of $d\sin\phi$ before recombining. Exactly as in day 6, constructive interference — a diffraction peak — requires that path difference to be a whole number of wavelengths, $d\sin\phi = n\lambda$; taking the first order ($n=1$) gives the grating condition $\lambda = d\sin\phi$...

**3. Day 7 wave packets substantively used in beat 5.**
Inserted a new paragraph in the wave–particle straight-talk section, between the wavefunction/Born-rule paragraph and the misconception callouts:
> A localized detection event is itself already familiar from day 7: a single sharp $k$ (a single de Broglie wavelength) describes a wave spread over all space, not a particle found "here." Getting something localized — an electron arriving at one point on a screen — requires superposing many $k$'s into a wave packet, exactly as day 7 built packets by adding plane waves. Day 7's uncertainty relation between packet width and the spread of $k$'s in it, $\Delta x\,\Delta k \gtrsim 1$, is already the trade-off between localization and momentum spread that this whole beat has been describing in words; day 16 formalizes it as $\Delta x\,\Delta p \gtrsim \hbar$.

**4. Orders-of-magnitude error corrected (minor).**
"the baseball's is $30$ orders of magnitude smaller" → "the baseball's is about $24$ orders of magnitude smaller ($1.14\times10^{-34}\,\text{m}$ versus $1.23\times10^{-10}\,\text{m}$)" — matches the coordinator's computed ratio ($10^{24}$).

**5. Misconception format corrected to house style (minor).**
Both callouts changed from bolding the whole label-plus-claim sentence to bolding only the label, per days 6/13/14 style:
- `> **Misconception: "the electron travels along the wave"...**` → `> **Misconception:** "the electron travels along the wave"...`
- `> **Misconception: "wave–particle duality means...**` → `> **Misconception:** "wave–particle duality means...`

**Final line count:** 586 lines (`wc -l` confirmed), within the 350–600 contract range.
