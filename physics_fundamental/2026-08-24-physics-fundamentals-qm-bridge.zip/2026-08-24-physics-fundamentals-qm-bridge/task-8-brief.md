### Task 8: Day 7 — Fourier Intuition and Wave Packets + sim

**Files:**
- Create: `content/day07.md`
- Create: `code/day07_wave_packet_builder.py`

**Interfaces:**
- Consumes: day 5's dispersion relation; day 6's superposition.
- Produces: group velocity $v_g = d\omega/dk$; the bandwidth theorem $\Delta x\,\Delta k \gtrsim 1$ with the Gaussian equality case $\Delta x\,\Delta k = \tfrac12$. Day 17 converts these verbatim into $\Delta x\,\Delta p \ge \hbar/2$.

- [ ] **Step 1: Draft `content/day07.md` (~3.5h day) with this content brief:**

*Learning objectives:* decompose a periodic shape into harmonics (concept + one real computation); explain the Fourier transform as the continuum limit; build a wave packet from a band of $k$'s; derive $v_g = d\omega/dk$; state and use $\Delta x\,\Delta k\gtrsim1$.

*Theory beats:*
1. Fourier series conceptually: the string's modes (day 6) are a basis; any shape on the string = sum of modes. Explicit connection to the learner's linear algebra: "this is expansion in an orthogonal basis, with $\int \sin(k_nx)\sin(k_mx)dx$ as the inner product."
2. One honest computation: square-wave Fourier coefficients ($b_n = 4/n\pi$ for odd $n$), showing the $1/n$ falloff and Gibbs wiggle in words.
3. Fourier transform as continuum limit: sum over discrete $k_n$ → integral over $k$; $\psi(x) = \int A(k)e^{ikx}dk$ at the intuition level (no rigor, no convergence theory — say so).
4. Wave packets: narrow Gaussian band $A(k)$ around $k_0$ → localized packet; carrier vs. envelope.
5. Group velocity derived from the two-wave beat (day 6's beats revisited): envelope moves at $\Delta\omega/\Delta k \to d\omega/dk$; contrast $v_g$ vs $v_{\mathrm{ph}}$ for $\omega=\sqrt{gk}$ ($v_g = v_{\mathrm{ph}}/2$).
6. The bandwidth theorem: narrow in $x$ ⇔ wide in $k$; Gaussian case computed ($\Delta x\,\Delta k = 1/2$); everyday instances (short sound click has no pitch; short radar pulse has broad spectrum). **Box:** "this is a fact about waves, not about quantum mechanics."
7. Dispersion spreading: if $\omega(k)$ is nonlinear, different $k$'s travel at different speeds → packets spread.
- Misconceptions: "the uncertainty principle is quantum weirdness" (it's the boxed classical wave fact, plus $p=\hbar k$); "group velocity is always less than phase velocity" (depends on the dispersion relation).

*Worked examples:* (1) square-wave coefficients computed; (2) $\omega=\sqrt{gk}$: compute $v_g/v_{\mathrm{ph}}$; (3) Gaussian packet: given $\Delta k$, compute $\Delta x$ and interpret.

*Simulation section:* run `python3 code/day07_wave_packet_builder.py`; predict-prompts: "double the k-bandwidth — does the packet get wider or narrower?", "add dispersion — which part of the packet outruns which?", "reduce to 3 modes — what does the 'packet' look like now?"

*Exercises:* Retrieval: (1) derive $v_g = d\omega/dk$ from two superposed nearby-frequency waves; (2) state the bandwidth theorem and give one non-quantum example not in the text. Standard: (3) for $\omega = \alpha k^2$ (foreshadowing matter waves — label it as such), compute $v_g$ and show $v_g = 2v_{\mathrm{ph}}$; (4) a 1 μs radar pulse: estimate its frequency bandwidth. Stretch: (5) triangle-wave Fourier coefficients; compare falloff rate with the square wave and connect smoothness ↔ high-$k$ content.

*Connection to QM:* multiply today by $\hbar$: $p = \hbar k$, $E=\hbar\omega$, and $\Delta x\,\Delta k \gtrsim 1$ becomes Heisenberg's $\Delta x\,\Delta p \gtrsim \hbar$; a particle IS a wave packet, its velocity is $v_g$, and exercise (3)'s dispersion relation is literally the free Schrödinger equation's.

- [ ] **Step 2: Write `code/day07_wave_packet_builder.py`** per Global Constraints. Panels: (a) partial sums of the square-wave series (N = 1, 3, 9, 33 terms overlaid); (b) wave packet built as $\sum_n A(k_n)\cos(k_n x)$ with Gaussian weights, shown for two bandwidths (narrow → wide packet, wide → narrow packet), with $\Delta x \cdot \Delta k$ annotated; (c) packet snapshots at 3 times with quadratic dispersion $\omega = \alpha k^2$ showing spreading (evaluate the sum at each $t$ with $\cos(k_nx - \omega_nt)$ — pure numpy, no integrator).

- [ ] **Step 3: Run `python3 code/day07_wave_packet_builder.py`** — expect clean run; wider $k$-band gives visibly narrower packet; dispersion panel shows spreading.

- [ ] **Step 4: Run the per-day verification checklist**; fix failures.

---

