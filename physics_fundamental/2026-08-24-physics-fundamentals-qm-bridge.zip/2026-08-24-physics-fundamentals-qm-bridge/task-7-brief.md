### Task 7: Day 6 — Superposition, Standing Waves, Interferometers + sim

**Files:**
- Create: `content/day06.md`
- Create: `code/day06_interference_standing_waves.py`

**Interfaces:**
- Consumes: day 5's sinusoidal-wave conventions.
- Produces: path-difference interference condition; standing-wave quantization $f_n = nv/2L$; Mach–Zehnder output laws $I_1 \propto \cos^2(\phi/2)$, $I_2 \propto \sin^2(\phi/2)$. Days 15, 16, 18 quote these directly (day 18 re-reads the MZ as a qubit circuit).

- [ ] **Step 1: Draft `content/day06.md` (~3.5h day) with this content brief:**

*Learning objectives:* apply superposition to compute interference from path difference; derive beats; derive standing waves and the discrete mode spectrum from boundary conditions; compute both output intensities of a Mach–Zehnder interferometer as a function of arm phase.

*Theory beats:*
1. Linearity of the wave equation ⇒ superposition; this is a *theorem about the equation*, not an extra assumption.
2. Two-source interference: path difference → phase difference $\delta = k\Delta L$; constructive/destructive conditions; two-slit maxima positions derived; phasor-addition picture.
3. Beats: $\cos\omega_1 t + \cos\omega_2 t$ → envelope at $(\omega_1-\omega_2)/2$; beat frequency.
4. Standing waves: counter-propagating equal waves → $y = 2A\sin(kx)\cos(\omega t)$; nodes/antinodes; fixed-end boundary conditions → $k_n = n\pi/L$, $f_n = nv/2L$. **Box and flag:** "boundary conditions turn a continuum of waves into a discrete list of modes — remember this sentence; it is the entire origin story of quantization."
5. Interferometers: Michelson layout and output vs. mirror displacement; then Mach–Zehnder carefully — beam splitter conventions (50/50, with the $\pi$ phase shift on one reflection stated as the convention that keeps energy conserved), two paths, recombination; derive $I_1 \propto \cos^2(\phi/2)$ and $I_2\propto\sin^2(\phi/2)$; note the outputs are complementary (energy conservation check).
- Misconceptions: "destructive interference destroys energy" (it redistributes it — the other MZ port brightens); "standing waves transport energy" (they don't; they're trapped modes).

*Worked examples:* (1) two-slit: given $\lambda, d, L$ compute fringe spacing; (2) string fixed at both ends: full harmonic series for given $v, L$, sketch first three modes; (3) MZ with a glass sample (thickness $t$, index $n$) in one arm: compute $\phi$ and both output intensities.

*Simulation section:* run `python3 code/day06_interference_standing_waves.py`; predict-prompts: "move the sources closer together — do the fringes get wider or narrower?", "detune the beat frequencies further apart — what happens to the envelope?", "in the MZ panel, find the phase where BOTH ports are equal — what fraction is each?"

*Exercises:* Retrieval: (1) derive the standing-wave form from two counter-propagating waves (sum-to-product identity); (2) derive $f_n = nv/2L$ from fixed-end boundary conditions. Standard: (3) beats: two tuning forks numbers → beat frequency, and which is sharper given one is loaded; (4) pipe open at one end: derive the odd-harmonics-only spectrum (different boundary condition — same method). Stretch: (5) MZ interferometry: derive both output intensities from the beam-splitter convention step by step, verify $I_1 + I_2 = I_0$ at every phase, and answer "where did the light go at $\phi=\pi$?"

*Connection to QM:* your course will send *single photons* through the Mach–Zehnder and get the same $\cos^2$/$\sin^2$ laws as *probabilities* — today's amplitudes become probability amplitudes; and the boxed boundary-condition sentence is exactly how the particle-in-a-box (day 16) gets discrete energies.

- [ ] **Step 2: Write `code/day06_interference_standing_waves.py`** per Global Constraints. Three panels, all analytic (no integration): (a) two-source interference intensity pattern on a screen vs. position for adjustable source separation; (b) beats: $y(t)$ sum of two nearby frequencies with envelope overlaid; (c) Mach–Zehnder: $I_1, I_2$ vs. $\phi \in [0, 4\pi]$ showing complementarity, plus their sum as a flat line.

- [ ] **Step 3: Run `python3 code/day06_interference_standing_waves.py`** — expect clean run, three panels, MZ curves summing to a constant.

- [ ] **Step 4: Run the per-day verification checklist**; fix failures.

---

