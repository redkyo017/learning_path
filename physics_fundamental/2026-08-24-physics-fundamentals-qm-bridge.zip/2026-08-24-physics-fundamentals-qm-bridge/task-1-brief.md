### Task 1: STRATEGY.md

**Files:**
- Create: `STRATEGY.md`

**Interfaces:**
- Produces: section names `## The protocol`, `## The time-wasters`, `## What we cut and why` — day files and README refer to STRATEGY.md generically (no anchor links), so only the file's existence and these three sections are load-bearing.

- [ ] **Step 1: Draft STRATEGY.md (~150–250 lines) with this exact structure:**

1. Title + framing paragraph: who this is for (rusty former physics student, strong recent math from the linear algebra path, completed quantum computing foundations path, QM course in a quantum-info master's starting in ~15 days, 3–4 h/day).
2. `## The protocol` — the top-1% re-learner method, one subsection each, each with a concrete "do this today" instruction:
   - **Learn backwards from the target.** The path is the dependency graph of a QM course, not the traditional curriculum. State the spine explicitly (mechanics → waves → Hamiltonians → quantum evidence → Schrödinger → Dirac).
   - **Derive, don't re-read.** Every named equation: close the file next morning and re-derive it on paper. Include the concrete morning ritual (10 min, yesterday's boxed equations, blank paper).
   - **Retrieval beats review.** Do the exercises closed-book; the Hints→Solutions escalation exists so you never peek at a solution before attempting a hint.
   - **One Fermi estimate per day.** Give the list of 18 suggested estimates, one per day, matched to that day's topic (e.g., day 3: "estimate the resonant frequency of a car on its suspension"; day 13: "estimate how many visible photons a light bulb emits per second").
   - **Interleave.** Each day's Stretch problem deliberately reaches back; additionally, every 4th day re-derive one equation from ≥3 days ago.
3. `## The time-wasters` — the 80% traps, one short subsection each with the *specific replacement behavior*: grinding projectile/statics problem sets; passive lecture videos; chasing mathematical rigor before physical intuition; skipping analytical mechanics; treating the historical experiments (blackbody, photoelectric) as trivia rather than evidence; note-taking as transcription.
4. `## What we cut and why` — table of the cut list from the spec (fluids, thermodynamic cycles, DC/AC circuits, geometric-optics instruments, rigid-body dynamics beyond angular momentum), each with one line on why it doesn't block a QM course.
5. `## How a day works` — walk through the day-file anatomy from the learner's side: objectives → theory with derivations → worked examples → sim (some days) → closed-book exercises → hints → solutions → QM connection box; state the 3/3.5/4-hour budgets by phase.

- [ ] **Step 2: Verify:** all five sections present; every protocol subsection has a concrete instruction; 18 Fermi estimates listed; cut-list table matches the spec's five items; no git or commit references anywhere.

---

