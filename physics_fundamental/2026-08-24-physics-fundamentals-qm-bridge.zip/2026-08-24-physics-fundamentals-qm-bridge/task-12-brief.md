### Task 12: Day 11 — Poisson Brackets and the Quantum Preview

**Files:**
- Create: `content/day11.md`

**Interfaces:**
- Consumes: day 10's $H$ and phase-space functions.
- Produces: $\{f,g\}$ definition; $\dot f = \{f,H\}$; canonical bracket $\{q,p\}=1$; the quantization dictionary table $\{,\}\to\frac{1}{i\hbar}[,]$. Day 18's Rosetta Stone reprints this table.

- [ ] **Step 1: Draft `content/day11.md` (~3.5h day) with this content brief:**

*Learning objectives:* compute Poisson brackets; show $\dot f = \{f,H\}$; verify $\{q,p\}=1$; use vanishing brackets to identify conserved quantities; state the canonical-quantization dictionary and why commutators are then *natural*.

Written-to-be-re-read note: open the file with an italic line — "*Read this day twice: once now, once after week 2 of your course, when commutators have appeared. It is designed to be better the second time.*"

*Theory beats:*
1. Definition $\{f,g\} = \frac{\partial f}{\partial q}\frac{\partial g}{\partial p} - \frac{\partial f}{\partial p}\frac{\partial g}{\partial q}$; algebraic properties (antisymmetry, linearity, product rule) verified quickly.
2. The master equation: $\frac{df}{dt} = \{f,H\}$ derived in four lines from Hamilton's equations. "One bracket to rule all time evolution."
3. Conservation: $f$ conserved ⇔ $\{f,H\}=0$; redo day 4's results in this language (momentum conserved when $H$ is translation-invariant, etc.).
4. Canonical brackets: $\{q,p\}=1$, $\{q,q\}=\{p,p\}=0$ — "the multiplication table of mechanics."
5. The dictionary, presented as a two-column table (classical | quantum): $f(q,p)$ | operator $\hat f$; $\{f,g\}$ | $\frac{1}{i\hbar}[\hat f,\hat g]$; $\{q,p\}=1$ | $[\hat q,\hat p]=i\hbar$; $\dot f=\{f,H\}$ | Heisenberg equation $\frac{d\hat f}{dt} = \frac{1}{i\hbar}[\hat f,\hat H]$; conserved ⇔ bracket with $H$ vanishes | conserved ⇔ commutes with $\hat H$. Frame honestly: this is a *pattern that quantization follows*, not a derivation of QM.
6. Why commutators are then natural, not weird: QM keeps the entire algebraic structure of mechanics and changes only what the bracket *is*. The non-commutativity $[\hat q,\hat p]\ne0$ is the mathematical seat of the uncertainty principle (day 17 closes this loop).
7. Two-level truncation idea in one paragraph: keep only two energy states of any system → every observable becomes a $2\times2$ matrix → the qubit; this is why your quantum computing path's $2\times2$ matrices describe real atoms (day 14, day 18).
- Misconceptions: "Poisson brackets are just notation" (they're coordinate-independent structure — the *same* bracket in any canonical coordinates); "QM replaces classical mechanics' equations" (it replaces the bracket and keeps the equations' shape).

*Worked examples:* (1) verify $\{q,p\}=1$ and compute $\{q,H\}, \{p,H\}$ for the oscillator, recovering Hamilton's equations; (2) central force in 2D: show $\{L_z, H\}=0$ by direct computation; (3) oscillator time evolution of $q$ via iterated brackets → recover $\cos\omega_0 t$ series (first three terms, then recognize the series).

*Exercises:* Retrieval: (1) derive $\dot f = \{f,H\}$ from Hamilton's equations, closed book; (2) verify antisymmetry and the product rule from the definition. Standard: (3) compute $\{L_z, x\}, \{L_z, y\}, \{L_z, p_x\}$ and interpret (rotations rotate things); (4) free particle: show $p$ and $H$ conserved, and $x - pt/m$ conserved too — interpret it. Stretch: (5) take the quantization dictionary at its word: from $[\hat q,\hat p]=i\hbar$, compute $[\hat q,\hat p^2]$ using only the algebra ($[A,BC]=[A,B]C+B[A,C]$), and check it matches $i\hbar\,\{q,p^2\}_{PB}$ computed classically.

*Connection to QM:* this day IS the connection; close instead with a half-page "what to re-derive after course week 2" list: the master equation, the dictionary table, exercise 5.

- [ ] **Step 2: Run the per-day verification checklist**; fix failures (including the re-read italic line).

---

