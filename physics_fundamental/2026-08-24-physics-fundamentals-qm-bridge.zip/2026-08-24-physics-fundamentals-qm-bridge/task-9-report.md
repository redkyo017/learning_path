# Task 9 Report — Day 8: Light and Polarization as a Two-State System

## File

`physics_fundamental/content/day08.md` — 554 lines.

## Structure delivered

Learning objectives (5 bullets, time budget ~3.5h) → Reference material
(Griffiths *Introduction to Electrodynamics* for the Maxwell/wave-equation
beats, Hecht *Optics* for polarization/Jones-calculus/wave-plate beats,
self-contained note, builds-on Day 5/6 note) → Theory, in order per the
brief:
1. Fields as physical objects (Lorentz force law).
2. The four Maxwell equations, one sentence each (source + what it
   forbids), no PDE manipulation; wave equation and $c=1/\sqrt{\mu_0
   \varepsilon_0}$ quoted and numerically evaluated to $\approx3.00\times
   10^8$ m/s.
3. EM wave anatomy ($\vec E\perp\vec B\perp\vec k$, in phase, $|E|=c|B|$,
   $I\propto E_0^2$).
4. Polarization as $\vec E$ direction; linear, then circular built from
   two linears $90°$ out of phase (misconception callout here).
5. Jones vectors — all four required states plus $|L\rangle$ for
   Exercise 2, polarizer-as-projection (misconception callout here),
   rotation, the "same arena as the qubit" punchline sentence (near-
   verbatim from the brief).
6. Malus's law derived as projection-then-square.
7. Wave plates — birefringence, QWP Jones matrix, one-line diagonal→
   circular computation.
8. Two labeled consolidation surveys (DC circuits; geometric optics,
   with the brief's stated reason — QM needs wave optics not ray optics)
   → Worked examples (3) → Exercises (5, tiered) → Hints (5) →
   Solutions (5) → Connection to QM.

No `## Simulation` section: task-9-brief.md has no `Create: code/...`
line (unlike tasks 4/7/8/11/14/17/18), confirming Day 8 is not one of
the 7 sim days. An earlier draft mistakenly added a "no simulation"
placeholder section; removed before finalizing, matching the precedent
in tasks 2/3/5 (section omitted entirely, not stubbed).

## Checklist results

1. Anatomy sections present, correctly ordered — pass.
2. Every named equation derived or motivated: Lorentz force (definition),
   Maxwell's equations (one-sentence, explicitly not derived per brief),
   $c$ (cited result, numerically evaluated), wave anatomy (cited
   consequence, flagged as such), circular polarization (fully derived
   via superposition), Jones states (definitions + normalization
   checked), polarizer projection (physically motivated), Malus's law
   (fully derived), QWP matrix (motivated from birefringence + $90°$
   phase = factor $i$). Survey-section equations (Ohm's law, Kirchhoff,
   thin-lens) are stated at survey depth only, matching the day04.md
   precedent for "Survey — paragraph depth, no derivations" sections —
   pass.
3. 5 exercises, tiers labeled (Retrieval 2, Standard 2, Stretch 1); every
   exercise has a matching hint and full solution; hints name the first
   move without giving the answer — pass.
4. Exercises use only Day 8 content (plus complex-vector-space background
   from the QM path, as licensed by the task context) — no forward
   references — pass.
5. Notation matches conventions: Jones vectors as column vectors with
   $|H\rangle,|V\rangle$ labels; degree symbol inside math mode matches
   day02/day03 precedent — pass.
6. 2 `> **Misconception:**` callouts present (sieve vs. projection;
   mixture vs. coherent superposition) — pass.
7. Time budget "~3.5 hours" stated, plausible for a photonics-heavy day —
   pass.
8. Not a sim day — N/A.

## Exercise verification (worked myself)

- **Three-polarizer puzzle (Worked Example 1):** unpolarized $I_0$ →
  $\langle\cos^2\theta\rangle=\tfrac12$ through first polarizer →
  $I_0/2$; ×$\cos^2(45°)=\tfrac12$ twice more → $I_0/4$ → $I_0/8$.
  Matches brief exactly. Without the middle polarizer: $\cos^2(90°)=0$,
  fully blocked.
- **Exercise 3 (N-polarizer cascade), $N\to\infty$ limit:** fraction
  $=[\cos^2(90°/N)]^N$. Numerically verified $N=4\to0.531$,
  $N=10\to0.781$, $N=100\to0.976$, $N=1000\to0.9975$,
  $N=10^5\to0.99998$ — confirmed analytically via
  $\cos^2x\approx1-x^2$, $(1-x^2)^N\approx e^{-Nx^2}\to1$ as
  $N\to\infty$ with $x=\pi/(2N)$. Matches the brief's "limit → 1."
- **Quarter-wave plate (Worked Example 2):** $M=\text{diag}(1,i)$ on
  $|D\rangle=\tfrac{1}{\sqrt2}(1,1)^T$ gives $\tfrac{1}{\sqrt2}(1,i)^T=
  |R\rangle$ — normalized, lands exactly on circular. Confirmed by hand
  and independently by direct matrix multiplication.
- **Exercise 2 (circular normalization/orthogonality):** computed
  $\langle R|R\rangle=\tfrac12(1+(-i)(i))=\tfrac12(1+1)=1$ (normalized);
  $\langle R|L\rangle=\tfrac12(1+(-i)(-i))=\tfrac12(1+i^2)=\tfrac12(1-1)
  =0$ (orthogonal). Both confirmed.
- **Exercise 4 (diagonal decomposition):** $|D\rangle=\tfrac{1}{\sqrt2}
  |H\rangle+\tfrac{1}{\sqrt2}|V\rangle$ (even split); $|D\rangle=1\cdot
  |{+}45°\rangle+0\cdot|{-}45°\rangle$ (trivial, since $|D\rangle$ *is*
  $|{+}45°\rangle$ by definition) — confirmed, and the basis-dependence
  point is drawn out explicitly in the solution.
- **Exercise 5 (general Jones vector + global phase):** trivial from the
  definition of the standard basis; global-phase invariance of $|\langle
  n|e^{i\varphi}\psi\rangle|^2$ confirmed via $|e^{i\varphi}|=1$ for any
  real $\varphi$, for arbitrary $|n\rangle$.
- **Photon-flux estimate (Worked Example 3):** $E=hc/\lambda\approx
  3.06\times10^{-19}$ J $\approx1.91$ eV at $\lambda=650$ nm (computed
  with $h=6.626\times10^{-34}$ J·s, $c=2.998\times10^8$ m/s);
  $\dot N=P/E\approx3.27\times10^{15}$ photons/s at $P=1$ mW. Both
  numbers verified numerically in Python and match the text.
- **$c=1/\sqrt{\mu_0\varepsilon_0}$:** computed with $\mu_0=4\pi\times
  10^{-7}$ T·m/A, $\varepsilon_0=8.854\times10^{-12}$ C²/N·m², giving
  $c\approx2.998\times10^8$ m/s — matches the stated $\approx3.00\times
  10^8$ m/s.

## Concerns

- None outstanding. One small wording issue caught during self-review
  (a stray/undefined `$I_0'$` in the three-polarizer puzzle's opening
  sentence) was fixed before finalizing — it now reads generically
  ("whatever intensity survives the first polarizer... a further factor
  of $\cos^2(90°)=0$") rather than introducing an undefined symbol.
- Reference texts (Griffiths, Hecht) are outside the contract's explicit
  list (Halliday/Resnick, Morin, French, Eisberg–Resnick, Griffiths QM)
  but are the standard, real texts for E&M and optics respectively —
  consistent with the contract's "as appropriate per day" clause, since
  none of the listed texts cover polarization/Jones calculus at this
  day's depth.

---

## Fix report (post-review)

File after fixes: `physics_fundamental/content/day08.md` — 583 lines
(within 350–600).

### MUST-FIX

**1. Mixture-vs-superposition misconception (was self-referential).**
Rewrote the callout's key sentences to state the operational distinction
explicitly:

> A linear polarizer at *any* angle $\theta$ transmits exactly half the
> incident intensity from circular light, and an *equal incoherent
> mixture* of horizontal and vertical light *also* transmits exactly half
> through a linear polarizer at *any* angle $\theta$ — every single
> linear-polarizer setting gives the identical reading for both. What
> breaks the tie is a quarter-wave plate (introduced later in today's
> Theory) placed before the final polarizer: it converts circular light
> into a *definite* linear state, which the polarizer that follows then
> passes completely or blocks completely depending on its angle —
> whereas the same quarter-wave plate leaves an incoherent
> horizontal/vertical mixture as an incoherent horizontal/vertical
> mixture (each component is already an eigenstate of the plate), which
> still transmits exactly half through the final polarizer no matter how
> it's oriented. Deterministic pass-or-block ... versus a stubborn,
> unbudgeable one-half for the mixture — that operational difference *is*
> the content of "coherent superposition $\ne$ mixture."

Verified both halves numerically: $|\langle\theta|R\rangle|^2=\tfrac12$
for every $\theta$ (since $\langle\theta|R\rangle=\tfrac{1}{\sqrt2}
e^{i\theta}$), and $\tfrac12\cos^2\theta+\tfrac12\sin^2\theta=\tfrac12$
for the H/V mixture at every $\theta$ — genuinely indistinguishable by
any linear analyzer alone, as claimed. Located at what is now roughly
L153–177 (file grew from the other edits).

### MINOR

**2. Phase convention (near the QWP intro).** Added one paragraph fixing
the convention once: "we write a wave's real field as $E=\mathrm{Re}
[A\,e^{i(kx-\omega t)}]$, so an added optical delay $\delta$ multiplies
that component's complex amplitude $A$ by $e^{+i\delta}$," plus the
half-sentence that "right"/"left" handedness labels on $|R\rangle,
|L\rangle$ are themselves convention-dependent across texts, while the
$\pm90°$ relative-phase content is not.

**3. Ampère–Maxwell double-negative (theory + Solution 1).** Both
instances rewritten to state the mechanism plainly: "Maxwell's addition
of the changing-$\vec E$ term closes the loop — a changing electric field
creates a magnetic field just as a current does, which is exactly what
lets the $\vec E$ and $\vec B$ fields in a light wave continuously
regenerate each other through empty space, with no current or charge
required at all." (Theory bullet and Solution 1 both updated with
equivalent plain-mechanism wording.)

**4. Polarization plane phrasing.** Dropped "the plane containing $\vec
E$ and $\vec k$"; the wave-anatomy bullet now just says "'polarization,'
defined precisely below, is simply the direction $\vec E$ points," with
the full definition still given at the start of the Polarization
subsection (unchanged, already correct).

**5. Current/intensity symbol collision.** Added inline clarifier at the
DC-circuits survey: "**current** $I$ (charge flow rate, in amps — this
$I$ is current, not the light intensity of earlier sections; the
collision is purely notational)."

**6. Wave-plate/gate claim in Connection to QM.** Corrected: the Hadamard
analog is a **half**-wave plate at $22.5°$, not the quarter-wave plate.
New text gives the explicit matrix and action: $M(22.5°)=\tfrac{1}{\sqrt2}
\begin{pmatrix}1&1\\1&-1\end{pmatrix}$ sends $|H\rangle\mapsto|D\rangle$,
$|V\rangle\mapsto|{-}45°\rangle$ — verified numerically
($M\cdot(1,0)=(0.7071,0.7071)$, $M\cdot(0,1)=(0.7071,-0.7071)$, matching
$|D\rangle,|{-}45°\rangle$ exactly). Today's quarter-wave plate is now
described as "a different single-qubit unitary — the one that turns a
linear basis state into a circular one," with no Hadamard claim attached
to it.

**7. Interaction-free/weak-measurement name-drop (Solution 3).** Deleted;
kept only the Zeno/adiabatic-rotation framing: "many small, gentle nudges
accomplish what one abrupt, large change cannot."

**8. "Intensity-squared-of-amplitude" phrasing.** Rephrased: "intensity
goes as the square of the amplitude, so it responds to projections
quadratically rather than linearly."

### Re-run checklist (post-fix)

1. Anatomy sections present, correctly ordered — pass (unchanged by
   fixes).
2. Every named equation derived or motivated — pass; fix 3 additionally
   removed the confusing double-negative in that motivation, fix 2 makes
   the QWP matrix's sign convention explicit rather than asserted.
3. 5 exercises, tiers labeled, hints non-spoiling, solutions match — pass
   (untouched by fixes; Exercise 4(b) triviality and Hint 4 left as-is
   per controller ruling).
4. Exercises use only Day 8 content — pass (unchanged).
5. Notation matches conventions — pass; fix 5 resolves the one real
   ambiguity (circuit $I$ vs. intensity $I$) flagged in review.
6. 2 `> **Misconception:**` callouts present — pass; the first is now
   substantively corrected per fix 1, the second (polarizer-as-sieve)
   was untouched and remains correct.
7. Time budget "~3.5 hours" — pass (unchanged).
8. Not a sim day — N/A (unchanged).

No new inconsistencies introduced: checked that "Hadamard-rotated basis"
(Connection to QM, referring to the *basis* $\{|D\rangle,|{-}45°\rangle\}$
that a Hadamard would rotate the computational basis into) still reads
correctly alongside the corrected half-wave-plate-is-Hadamard claim — the
two statements are about different things (a basis label vs. which
physical device implements the gate) and do not conflict.

Controller rulings honored: Exercise 4(b)'s by-design triviality, Hint 4,
the Griffiths/Hecht citations, and the Day 13 Exercise 4 pointer were all
left unchanged.
