# Task 3 Report — Day 2: Energy and Potential Wells

File written: `physics_fundamental/content/day02.md` (502 lines; `content/`
directory created, did not previously exist).

## Sections written (in order)

1. Title + Learning objectives (6 testable bullets) + Time budget: ~3 hours.
2. Reference material (Morin ch.4 / Halliday-Resnick work-energy & PE
   chapters; self-contained note; builds on Day 1's $m\ddot x=F$ framing).
3. Theory, six subsections matching the brief's theory beats in order:
   - Work-energy theorem, derived via $\ddot x = v\,dv/dx$.
   - Conservative forces, $V(x)=-\int F\,dx$, $F=-dV/dx$; gravity and spring
     potentials both derived from the definition.
   - Energy conservation derived by differentiating $E=K+V$ and using
     Newton's law (misconception callout on "energy as substance" placed
     immediately after).
   - Core skill: reading $V(x)$ diagrams — turning points from $V(x)\le E$,
     stable/unstable equilibria from sign of $V''$, and a described
     wall/well/barrier/asymptote figure (with ASCII sketch) walked through
     at three energies ($E=-1,+0.5,+2$) covering bound, bound-larger, and
     free/escaping cases, including the "allowed but disconnected" point
     (misconception callout on turning points placed here).
   - Small-oscillation preview (Taylor expansion around a minimum → spring
     shape), explicitly deferred to Day 3.
   - Escape velocity: derived $V(r)=-GMm/r$ from the inverse-square force
     (explicitly noting why the uniform-$g$ potential cannot answer this
     question), then the $E=0$ escape condition.
4. Worked examples (3): double-well $x^4-2x^2$ at $E=-0.5,0,1$; pendulum
   speed at bottom by energy (no ODE); Earth escape velocity, numeric.
5. Exercises: 5 total, numbered continuously, tiers **Retrieval** (2),
   **Standard** (2), **Stretch** (1), opening line present.
6. Hints: 5, one per exercise, name the first move without giving answers.
7. Solutions: 5, full derivations with final answers, in the compressed
   step-by-step style of the exemplar.
8. Connection to QM: bound states ↔ discrete energies, scattering states ↔
   continuum, classically forbidden region → tunneling (Day 17), and the
   small-oscillation preview → quantum harmonic oscillator.

No `## Simulation` section — this day has no assigned simulation.

## Checklist results (day-file-contract.md, per-day verification)

1. **Anatomy present, in order, correctly headed** — PASS. Verified via
   heading grep: Learning objectives → Reference material → Theory →
   Worked examples → Exercises → Hints → Solutions → Connection to QM.
2. **Every named equation derived or motivated** — PASS. Work-energy
   theorem (chain-rule derivation), $F=-dV/dx$ (fundamental theorem of
   calculus), gravity/spring potentials (direct integration from $F$),
   energy conservation ($dE/dt=0$ derivation), small-oscillation shape
   (Taylor expansion), $V(r)=-GMm/r$ (integration of inverse-square force,
   with explicit note on why uniform-$g$ potential fails for this purpose),
   escape velocity (energy conservation at $E=0$), period integral
   (Exercise 5, derived from $v=dx/dt$ and time-reversal symmetry). No
   equation is dropped in unmotivated.
3. **Exercise count 4-6, tiers labeled, hints non-spoiling, every exercise
   has matching hint + solution, solutions actually solve the problem** —
   PASS. 5 exercises, tiers labeled **Retrieval/Standard/Stretch**, 5
   hints, 5 solutions, all numerically/symbolically verified independently
   (see below).
4. **Exercises use only this day + prior days** — PASS. All five exercises
   use only work-energy theorem, $V(x)$ construction, turning points,
   equilibrium classification, and (Exercise 4) Newton's second law in the
   radial direction with centripetal acceleration $v^2/R$ flagged
   explicitly as "recall" prior general-mechanics knowledge, consistent
   with Day 1's $F=ma$ framing and the brief's explicit exercise spec.
5. **Notation matches conventions** — PASS. $K$ used for kinetic energy
   throughout (not $T$); $T$ reused only for oscillation period in
   Exercise 5, which is fine since Day 2 is not one of the days 9-11 where
   $T$ is reserved for kinetic energy. Spring constant written $k_s$
   consistently everywhere (checked via grep for bare `k`; no collisions
   found) for forward consistency with Days 3/5/16/17. $V(x)$ for potential,
   $E$ total energy, $\omega_0$ natural frequency introduced correctly in
   Exercise 5's solution.
6. **≥2 misconception callouts** — PASS. Two `> **Misconception:**`
   blockquotes present (lines 124 and 162): "energy is a substance," and
   "zero velocity at a turning point means zero force."
7. **Time budget stated and plausible** — PASS. "Time budget: ~3 hours"
   (line 22), matching contract's ~3h target for days 1-4.
8. **Sim days** — N/A, no simulation assigned to this day.

## Exercise-by-exercise verification (worked myself, numerically checked)

1. $F=-dV/dx$ from $V=-\int F\,dx$ via FTC — direct, correct.
2. Spring turning points: $x=\pm\sqrt{2E/k_s}$ — correct, and consistent
   with Exercise 5's amplitude $A=\sqrt{2E/k_s}$.
3. $V(x)=x^3-3x$: equilibria $x=\pm1$ ($x=1$ stable, $V=-2$; $x=-1$
   unstable, $V=2$). At $E=0$: roots $x=-\sqrt3,0,\sqrt3$ — free branch
   ($x\le-\sqrt3$, one turning point) and bound branch ($0\le x\le\sqrt3$).
   At $E=3$: single real root of $x^3-3x-3=0$ at $x\approx2.1038$ (verified
   numerically by Newton's method), barrier submerged, free motion with one
   turning point. All values numerically confirmed.
4. Hemisphere departure angle: $\cos\theta=2/3$, $\theta\approx48.19°$ —
   verified numerically ($\arccos(2/3)=48.1897°$).
5. Period integral derived from $v=dx/dt$ and time-reversal symmetry;
   evaluated for the spring via $\arcsin$ integral to get $T=2\pi/\omega_0
   =2\pi\sqrt{m/k_s}$ — matches the standard SHM period exactly.

Worked-example numbers also independently recomputed and confirmed:
double-well turning points at $E=-0.5$ ($x=\pm0.5412,\pm1.3066$), $E=0$
($x=0,\pm\sqrt2=\pm1.4142$), $E=1$ ($x=\pm1.5538$); pendulum $v\approx3.13$
m/s for $L=1$ m, $\theta_0=60°$; Earth escape velocity $\approx11.19$ km/s
via $\sqrt{2GM/R}$, cross-checked at $\approx11.17$ km/s via $\sqrt{2gR}$
(both round to the well-known 11.2 km/s).

## Self-review findings

- All numeric claims in worked examples and solutions were recomputed
  independently with a small Python script and matched the file's stated
  values to the precision given.
- Checked that Exercise 4's use of centripetal acceleration ($v^2/R$) does
  not silently pull in unavailable material: it's flagged inline as
  "recall" prior knowledge, and the exercise is explicitly specified in the
  task brief, so this is intentional and consistent with instructions.
- Checked for notational collisions between spring constant and wave
  number ($k$ vs $k_s$) — none found, and $k_s$ used forward-consistently
  even though Day 2 isn't in the contract's explicit collision list, since
  Day 2 originates the spring potential that Day 3 continues.
- Verified the escape-velocity subsection explicitly explains why the
  uniform-gravity potential ($V=mgx$) cannot be used for this calculation
  (it diverges as $x\to\infty$), rather than silently switching potentials
  without comment.

## Concerns

None outstanding. One minor stylistic note: the exemplar file
(`quantum_computing_foundations/content/day03.md`) ends with a "Journal
template" section after Solutions; the day-file-contract's mandatory
anatomy list does not include this section, so it was intentionally
omitted from `day02.md` to follow the contract exactly. Flagging in case
the controller wants journal templates added uniformly across all 18 days.

## Fix report (post-review revision)

The coordinator approved the file contingent on 10 fixes (2 IMPORTANT, 8
MINOR). All 10 applied to `physics_fundamental/content/day02.md`. File is
now 515 lines (was 502).

**1. (IMPORTANT) Morin chapter citation.** Line 26 was wrong (cited ch. 4,
"The Laws of Energy and Momentum I" — that's actually Morin's Oscillations
chapter). Fixed to:
> "Morin, *Introduction to Classical Mechanics*, ch. 5 (conservation of
> energy and momentum), or Halliday/Resnick, ..."
No invented chapter title; chapter number + plain description only.

**2. (IMPORTANT) Exercise 4 solution — unmotivated $v^2/R$.** Added a
motivating sentence in Solution 4, with the labeled forward pointer, in
place of the bare "(recall: ...)" parenthetical:
> "The ball leaves the surface when the normal force $N\to0$. Up to that
> point, Newton's second law in the radial direction needs one kinematic
> fact we haven't derived yet: in uniform circular motion the velocity
> vector turns with the position vector, giving an inward acceleration
> $v^2/R$ — a kinematics fact we take as given here (Day 4's orbit survey
> motivates it). With that, and gravity's inward radial component
> $mg\cos\theta$ against the surface pushing outward with $N$: ..."

**3. (MINOR) ASCII figure fixes.** Three sub-fixes, all applied together:
- Added, directly under the ASCII block: "(The baseline drawn along the
  bottom is the position axis, not $V=0$; $V=0$ is the flat segment on the
  right, where the curve asymptotes.)"
- Fixed the stray space breaking the underscore run: `\____ ___________/`
  → `\________________/` (one continuous run).
- Reconciled the drawn flat well-bottom with the stated single minimum by
  changing the prose from "dips down to a minimum of $V=-3$ at $x=2$" to
  "dips down to a broad minimum of $V=-3$ near $x=2$," and relabeling the
  figure annotation from "(well minimum, V=-3, at x=2)" to "(broad minimum,
  V=-3, near x=2)" to match the drawn flat bottom.

**4. (MINOR) "i.e." → "e.g." in the turning-point misconception.** Line
(originally 167-169) changed from "...coincide with an equilibrium, i.e.
the particle asymptotically approaches an unstable maximum..." to "...
coincide with an equilibrium, e.g. the particle asymptotically approaches
an unstable maximum..." — correctly signals this is one example among
possible zero-force turning points (e.g. $E=V_{\min}$ sitting exactly on a
stable minimum is another), not the only one.

**5. (MINOR) Exercise 3 wording.** "then describe (with exact turning
points) the motion at $E=0$ and at $E=3$" → "then describe (with turning
points exact where possible, numerical otherwise) the motion at $E=0$ and
at $E=3$" — accurate since the $E=3$ root is numerical ($x\approx2.1038$),
not closed-form.

**6. (MINOR) Hint 4 spoiler trim.** Replaced the second half of Hint 4
(which gave away "normal force set to zero (the departure condition)") with
the non-spoiling version:
> "Write energy conservation between the top and angle $\theta$ to get
> $v(\theta)^2$ as one equation; you need a second equation besides energy
> conservation — what happens to the normal force at the moment the ball
> leaves the surface?"

**7. (MINOR) Exercise 4 rest-at-top wording.** "A small ball starts at
rest ... at the very top" → "A small ball starts at rest (given an
infinitesimal nudge) at the very top" — flags that exact top-of-hemisphere
rest is itself an unstable equilibrium, requiring the nudge for any motion
to occur at all.

**8. (MINOR) Exercise 2 / Solution 2 — $E\ge0$ clause.** Exercise 2 now
reads "...find the turning point(s) at total energy $E$ (assume $E\ge0$,
as it must be for this potential)." Solution 2 now reads:
> "$x = \pm\sqrt{2E/k_s}, \qquad E\ge0$ (required since
> $V(x)=\tfrac12k_sx^2\ge0$ everywhere for this potential, so no motion —
> and no real turning point — exists at $E<0$)."

**9. (MINOR) Escape-velocity digit slip.** $2GM/R$ recomputed precisely as
$1.2513\times10^{8}$ (Python-verified: $2(3.986\times10^{14})/(6.371\times
10^6) = 1.25129\times10^8$), replacing the stated $1.2516\times10^8$. Final
$v_{\text{esc}}\approx1.119\times10^4$ m/s $\approx11.2$ km/s is unchanged
(the sqrt of both values rounds to the same three sig figs).

**10. (MINOR) 1D path-independence justification rewritten.** Old text
incorrectly claimed "in one dimension there is only one path between two
points" (false — a particle can double back). Replaced with the correct
endpoint-only argument:
> "The integral $W=\int_{x_1}^{x_2}F\,dx$ above depended only on the two
> endpoints $x_1, x_2$, not on any details of the trip between them — even
> though the particle is free to double back, overshoot, and retrace
> ground along the way. This holds because $F$ depends on $x$ alone:
> $\int F(x)\,dx$ is an ordinary single-variable definite integral, and the
> fundamental theorem of calculus makes any such integral a function of
> its two endpoints only, however winding the trajectory that connects
> them. (In more than one dimension this endpoint-only property is a real
> restriction, called path-independence, that not every force satisfies;
> here it follows automatically from $F$ being a function of $x$ alone.)"

### Checklist re-verification after fixes

1. **Anatomy present, in order** — PASS (re-grepped headings: Learning
   objectives → Reference material → Theory → Worked examples → Exercises
   → Hints → Solutions → Connection to QM, unchanged by the edits).
2. **Every named equation derived/motivated** — PASS, and strengthened:
   the $v^2/R$ fact used in Exercise 4 is now explicitly flagged as an
   assumed-given kinematics fact with a forward pointer, rather than
   silently invoked; the 1D path-independence claim is now correctly
   justified rather than resting on a false premise.
3. **Exercises 4-6, tiers labeled, hints non-spoiling, matching
   solutions** — PASS. Still 5 exercises (2 Retrieval / 2 Standard / 1
   Stretch), re-verified by grep. Hint 4 no longer states the departure
   condition outright; it now poses the normal-force question instead.
4. **Exercises use only this day + prior days** — PASS, and the boundary
   is now explicit rather than assumed: Exercise 4 clearly marks $v^2/R$
   as taken-as-given with a named forward source (Day 4).
5. **Notation matches conventions** — PASS, unaffected by these edits ($K$,
   $k_s$, $V$, $E$ usage unchanged).
6. **≥2 misconception callouts** — PASS, both still present; the second's
   "i.e."→"e.g." fix makes its scope claim accurate rather than overly
   narrow.
7. **Time budget stated and plausible** — PASS, unaffected ("~3 hours").
8. **Sim days** — N/A, unaffected.

### Exercise re-verification after fixes

Re-checked that no fix altered any final answer:
- Exercise 2 / Solution 2: answer still $x=\pm\sqrt{2E/k_s}$, now correctly
  scoped to $E\ge0$.
- Exercise 3 / Solution 3: unchanged; wording now accurately flags the
  $E=3$ turning point as numerical ($x\approx2.1038$).
- Exercise 4 / Solution 4: answer still $\cos\theta=2/3$,
  $\theta\approx48.19°$; derivation is now fully motivated end to end.
- Worked example 3: escape velocity still $\approx11.2$ km/s; only the
  intermediate digit string correcting $2GM/R$ changed, not the final
  numbers or the cross-check via $\sqrt{2gR}$.

No new concerns. File is ready.
