### Task 14: Day 13 — Blackbody Radiation and the Photon + sim

**Files:**
- Create: `content/day13.md`
- Create: `code/day13_blackbody_curves.py`

**Interfaces:**
- Consumes: day 6's standing-wave mode counting ($f_n = nv/2L$), day 12's Boltzmann/partition machinery and equipartition.
- Produces: Planck's law and the quantized-oscillator average $\langle E\rangle = hf/(e^{hf/k_BT}-1)$; the photon $E=hf$; work function/stopping potential. Days 14, 15 consume $E=hf$ everywhere.

- [ ] **Step 1: Draft `content/day13.md` (~3.5h day) with this content brief:**

*Learning objectives:* count cavity modes (1D honestly, 3D by stated scaling); derive Rayleigh–Jeans and articulate the ultraviolet catastrophe; redo the average with $E_n = nhf$ to get Planck's law; extract Wien and Stefan–Boltzmann as consequences; analyze the photoelectric effect classically vs. with photons.

*Theory beats:*
1. Setup: a hot cavity's radiation spectrum as THE 1900 problem; blackbody = perfect absorber, universal spectrum.
2. Mode counting: 1D cavity modes from day 6's $f_n = nv/2L$ — count modes below $f$ honestly; state the 3D result $dN/df \propto f^2$ with the geometric reasoning sketched (shell in $n$-space, factor 2 for polarization — cite day 8) but not belabored.
3. Rayleigh–Jeans: (modes per frequency) × (equipartition $k_BT$ per mode) → $u(f) \propto f^2 k_BT$ → integral diverges. The ultraviolet catastrophe stated plainly: classical physics predicts infinite energy in every warm box; day 12's ominous paragraph cashed in.
4. **Planck's move — the day's centerpiece, fully derived:** allow each mode only $E_n = nhf$; compute $\langle E\rangle$ with day 12's partition sum (geometric series, done completely) → $\langle E\rangle = hf/(e^{hf/k_BT}-1)$; low-$f$ limit recovers $k_BT$ (Taylor expand — classical physics survives where it worked); high-$f$ modes freeze out → spectrum peaks and dies. Assemble Planck's law.
5. Consequences: Wien displacement (state $\lambda_{\max}T = b$, derive the origin as maximizing Planck's law — set up the transcendental equation, quote its numerical root); Stefan–Boltzmann $\propto T^4$ (state, with the integral's origin indicated).
6. Photoelectric effect: the experimental facts table (threshold frequency, instantaneous emission, intensity raises current not energy); what the classical wave picture predicts for each (wrong on all three); Einstein: light arrives as quanta $E = hf$; $eV_{\mathrm{stop}} = hf - \phi_w$ (work function $\phi_w$); slope of $V_{\mathrm{stop}}$ vs. $f$ measures $h$ — Millikan's reluctant confirmation, one sentence.
- Misconceptions: "Planck proposed photons" (Planck quantized exchange with matter and considered it a trick; Einstein made light itself grainy — the distinction is historically and conceptually real); "brighter light means more energetic electrons" (more *numerous*; only frequency raises per-electron energy).

*Worked examples:* (1) the geometric-series computation of $\langle E\rangle$ for a quantized mode, start to finish (this is also exercise-able as retrieval; the worked version carries full commentary); (2) the Sun as a blackbody: $T \approx 5800$ K → $\lambda_{\max}$ via Wien, compare to visible; (3) photoelectric: given $\phi_w$ (sodium) and $\lambda$, compute stopping potential; check the threshold.

*Simulation section:* run `python3 code/day13_blackbody_curves.py`; predict-prompts: "double T — the peak moves which way, and the area grows by what factor?", "where exactly do the RJ and Planck curves agree, and why there?", "at the Sun's temperature, is the peak inside the visible band?"

*Exercises:* Retrieval: (1) reproduce the quantized-mode $\langle E\rangle$ geometric-series derivation closed book; (2) state the three photoelectric facts and what the wave picture wrongly predicts for each. Standard: (3) cosmic microwave background at $T=2.7$ K: find $\lambda_{\max}$ and the corresponding photon energy in eV, compare to $k_BT$; (4) a photon counter: how many 500 nm photons per second is 1 nW? (closes day 8's forward flag). Stretch: (5) show $\langle E\rangle \to k_BT$ as $hf/k_BT \to 0$ by Taylor expansion, and $\to hf\,e^{-hf/k_BT}$ as $hf/k_BT\to\infty$; explain in one paragraph how this single formula contains both classical physics and its death.

*Connection to QM:* $E=hf$ is the first quantum equation of your course; "each field mode is a quantized oscillator" is the seed of quantum optics — the photon states your photonics-flavored course manipulates in interferometers are exactly these mode quanta.

- [ ] **Step 2: Write `code/day13_blackbody_curves.py`** per Global Constraints. Two panels: (a) Planck spectral curves at T = 3000, 4500, 5800 K with Wien peaks marked by vertical dashed lines, visible band shaded; (b) Planck vs. Rayleigh–Jeans at 5800 K on log-log axes showing agreement at low frequency and divergence at high.

- [ ] **Step 3: Run `python3 code/day13_blackbody_curves.py`** — expect clean run; peaks shift blue with T; RJ hugs Planck at low $f$ and explodes at high $f$.

- [ ] **Step 4: Run the per-day verification checklist**; fix failures.

---

