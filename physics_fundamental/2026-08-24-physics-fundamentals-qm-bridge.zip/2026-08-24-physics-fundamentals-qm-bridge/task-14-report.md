# Task 14 Report — Day 13: Blackbody Radiation and the Photon

**File written:** `physics_fundamental/content/day13.md` (544 lines)

**Scope note:** Per explicit instruction, `code/day13_blackbody_curves.py` was
NOT written (deferred for token budget). The `## Simulation` section was
written in full per the brief (run command, panel descriptions, three
predict-prompts verbatim from the brief) with the mandated closing italic
line: "*The script ships separately; the predict-prompts stand on their
own.*"

## Sections (anatomy, in order)

Title → Learning objectives (6 bullets + "Time budget: ~3.5 hours") →
Reference material (Eisberg–Resnick; HRW modern-physics chapters;
self-contained note; cites Day 6, Day 8, Day 12) → Theory (10 `###`
subsections) → Worked examples (3) → Simulation → Exercises (5, tiered) →
Hints (5) → Solutions (5) → Connection to QM.

Theory subsections: blackbody setup; 1D mode counting (full, from Day 6's
$f_n=nv/2L$) + 3D scaling (shell-in-$n$-space sketch, polarization factor 2
cited to Day 8, not belabored); Rayleigh–Jeans + UV catastrophe (ties to
Day 12's "ominous" paragraph); **Planck's move — geometric series done in
full** (partition function, differentiate-the-series trick for $\sum n x^n$,
final $\langle E\rangle=hf/(e^{hf/k_BT}-1)$); both limiting Taylor
expansions; Planck's law assembled; Wien (transcendental equation
$(x-5)e^x+5=0$ set up, root $x\approx4.9651$ quoted, $b\approx2.898\times
10^{-3}$ m·K derived from it); Stefan–Boltzmann ($T^4$, integral
$\pi^4/15$ cited as $\Gamma(4)\zeta(4)$, not re-derived); photoelectric
facts table + Einstein's fix + $eV_{\text{stop}}=hf-\phi_w$ derivation +
one-sentence Millikan.

## Checklist results (per day-file-contract.md)

1. Anatomy sections present, correctly ordered/headed — **pass**.
2. Every named equation derived or motivated — **pass** (mode counting,
   Rayleigh–Jeans, and the geometric-series $\langle E\rangle$/Planck's law
   fully derived; Wien and Stefan–Boltzmann given the lighter "state the
   integral/transcendental-equation origin, quote the number" treatment the
   brief explicitly calls for).
3. Exercise count 5 (within 4–6); tiers labeled (Retrieval 1–2, Standard
   3–4, Stretch 5); every exercise has a matching hint and solution; hints
   don't give away final numeric answers — **pass**.
4. Exercises solvable from Day 13 + priors only (Day 6 mode logic, Day 8
   $E=hf$ flag/photon-counting style, Day 12 $k_BT$ in eV) — **pass**, no
   forward references.
5. Notation: $\phi_w$ used throughout for work function, with an explicit
   one-line note distinguishing it from phase $\phi$ (not otherwise used
   this day); $K$/$K_{\max}$ for kinetic energy — **pass**.
6. Misconception callouts: 2, exactly the two brief-mandated ones
   (Planck-vs-Einstein historical distinction; brighter ≠ more energetic
   electrons), placed where they bite (right after the geometric-series
   derivation; inside the photoelectric section) — **pass** (meets the ≥2
   minimum).
7. Time budget "~3.5 hours" stated, correct for a day-5–15 file — **pass**.
8. Sim-day check: **N/A per user's deferral decision** — script not
   written; `## Simulation` section present with run command, panel
   description, and the three brief-specified predict-prompts verbatim,
   plus the required deferral disclaimer line.

## Exercise verification (worked closed-book, final answers)

1. Geometric-series retrieval — reproduces $\langle E\rangle=hf/(e^{hf/k_BT}-1)$
   via $Z=1/(1-x)$, $\sum nx^n=x/(1-x)^2$ (by differentiating the geometric
   series), ratio, resubstitution. Confirmed correct.
2. Photoelectric three facts + wave-picture failure on each — standard,
   matches the Theory table.
3. CMB at $T=2.7$ K: $\lambda_{\max}=b/T\approx1.07\times10^{-3}$ m
   (1.07 mm) — **matches expected check**. Photon energy $hf\approx
   1.16\times10^{-3}$ eV; $k_BT\approx2.33\times10^{-4}$ eV; ratio
   $\approx5.0$, consistent with Wien's root $x\approx4.965$ — **matches
   the "~$10^{-3}$ eV vs $k_BT$" expectation**, with the added observation
   that the ratio always equals the Wien constant regardless of $T$.
4. Photon counter, 1 nW at 500 nm: $hf=2.48$ eV $=3.97\times10^{-19}$ J;
   $\dot N = P/hf \approx 2.5\times10^9$ photons/s — **matches expected
   check exactly**.
5. Both Taylor limits verified symbolically: low-$f$ → $k_BT(1-\varepsilon/2+
   \cdots)\to k_BT$; high-$f$ → $hf\,e^{-hf/k_BT}\to0$. Correct.

Worked examples independently re-verified: Sun ($T=5800$ K) →
$\lambda_{\max}\approx500$ nm — **matches expected check**, sits centrally
in the visible band. Sodium ($\phi_w=2.28$ eV, $\lambda=400$ nm) →
threshold $\lambda_0\approx544$ nm (400 nm is above threshold frequency,
consistent), $K_{\max}=0.82$ eV, $V_{\text{stop}}=0.82$ V. Stefan–Boltzmann
coefficient $8\pi^5k_B^4/(15h^3c^3)\approx7.55\times10^{-16}$ J/(m³K⁴),
cross-checked against the known radiation constant $a\approx7.566\times
10^{-16}$ J/(m³K⁴) — agrees to within rounding of constants used.

## Concerns

- `physics_fundamental/content/day12.md` does not yet exist on disk (only
  day01–day11 present at task start); Day 13 cites Day 12's Boltzmann
  factor / partition function / equipartition / "ominous infinite-modes
  paragraph" per the task brief's explicit instruction that these may be
  cited without reading the file. No inconsistency is expected once Day 12
  is written, since the brief's description of Day 12's products was used
  directly, but this is worth a cross-check pass once Day 12 lands.
- The deferred simulation script means the file cannot be run/verified
  end-to-end as a sim day; this is expected and intentional per the scope
  change, not an error.
- No git commands were run, per hard constraints and standing user
  preference.
