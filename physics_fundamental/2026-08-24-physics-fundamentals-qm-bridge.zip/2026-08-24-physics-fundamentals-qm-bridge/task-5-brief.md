### Task 5: Day 4 — Momentum, Angular Momentum, Symmetry

**Files:**
- Create: `content/day04.md`

**Interfaces:**
- Consumes: days 1–2 (Newton, energy).
- Produces: the informal Noether statement (symmetry → conservation law) quoted by days 9 and 11; $\vec L = \vec r\times\vec p$ conserved under central forces.

- [ ] **Step 1: Draft `content/day04.md` (~3h day) with this content brief:**

*Learning objectives:* derive momentum conservation from Newton's third law; solve elastic/inelastic collisions; define $\vec L=\vec r\times\vec p$ and show central forces conserve it; state the symmetry↔conservation dictionary informally; survey rotation and orbits at concept level.

*Theory beats:*
1. Momentum conservation derived from N2+N3 for a two-body system; generalization stated.
2. Collisions: perfectly inelastic (momentum only) and elastic (momentum + energy) in 1D; the center-of-mass frame trick.
3. Angular momentum: $\vec L=\vec r\times\vec p$; $d\vec L/dt = \vec\tau$; central force ⇒ $\vec\tau=0$ ⇒ $\vec L$ conserved; equal-areas (Kepler's 2nd) as a one-line consequence.
4. The symmetry dictionary (informal Noether): space-translation symmetry → momentum; rotation symmetry → angular momentum; time-translation symmetry → energy. Frame as "why these three quantities and not others."
5. *Consolidation survey* (labeled as such, paragraph depth each): rigid-body rotation ($I$, $L=I\omega$, $K=\tfrac12 I\omega^2$, no derivations); gravity and orbits (Kepler's laws stated, circular-orbit speed derived in 3 lines).
- Misconceptions: "momentum and kinetic energy are interchangeable bookkeeping" (inelastic collisions conserve one, not the other); "angular momentum needs circular motion" (a straight-moving free particle has constant $\vec L$ about any point).

*Worked examples:* (1) 1D elastic collision, general masses — derive final velocities, check equal-mass swap limit; (2) skater pulling arms in: $I\omega$ conservation with numbers, where the kinetic-energy increase comes from; (3) comet at perihelion vs. aphelion via $L$ conservation.

*Exercises:* Retrieval: (1) derive two-body momentum conservation from N3; (2) show central force ⇒ $dL/dt=0$. Standard: (3) ballistic pendulum (inelastic collision + energy sweep-up, flags which conservation law applies in which phase); (4) circular orbit: derive $v(r)$ and the period–radius relation. Stretch: (5) reduce the two-body problem to one body with reduced mass $\mu = m_1m_2/(m_1+m_2)$ — derive, then explain in one paragraph why this matters for the hydrogen atom (day 14).

*Connection to QM:* conserved quantities become operators commuting with $\hat H$; the symmetry dictionary survives verbatim; angular momentum will be *quantized* — and the reduced-mass trick is exactly how the hydrogen atom becomes a one-body problem in the course.

- [ ] **Step 2: Run the per-day verification checklist**; fix failures.

---

