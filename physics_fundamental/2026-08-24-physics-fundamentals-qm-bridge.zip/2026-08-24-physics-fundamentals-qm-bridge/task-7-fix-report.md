# Task 7 fix report — Day 6 review fixes

Applied all 9 numbered fixes to `content/day06.md` and
`code/day06_interference_standing_waves.py`. No git commands run.

## CRITICAL

**1. Michelson factor-of-2 error (was L217–219).** Replaced the wrong
"λ/4 sweeps a full fringe cycle" claim with the correct half-cycle/full-cycle
split. New text:

> "...giving phase $\phi=k(2\Delta x)=4\pi\Delta x/\lambda$ and detected
> intensity that oscillates as $\cos^2(\phi/2)$ as $\Delta x$ is swept — a
> displacement of just $\lambda/4$ (a fraction of a micron for visible light)
> already carries $\phi$ through $\pi$, taking the output from bright to
> dark (half a fringe cycle); a *full* bright-to-dark-to-bright cycle needs
> $\phi$ to advance by $2\pi$, i.e. $\Delta x=\lambda/2$ — the standard
> one-fringe-per-$\lambda/2$ result. Sub-micron mirror displacements are
> therefore easily readable as whole fringes, which is why Michelson
> interferometers are used for extremely sensitive length and vibration
> measurements..."

## IMPORTANT

**2. Removed the visible self-correction (was L309–311).** Old text had
"one antinode, at $x=L/4$... — no: ...". New text states the result
directly:

> "$n=1$: $\sin(k_1x)=\sin(\pi x/L)$ peaks at $x=L/2$. Nodes only at the
> two fixed ends $x=0,L$; one antinode at the midpoint $x=L/2$."

**3. Renamed single-source intensity $I_1\to I_s$ (was L84–86).** New text,
with an explicit disambiguation note since $I_1$ is reused later for the MZ
port:

> "$$I = 4A^2\cos^2(\delta/2) = 4I_s\cos^2(\delta/2),$$
> where $I_s\propto A^2$ is the intensity from either source alone (written
> $I_s$, not $I_1$, to keep this single-source intensity distinct from the
> Mach–Zehnder *port*-1 intensity $I_1$ defined later in this file — the two
> symbols never mean the same thing)."

Also updated the immediately following "constructive/destructive
conditions" line ($I$ maximal $=4I_s$) to match. Checked the rest of the
file: every other $I_1$ occurrence is genuinely the MZ port-1 intensity, so
no further renames were needed.

**4. Complex-amplitude bridge inserted before first use (new paragraph
before *Beam-splitter convention*).** Added, verbatim per the requested
wording (lightly adapted to this file's $\tilde A$ notation, matching
`day03.md`'s own $\tilde A=Ae^{i\phi}$, $z=\mathrm{Re}[\tilde A e^{i\omega
t}]$ convention exactly):

> "Day 3 introduced the trick of bookkeeping oscillations as complex
> exponentials ($x=\mathrm{Re}[\tilde A\,e^{i\omega t}]$); we use the same
> device for fields: a phasor of length $A$ and angle $\alpha$ is the
> complex number $A\,e^{i\alpha}$, and intensity is $|E|^2$. That is what
> motivates writing a field's phase as $e^{i\phi}$ and its intensity as
> $I_0=|E_0|^2$ below."

**5. Sim: added fourth panel (standing-wave modes).** New panel (d) in
`code/day06_interference_standing_waves.py`: first three fixed-end modes
$\sin(n\pi x/L)$, $n=1,2,3$, each plotted at 4 time snapshots
($t=0,T_1/8,T_1/4,3T_1/8$) overlaid with increasing alpha, one color per
$n$. All analytic — no integration. Restructured the figure from a 1×3 row
to a 2×2 grid to fit the new panel. Script is now 89 lines (≤150 limit).
Updated the `## Simulation` section in `day06.md` to describe panel (d)
and added a fourth predict-before-run prompt about $n=3$'s interior node
count. Re-run confirmed clean (see Sim re-run output below).

## MINOR

**6. Softened fork-B arithmetic (was L429–430).** Old text asserted fork B
"would now be at 438 Hz" as the only option; new text acknowledges both
values consistent with a 2 Hz beat, while the conclusion $f_B=444\text{
Hz}$ (the *original*, pre-loading frequency) is unchanged:

> "...consistent with the observed drop to $2\text{ Hz}$ (fork B would now
> be at $442\text{ Hz}$, or $438\text{ Hz}$ if loaded further past
> $440\text{ Hz}$ — either is consistent with a $2\text{ Hz}$ beat, since
> beats only reveal $|f_A-f_B|$)."

**7. Boxed the quantized results instead of an imperative (was L186).**
Removed "**Box this result and the sentence that goes with it:**" and
instead literally boxed the two results:

> "$$\boxed{k_n = \dfrac{n\pi}{L}, \qquad f_n = \dfrac{n v}{2L}}, \qquad
> n=1,2,3,\dots$$ — the string's full harmonic series: a fundamental
> $f_1=v/2L$ and integer multiples of it. Days 15 and 16 quote this pair of
> boxed results directly, so keep the exact form in mind. Just as important
> is the sentence behind *why* the spectrum is discrete at all:" — followed
> by the boxed quotation-blockquote sentence, unchanged.

Also removed the now-redundant plain (unboxed) restatement of $k_n=n\pi/L$
that had preceded this paragraph, so the boxed pair is the single
authoritative statement of the result (small additional cleanup, not a
separate numbered fix).

**8. Trimmed Reference material from 5 to 4 bullets.** Merged the
Halliday/Resnick/Walker bullet into the French bullet as an "alternative
for the same material" clause, and folded a mention of Day 3's
complex-exponential trick into the existing "Builds on Day 5..." bullet
(now "Builds on Days 1, 3, and 5"). Final count: 4 bullets (≤4, per
contract).

**9. Sim polish.**
- Panel (a) y-label: `"I(y) / I_source"` → `"I(y) / I_max"`.
- Panel (b) now has an explicit y-label `"y(t)"` (previously none).
- The panel-(b) TWEAK line now names the editable constant `F2` directly
  ("set F2 much closer to F1"), not the derived `W2`.
- Panel (a)'s screen window widened from $\pm20\text{ mm}$ to
  $\pm40\text{ mm}$ (`y = np.linspace(-0.04, 0.04, 800)`), so halving `D`
  (which doubles the fringe spacing to ~25.3 mm) still leaves ~3 fringes
  visible across the window rather than being reduced to fewer than 2.

## Re-verified checklist

1. Anatomy sections present, in order, correctly headed — pass (`##`
   headers: Learning objectives, Reference material, Theory, Worked
   examples, Simulation, Exercises, Hints, Solutions, Connection to QM).
2. Every named equation derived/motivated — pass; re-checked the Michelson
   fix, the boxed $k_n/f_n$ result, and the new complex-amplitude bridge
   all read as motivated derivations, not drop-ins.
3. Exercise count 5 (within 4–6); tiers labeled; hints non-spoiling;
   every exercise has a matching hint + solution; Exercise 3's solution now
   reads consistently with the softened fork-B wording (conclusion
   $f_B=444\text{ Hz}$ unchanged) — pass.
4. Exercises solvable from Day 6 + prior days only — pass (no change
   affected this; the new Day 3 citation is a prior day, not a forward
   reference).
5. Notation matches conventions block — pass; $I_s$ vs. $I_1$ disambiguation
   in fix 3 makes this file's notation stricter than before, not looser.
6. 2 `> **Misconception:**` callouts present, unchanged locations,
   confirmed still present after edits — pass.
7. Time budget "~3.5 hours" stated — pass, unchanged.
8. Sim: script exists, runs clean, `## Simulation` section present with
   predict-before-run prompts (now 4, one per panel) — pass.

**Line counts after fixes:** `content/day06.md` = 519 lines (≤600 budget,
grew from 497 as instructed); `code/day06_interference_standing_waves.py`
= 89 lines (≤150 limit).

## Sim re-run output

Command: `MPLBACKEND=Agg python3 code/day06_interference_standing_waves.py`
(using `/opt/homebrew/bin/python3`, the interpreter with numpy/matplotlib
installed in this sandbox per the original task's environment note):

```
.../code/day06_interference_standing_waves.py:89: UserWarning: FigureCanvasAgg is non-interactive, and thus cannot be shown
  plt.show()
EXIT:0
```

Exit code 0. Same single benign `FigureCanvasAgg` warning as before (an
artifact of the forced headless backend, also reproduced by the
pre-existing `day03_oscillator_zoo.py` under the same invocation) — no
other warnings or exceptions. Four panels generated: (a) two-source
interference over the widened $\pm40\text{ mm}$ window, (b) beats with
envelope and new y-label, (c) MZ complementarity (unchanged), (d) the new
standing-wave mode-shape panel with fixed node positions across time
snapshots.

## Controller rulings acknowledged (left as-is)

- Hints 3–4 calibration: left unchanged.
- The `python3 code/...` run instruction in the `## Simulation` section:
  left as a bare command; environment/dependency specifics deferred to a
  future README per the controller's ruling.
