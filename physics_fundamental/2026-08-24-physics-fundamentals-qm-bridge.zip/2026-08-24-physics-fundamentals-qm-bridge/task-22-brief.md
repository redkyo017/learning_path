### Task 22: Final Coherence Pass

**Files:**
- Modify (fix-only): any file failing a check below.

**Interfaces:**
- Consumes: the entire corpus. Produces: the ship-ready state.

- [ ] **Step 1: Cross-reference sweep.** `grep -n "day0\|day1\|Day 0\|Day 1" content/*.md README.md STRATEGY.md` and verify every mention of another day refers to content that actually exists there (day 6's boxed sentence quoted by 15/16; day 7's bandwidth theorem in 17; day 8's Jones vectors in 18; day 11's table reprinted in 18; day 12's exercise 4 closed by 17; day 15's stretch matched by 16). Fix mismatches at the *referencing* end.

- [ ] **Step 2: Run all seven simulations** in sequence: `for f in code/*.py; do python3 "$f"; done` (close each window to proceed, or run with `MPLBACKEND=Agg` for a headless pass). Expected: seven clean exits, no exceptions, no warnings other than benign matplotlib font notices.

- [ ] **Step 3: Anatomy audit.** For each of the 18 day files confirm mechanically: all required `##` sections present in order; exercise/hint/solution counts match (`grep -c` per section); ≥2 misconception callouts; time budget stated. Produce a pass/fail line per file and fix every fail.

- [ ] **Step 4: Notation audit.** `grep -n "mathcal{L}" content/*.md` must return nothing; spot-check that $k_s$ is used for spring constants in days 3, 5, 16, 17 and $T_s$ for string tension in day 5; days 9–11 each flag the $L$/$T$ notation switch on first use.

- [ ] **Step 5: Report.** Summarize to the user: files created, checks run and their results, anything cut or deviated from this plan — and remind that committing is theirs to do.

---

## Self-Review (performed)

**Spec coverage:** STRATEGY.md → Task 1; 18 day files → Tasks 2–19 matching the spec's five phases and per-day content including the photonics weighting (interferometers in Task 7, Jones vectors in Task 9, Einstein A/B + two-level atom in Task 15, photonic qubits/MZ-as-circuit in Task 19); 7 sims → embedded in Tasks 4, 7, 8, 11, 14, 17, 18; glossary → Task 20; README → Task 21; verification section of the spec → per-task checklists + Task 22. Out-of-scope items (hydrogen solution, spin algebra, perturbation theory, LaTeX builds, commits) appear in no task. No gaps found.

**Placeholder scan:** no TBD/TODO; every exercise names its actual problem; every sim step specifies panels and method; hints/solutions required per-problem by the anatomy contract in Global Constraints rather than restated 18 times.

**Type consistency (here: notation/interface consistency):** $\omega_0$, $k_s$, $T_s$, $V(x)$, Jones-vector basis, MZ output laws $\cos^2(\phi/2)/\sin^2(\phi/2)$, box results, and the day-11 dictionary are defined once and consumed by name in later tasks' Interfaces blocks; day-18's beam-splitter matrix convention is stated where used.
