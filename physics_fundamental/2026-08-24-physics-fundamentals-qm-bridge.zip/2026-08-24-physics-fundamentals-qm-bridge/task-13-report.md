# Task 13 Report — Day 12: Minimal Thermal Physics

File written: `physics_fundamental/content/day12.md` (479 lines).

## Sections (anatomy, in order)

1. Learning objectives (6 bullets + "Time budget: ~3.5 hours.")
2. Reference material (Schroeder's *Thermal Physics*, HRW kinetic-theory
   chapters, self-contained note, Day 3 + Day 10 pointers)
3. Theory, subsections in brief order:
   - Why this day exists (framing paragraph)
   - Temperature, operationally ($k_BT\approx1/40$ eV anchor)
   - The Boltzmann factor, motivated lightly (reservoir/entropy-expansion
     argument, one exponential step, full derivation explicitly flagged as
     stat-mech-course material) — Misconception 1 placed just after
   - Partition function and thermal averages: the two-level system (fully
     worked qualitatively: freeze-out at $T\to0$, saturation at $T\to\infty$)
     — Misconception 2 placed just after
   - Equipartition (Gaussian-integral result *stated*, not derived; two
     quadratic terms → $k_BT$ for the oscillator)
   - Where equipartition must fail (the ominous paragraph, ending "Hold
     this thought for exactly one day.")
   - Survey: entropy, in two paragraphs (labeled)
   - Survey: the laws of thermodynamics, in four sentences (labeled)
4. Worked examples (3): two-level populations at $0.1\Delta,\Delta,10\Delta$;
   oscillator $\langle E\rangle=k_BT$; N₂ $v_{\rm rms}$.
5. Exercises (5, tiered): Retrieval (1–2), Standard (3–4), Stretch (5) —
   opens with the house line.
6. Hints (5, matching, non-spoiling).
7. Solutions (5, matching, full sketches).
8. Connection to QM (3 paragraphs: Planck's discrete-ladder move, freeze-out
   as pre-1925 evidence of quantization, two-level system → maximally mixed
   qubit).

## Checklist results

1. Anatomy present, in order, correctly headed — pass.
2. Every named equation derived or motivated: Boltzmann factor via
   reservoir/entropy Taylor-expansion (flagged lightweight); equipartition
   via stated Gaussian-integral results (not developed); two/three-level
   $Z$, $\langle E\rangle$ from definitions; entropy/laws given at survey
   depth as instructed — pass.
3. Exercise count 5 (within 4–6); tiers labeled; hints name the first move
   without giving numeric answers; every exercise has a matching hint and
   solution; solutions solve the stated problem — pass.
4. Exercises solvable from Day 12 + priors only (two/three-level systems,
   equipartition, ideal-gas kinematics — no forward references) — pass.
5. Notation: no Lagrangian/angular-momentum collision arises (topic doesn't
   need $L$); $K$ used for kinetic energy; $k_s$ kept for spring constant
   (avoids visual clash with $k_B$, consistent with Day 3) — pass.
6. 2 `> **Misconception:**` callouts, placed where they bite (after the
   Boltzmann factor and after the two-level system) — pass.
7. Time budget "~3.5 hours" stated, correct for a Day 5–15 file — pass.
8. No simulation day; N/A.

## Exercise verification (worked myself, final answers)

- **Two-level populations.** $k_BT=0.1\Delta$: $P_0=0.999955,\ P_1=4.54\times10^{-5}$.
  $k_BT=\Delta$: $P_0=0.7311,\ P_1=0.2689$. $k_BT=10\Delta$: $P_0=0.5250,\
  P_1=0.4750$. Confirms freeze-out (low $T$) and near-saturation, not exact
  50/50, at $T=10\Delta$.
- **Three-level system** at $k_BT=\Delta$ ($E=0,\Delta,2\Delta$):
  $Z=1+e^{-1}+e^{-2}=1.50321$; $\langle E\rangle=\Delta(e^{-1}+2e^{-2})/Z
  =0.6386\Delta/1.5032\approx0.425\,\Delta$.
- **N₂ RMS speed** at $T=300$ K, $M=0.0280$ kg/mol,
  $m=4.65\times10^{-26}$ kg: $v_{\rm rms}=\sqrt{3k_BT/m}\approx517$ m/s —
  close to the brief's "~515 m/s" ballpark; noted in-file as landing in the
  textbook range (505–520 m/s depending on rounding), not force-fit to 515.
- **Closed-form two-level average**: $\langle E\rangle=\Delta/(e^{\Delta/k_BT}+1)$;
  as $T\to\infty$, $e^{\Delta/k_BT}\to1$, giving $\langle E\rangle\to\Delta/2$ — confirmed.
- **Diatomic mode count**: 3 translational + 2 rotational + 2 vibrational =
  7 quadratic terms $\Rightarrow C_V=\tfrac72R$ predicted; measured
  $\approx\tfrac52R$ near room T because the 2 vibrational terms freeze out
  (flagged explicitly as a quantum effect, not resolvable classically).

All five numeric checks matched what the brief specified (or, for N₂,
matched within expected rounding of the brief's approximate figure).

## Concerns

- None blocking. The one judgment call: N₂ RMS speed came out to ≈517 m/s
  rather than the brief's quoted "~515 m/s"; I kept the accurate computed
  value (517 m/s, $T=300$ K, $M=28.0$ g/mol) and added a sentence noting it
  falls in the standard textbook range depending on rounding choices,
  rather than silently adjusting inputs to hit 515 exactly.
- No git commands were run, per hard constraint.

---

## Fix report (post-review)

File is now 534 lines (was 479). All fixes applied to
`physics_fundamental/content/day12.md`; no git commands run.

### CRITICAL — the saturation/catastrophe-location error (3 connected spots)

The brief's phrasing had led me to claim a discrete, unbounded, evenly-
spaced ladder "saturates" the way the two-level system does, and to locate
the classical catastrophe in a single mode's average rather than in the
sum over modes. Reviewer is correct; fixed in all three spots.

**1. Exercise 5 prompt.** Old: asked to contrast the two-level $\Delta/2$
saturation against "a classical continuum of evenly spaced levels
extending without bound" (wrongly conflating Planck's actual discrete
ladder with the foil). New text:

> Then consider a single mode with an *unbounded* ladder of evenly spaced
> discrete levels $0,\varepsilon,2\varepsilon,3\varepsilon,\dots$
> (Planck's actual model for one mode of light, met tomorrow) in place of
> only two levels. Explain, in one paragraph, why this discrete mode does
> *not* saturate the way the two-level system does — its average energy
> keeps climbing as $T$ increases, approaching the ordinary equipartition
> value $k_BT$ once $\varepsilon\ll k_BT$ — but instead **freezes out**,
> contributing far less than $\tfrac12k_BT$, whenever $\varepsilon\gg
> k_BT$ (exactly Worked example 1's $k_BT=0.1\Delta$ row, with
> $\varepsilon$ playing the role of $\Delta$). Then contrast this with a
> genuine classical *continuum* of levels (no gap at all between
> neighbors): explain why such a mode has nothing to freeze out below and
> so always delivers the full $k_BT$, at any $T$ — and why this is
> precisely why the classical catastrophe lives in the *sum over
> infinitely many modes*, not in any single mode's average.

Hint 5 rewritten to match (geometric-series $Z$, the two regimes
$\varepsilon\ll k_BT$ / $\varepsilon\gg k_BT$).

**2. Solution 5.** Kept the two-level $\langle E\rangle=\Delta/(e^{\Delta/k_BT}+1)\to\Delta/2$
derivation (correct, unchanged in substance — only reworded per minor fix
5, see below). Replaced the old "why a continuum never saturates"
paragraph — which wrongly treated the discrete ladder as a saturating
system — with:

> *The discrete unbounded ladder does not saturate — it freezes out
> instead.* ... $Z=\sum_{n=0}^\infty e^{-n\varepsilon/k_BT}=1/(1-e^{-\varepsilon/k_BT})$
> ... $\langle E\rangle = \dfrac{\varepsilon}{e^{\varepsilon/k_BT}-1}$.
> This ladder has no top level, so unlike the two-level system it has no
> $\Delta/2$-style ceiling to level off at. Instead, two different regimes
> appear depending on how $\varepsilon$ compares to $k_BT$ *at fixed
> temperature*. When $\varepsilon\ll k_BT$ ... $\langle E\rangle\to k_BT$
> — the *ordinary equipartition value* ... not a saturation ceiling. But
> when $\varepsilon\gg k_BT$ ... the mode **freezes out** ...
> $\langle E\rangle\approx\varepsilon\,e^{-\varepsilon/k_BT}$ ...
> far below the equipartition share $\tfrac12k_BT$.
>
> A genuine classical *continuum* ... has nothing to freeze out below at
> any $T$, so it always delivers the full $k_BT$ ... which is exactly why
> summing $k_BT$ over infinitely many continuum modes ... diverges, while
> summing the *discrete* ladder's $\langle E\rangle$ over infinitely many
> modes converges ... Discreteness — not any ceiling on a single mode's
> average — is what tames the sum; the classical catastrophe was always a
> statement about the *sum over modes*, never about any one mode failing
> to have a finite average.

I independently verified the Planck-oscillator average used here:
$Z=\sum_n e^{-n\varepsilon/k_BT}=1/(1-x)$ with $x=e^{-\varepsilon/k_BT}$;
$\langle E\rangle=\varepsilon x/(1-x)=\varepsilon/(x^{-1}-1)=\varepsilon/(e^{\varepsilon/k_BT}-1)$.
Limits: $\varepsilon/k_BT\to0\Rightarrow e^{\varepsilon/k_BT}-1\approx
\varepsilon/k_BT\Rightarrow\langle E\rangle\to k_BT$ (correspondence
limit, not a ceiling); $\varepsilon/k_BT\to\infty\Rightarrow\langle
E\rangle\approx\varepsilon e^{-\varepsilon/k_BT}\to0$ (freeze-out). Both
match the reviewer's specified formula and limits exactly.

**3. Connection to QM, opening paragraph.** Old last sentence wrongly
claimed discreteness "keeps $\langle E\rangle$ finite *per mode*" as if
the continuum gave an infinite per-mode average (it doesn't — it gives a
finite $k_BT$). New text relocates the fix to the sum:

> As Exercise 5 shows, a single discrete mode by itself still delivers the
> full classical $k_BT$ whenever its spacing $\varepsilon$ is small
> compared to $k_BT$ — discreteness alone does not shrink any one mode's
> average below the classical value. What it does instead is make each
> mode's average depend on $\varepsilon$: modes with $\varepsilon\gg k_BT$
> freeze out and contribute almost nothing, while modes with
> $\varepsilon\ll k_BT$ still contribute the full $k_BT$. Since a box
> supports infinitely many modes of ever-shorter wavelength (ever-larger
> $\varepsilon$), the classical catastrophe — which lives in *summing
> $k_BT$ over infinitely many modes*, exactly as the equipartition-failure
> paragraph above argued — is cured because the high-$\varepsilon$ tail of
> that sum is exponentially suppressed, rather than every mode
> contributing a flat, unshrinking $k_BT$ regardless of temperature.

### IMPORTANT

**2. "71/29" → "73/27" (Worked example 1, $k_BT=\Delta$ row).** Now reads:
"$P(E_0)=1/1.3679=0.7311$, $P(E_1)=0.3679/1.3679=0.2689$ — a genuine
**73/27** split, not 50/50 ..." — matches the computed 0.7311/0.2689 and
the existing misconception callout's "$73\%$ and $27\%$."

**3. $C_V$/$R$ undefined.** Chose to define them in the Theory section
(not restate Exercise 4 per-molecule), since $C_V=\tfrac{n}{2}R$ per mole
is the more standard textbook phrasing and Exercise 4 already asks for a
"molar heat capacity." Added one paragraph immediately after the
oscillator result, before "Where equipartition must fail":

> For a mole of particles it's standard to restate the same prediction as
> a **molar heat capacity**, $C_V:=d\langle E\rangle/dT$, using the gas
> constant $R:=N_Ak_B\approx8.31\text{ J/(mol·K)}$ ($N_A$ is Avogadro's
> number — $R$ is just $k_B$ rescaled to a per-mole basis). An average
> energy $\langle E\rangle=\tfrac{n}{2}k_BT$ per particle, for $n$
> quadratic terms, corresponds to $C_V=\tfrac{n}{2}R$ per mole — the same
> counting, in whichever unit ($k_BT$ per particle or $R$ per mole) a
> given problem asks for; Exercise 4 below uses the per-mole form.

Exercise 4 and Solution 4 themselves are unchanged — they now simply rely
on a definition that exists earlier in the same file.

### MINOR

**4. Solution 3, $0.425\Delta$ phrasing.** Old wrongly said "close to
$E_1$." New: "$0.425\Delta$ sits between $E_0=0$ and $E_1=\Delta$, below
the midpoint $0.5\Delta$ — consistent with the still-substantial
ground-state population pulling the average down, only partly offset by
the smaller but nonzero $E_2$ population pulling it back up."

**5. Solution 5, plain limits.** Folded into the critical rewrite above;
now reads: "the numerator stays fixed at $\Delta$ (it doesn't depend on
$T$ at all), while in the denominator $e^{\Delta/k_BT}\to e^0=1$, so the
denominator goes to $1+1=2$" — no "growing" language remains.

**6. "monatomic" deleted from Worked example 3.** Now: "**3. RMS speed of
a nitrogen molecule at room temperature.** A translational degree of
freedom is quadratic in momentum ..." (Exercise 2/Solution 2's uses of
"monatomic ideal-gas atom" are untouched — that context is genuinely about
a monatomic atom, not N$_2$).

**7. One room-temperature convention, stated up front.** Theory's
"Temperature, operationally" section now fixes $T=300$ K explicitly and
gives the precise value first:

> Today (and Days 13–15) fix one convention for "room temperature,"
> $T=300\text{ K}$ ... $k_BT \approx (8.617\times10^{-5}\text{ eV/K})(300\text{ K})
> \approx 0.0259\text{ eV}$ ... $\boxed{k_BT \approx 0.0259\text{ eV}
> \approx \frac{1}{40}\text{ eV at }T=300\text{ K (room temperature).}}$
> The precise value is $0.0259$ eV; "$\approx1/40$ eV" is the traditional
> rounded mnemonic, and the two are used interchangeably below.

Propagated consistently: Worked example 2 (oscillator) now uses $T=300$ K
and $k_BT\approx4.14\times10^{-21}\text{ J}\approx0.0259$ eV (was
$290$ K / $4.0\times10^{-21}$ J / $0.025$ eV); Exercise 1 and Solution 1
now use $k_BT\approx0.0259$ eV (ratio recomputed:
$e^{-0.2/0.0259}=e^{-7.72}\approx4.4\times10^{-4}$, about 1 in 2260 —
re-verified by hand). Worked example 3 (N₂ $v_{\rm rms}$) already used
$T=300$ K in SI units and needed no change; it is now the anchor every
other numeric example matches.

## Re-verified checklist (post-fix)

1. Anatomy present, in order, correctly headed — pass (unchanged
   structure; only prose within sections changed).
2. Every named equation derived or motivated — pass; the Planck-oscillator
   formula $\langle E\rangle=\varepsilon/(e^{\varepsilon/k_BT}-1)$
   introduced in Solution 5 is explicitly built from a stated geometric
   series (shown, not asserted) and flagged as "done in full tomorrow."
3. Exercise count 5; tiers labeled; hints don't spoil (Hint 5 still
   withholds the freeze-out vs. correspondence conclusion, only naming the
   two regimes to check); every exercise has a matching hint and solution;
   solutions solve the stated (now-corrected) problem — pass.
4. Exercises solvable from Day 12 + priors only — pass; the geometric
   series in Solution 5 uses only algebra plus the day's own Boltzmann
   factor/partition-function machinery, no forward material assumed as a
   prerequisite (it's presented as a worked extension, with the full
   treatment explicitly deferred to Day 13).
5. Notation unchanged and still consistent (no $L$ collision; $K$ for
   kinetic energy; $k_s$ kept distinct from $k_B$) — pass.
6. 2 `> **Misconception:**` callouts, placement left as-is per
   instruction — pass.
7. Time budget "~3.5 hours" still stated — pass.
8. No simulation day; N/A.

Numeric re-check of every changed number: two-level 73/27 at $k_BT=\Delta$
(0.7311/0.2689, matches); $k_BT$ at 300 K $=8.617\times10^{-5}\times300=
0.02585\approx0.0259$ eV and $=1.380649\times10^{-23}\times300=4.142\times
10^{-21}$ J (matches); Exercise/Solution 1 ratio $e^{-0.2/0.0259}=
e^{-7.722}\approx4.43\times10^{-4}$, i.e. 1 in ~2258 (rounded to 1 in 2260
in-file); Planck-oscillator formula and both its limits re-derived above
from the geometric series and confirmed against the reviewer's specified
formula.

File is 534 lines, still within the 350–600 contract range.
