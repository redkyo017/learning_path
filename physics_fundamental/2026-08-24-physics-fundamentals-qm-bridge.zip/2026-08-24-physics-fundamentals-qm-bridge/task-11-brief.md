### Task 11: Day 10 — The Hamiltonian + sim

**Files:**
- Create: `content/day10.md`
- Create: `code/day10_phase_space.py`

**Interfaces:**
- Consumes: day 9's $L$ and $p=\partial L/\partial\dot q$.
- Produces: $H(q,p)$, Hamilton's equations $\dot q = \partial H/\partial p$, $\dot p = -\partial H/\partial q$; phase-space portrait reading (oscillator ellipses, pendulum separatrix). Days 11, 16 consume $H$; day 11 consumes phase-space functions $f(q,p)$.

- [ ] **Step 1: Draft `content/day10.md` (~3.5h day) with this content brief:**

*Learning objectives:* construct $H$ from $L$ via the Legendre transform; derive and use Hamilton's equations; identify when $H = T+V$; read phase-space portraits fluently (closed orbits, separatrix, fixed points).

*Theory beats:*
1. Motivation: trade $(q,\dot q)$ for $(q,p)$ — two first-order equations instead of one second-order; and "the object that generates time evolution" is what QM will quantize.
2. Legendre transform gently: geometric picture (describing a convex function by its tangent lines), then the recipe $H(q,p) = p\dot q - L$ with $\dot q$ eliminated via $p = \partial L/\partial\dot q$. One fully-worked scalar example before any mechanics.
3. Hamilton's equations derived from $dH$; symmetry of the pair; check on the oscillator: $H = p^2/2m + \tfrac12 k_s q^2$ → recover SHM.
4. When $H = T + V$: yes for natural systems with time-independent constraints; one-sentence caution (rotating frames break it) without a full treatment.
5. Phase space: state $(q,p)$ as a point; motion as a flow. Oscillator → nested ellipses (area ↔ energy); pendulum → the full portrait: libration ovals, rotation bands, the separatrix through the unstable equilibrium, and what the separatrix *means* (infinite-period boundary).
6. Liouville teaser, one paragraph: Hamiltonian flow preserves phase-space area; why this makes phase space the natural home of statistical mechanics (used day 12).
- Misconceptions: "$H$ is always the energy" (usually, with stated conditions — but it's *defined* by the transform, not by being $T+V$); "phase-space trajectories can cross" (they can't — determinism; crossing would mean two futures from one state).

*Worked examples:* (1) full Legendre-transform construction of $H$ for the oscillator + Hamilton's equations solved; (2) pendulum $H(\theta, p_\theta)$: compute the separatrix energy, classify motion above/below it; (3) particle in gravity: $H$, equations, phase portrait (parabolic flow).

*Simulation section:* run `python3 code/day10_phase_space.py`; predict-prompts: "pick an energy just above the separatrix — describe the trajectory before running", "double the pendulum length — which features of the portrait move and which are unchanged?", "why do no two streamlines ever cross?"

*Exercises:* Retrieval: (1) derive Hamilton's equations from $H = p\dot q - L$ closed book; (2) construct $H$ for $L = \tfrac12 m\dot x^2 - \tfrac12 k_s x^2$ and verify Hamilton's equations reproduce SHM. Standard: (3) $H$ for a bead on a parabolic wire $y = ax^2$ (Legendre transform with a position-dependent mass term); (4) sketch (described in words/coordinates) the phase portrait of $V(x) = x^4 - 2x^2$ from day 2 — including the figure-eight separatrix. Stretch: (5) relativistic-flavored $L = -mc^2\sqrt{1-\dot x^2/c^2}$: compute $p$, then $H$, and recognize $H = \sqrt{p^2c^2 + m^2c^4}$ (flag: this expression returns in day 14's Compton discussion).

*Connection to QM:* the course's fundamental equation is $i\hbar\,\partial_t|\psi\rangle = \hat H|\psi\rangle$ — today's $H$ with hats on. Writing $H = p^2/2m + V$ and promoting $p \to -i\hbar\,\partial_x$ is literally how day 16 builds the Schrödinger equation. Energy eigenstates, level spacings, time evolution: all properties of $\hat H$.

- [ ] **Step 2: Write `code/day10_phase_space.py`** per Global Constraints. Two panels: (a) oscillator phase portrait — streamplot or quiver of $(\dot q, \dot p)$ field plus 4 nested energy ellipses drawn analytically; (b) pendulum phase portrait — contour plot of $H(\theta,p_\theta)$ over $\theta\in[-2\pi,2\pi]$ with the separatrix contour highlighted in a distinct color/width, libration and rotation contours labeled via title/legend.

- [ ] **Step 3: Run `python3 code/day10_phase_space.py`** — expect clean run, separatrix visibly distinct, no trajectory crossings.

- [ ] **Step 4: Run the per-day verification checklist**; fix failures.

---

