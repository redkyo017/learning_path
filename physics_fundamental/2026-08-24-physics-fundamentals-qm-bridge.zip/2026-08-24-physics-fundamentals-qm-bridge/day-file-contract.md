**Day-file anatomy (every `content/dayXX.md`, in this order):**
1. `# Day N — <Title>` then `## Learning objectives` — "By the end of today you should be able to:" + 4–7 concrete, testable bullets, then a stated time budget line (e.g., "Time budget: ~3 hours").
2. `## Reference material` — 2–4 bullets: which standard text chapter matches (Halliday/Resnick, Morin, French's *Vibrations and Waves*, Eisberg–Resnick, Griffiths QM as appropriate per day), a note that the file is self-contained, and pointers to prior days it builds on.
3. `## Theory` — narrative-with-derivations. Every named equation is derived or physically motivated in-line, never dropped in. Use `###` subsections. Include the day's **common-misconception callouts** as blockquotes beginning `> **Misconception:**` (at least 2 per day) placed where they bite.
4. `## Worked examples` — 2–3 fully worked, numbered, each with a bold one-line statement then complete solution including numbers where relevant.
5. `## Exercises` — 4–6 problems, numbered continuously, grouped under three bold tier labels: **Retrieval** (1–2 problems: state/derive/verify things from today's theory), **Standard** (2–3 problems: apply today's tools to new setups), **Stretch** (1 problem: combines today with a prior day or pushes one step further). Open with the house line: "Attempt every problem closed-book before checking the Hints, and only then the Solutions."
6. `## Hints` — one short hint per exercise, numbered to match. A hint names the tool or first move ("write energy conservation between the top and the turning point") without giving the answer.
7. `## Solutions` — full solution sketch per exercise, numbered to match: the key steps and the final answer, in the style of `quantum_computing_foundations/content/day03.md`'s Solutions section (complete but compressed — no skipped logical steps, no essay padding).
8. `## Connection to QM` — closing section, 1–3 paragraphs: exactly what this day buys in the QM course, naming the course concepts it unlocks.
9. Days with a simulation add `## Simulation` between Worked examples and Exercises: what to run (`python3 code/<file>.py`), what to look at, and 2–3 "now change this parameter and predict before you run" prompts.

**Formatting/notation conventions (used identically in all 18 files):**
- Math: `$...$` inline, `$$...$$` display, matching the house style of `quantum_computing_foundations/content/day03.md`.
- Symbols: $x, v, a$ kinematics; $\omega$ angular frequency; $\omega_0$ natural frequency; $k$ wave number (spring constant is $k_s$ wherever both could collide, i.e., days 3, 5, 16, 17); $V(x)$ potential energy; $T$ kinetic energy in analytical-mechanics days 9–11 (elsewhere $K$); $L$ Lagrangian in days 9–11, angular momentum elsewhere (each of days 9–11 states this explicitly on first use); $\mathcal{L}$ is NOT used; $H$ Hamiltonian; $\{f,g\}$ Poisson bracket; $\hbar$, $h$; $\psi$ wavefunction; Jones vectors as 2-component column vectors with $|H\rangle, |V\rangle$ labels.
- Problems must be solvable from that day's content plus prior days only — no forward references, no outside material.
- Target length per day file: 350–600 lines (the quantum path's heavy days run ~370; phase-5 days may reach 600 with solutions).

**Simulations (all 7):**
- numpy + matplotlib only. No scipy, no animation libraries (use multi-panel snapshots instead of animation).
- ≤150 lines each, single file, runs clean via `python3 code/<file>.py` with no arguments, ends with `plt.show()`.
- Header docstring: one-line purpose, then 2–3 "TWEAK:" lines naming parameters to change and what to expect.
- Where numerical integration is needed, use the Euler–Cromer method (semi-implicit Euler): `v += a(x)*dt; x += v*dt` — stable for oscillatory systems, no scipy dependency.

**Per-day verification checklist (run for every day file before calling its task done):**
1. All anatomy sections present, in order, correctly headed.
2. Every named equation in Theory is derived or explicitly motivated ("we take from experiment...").
3. Exercise count 4–6; tiers labeled; hints don't spoil; every exercise has a matching hint AND solution; solutions actually solve the stated problem.
4. Exercises use only this day + prior days.
5. Notation matches the conventions block above.
6. ≥2 `> **Misconception:**` callouts.
7. Time budget stated and plausible: ~3h for days 1–4, ~3.5h for days 5–15, ~4h for days 16–18.
8. Sim days: script exists, runs clean, `## Simulation` section present with predict-before-run prompts.

---
