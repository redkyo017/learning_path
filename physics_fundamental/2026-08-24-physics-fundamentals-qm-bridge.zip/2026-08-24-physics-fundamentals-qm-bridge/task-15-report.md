# Task 15 Report — Day 14: Atoms, Spectra, and Atom–Light Interaction

## File
`physics_fundamental/content/day14.md` — 565 lines (target 350–600; no
trimming needed, relativity teaser kept in full).

## Sections written (anatomy, in order)
1. Learning objectives (5 bullets, time budget "~3.5 hours")
2. Reference material (Eisberg–Resnick as primary text; Demtröder/Fox for
   laser material; self-contained note; pointers to days 4, 8, 12, 13)
3. Theory — 8 numbered `###` subsections following the brief's beat order:
   1. Rutherford's classical death sentence (Larmor radiation, ~10⁻¹¹ s
      collapse quoted, not derived)
   2. Spectral lines / Balmer numerology (stated as empirical pattern)
   3. Bohr's postulates + full derivation of $r_n$, $E_n=-13.6\,\text{eV}/n^2$,
      Balmer recovered, reduced-mass one-liner cashing in day 4
   4. Why Bohr is wrong-but-useful
   5. Two-level atom: absorption/spontaneous/stimulated defined, copy
      property stated exactly
   6. Einstein equilibrium argument — full derivation: detailed balance +
      Boltzmann (day 12) + high-T limit → $B_{12}=B_{21}$; match to
      Planck's law (day 13) → $A_{21}/B_{21}=8\pi hf^3/c^3$; moral stated
      (spontaneous emission thermodynamically forced to exist)
   7. Laser in one page: two-level no-lasing argument, three/four-level
      fix, cavity as mode selector (day 6), coherence from copying
   8. Relativity teaser (explicitly labeled): $E=mc^2$, $p=h/\lambda$ from
      day 10's $H=\sqrt{p^2c^2+m^2c^4}$ massless limit, Compton formula
      stated (not derived) and motivated via billiard-collision picture
4. Worked examples (4, per brief): Bohr numbers for n=1; Balmer α (656 nm);
   Einstein-relations derivation walked as an argument; Compton at 0.1 nm,
   90°
5. Exercises (5: 2 retrieval, 2 standard, 1 stretch), house line used
   verbatim
6. Hints (5, non-spoiling, name the first move)
7. Solutions (5, full derivations, compressed but complete)
8. Connection to QM (two-level atom = photonics qubit; Rabi oscillations
   as coherent version of rate-equation story; $L=n\hbar$ as first
   appearance of angular-momentum quantization)

No `## Simulation` section — day 14 is not a sim day per the brief.

## Checklist results
1. Anatomy sections present, correctly ordered — pass.
2. Every named equation derived or motivated in-line — pass (Larmor
   collapse quoted as fact; Balmer stated as empirical pattern awaiting
   mechanism; Bohr $r_n$/$E_n$ fully derived; Einstein $B_{12}=B_{21}$ and
   $A/B$ fully derived; Planck form cited to day 13 with motivating
   clause; $p=h/\lambda$ derived from $E=pc$ + $E=hf$; Compton formula
   explicitly labeled stated-not-derived per brief).
3. Exercise count 5 (within 4–6), tiers bold-labeled, every exercise has
   a matching non-spoiling hint and a solving solution — pass.
4. Exercises use only day 14 + prior days (12, 13; no forward refs) —
   pass.
5. Notation: $f$ for frequency throughout (matches day 13); $L$ flagged
   explicitly as angular momentum, not Lagrangian — pass.
6. 2 `> **Misconception:**` callouts present (electrons-orbit-like-planets
   near Bohr section; stimulated-emission-is-exotic near the two-level
   section) — pass.
7. Time budget "~3.5 hours" stated, matches days 5–15 convention — pass.
8. Not a sim day — N/A.

## Exercise verification (worked myself, closed-book style)
1. $E_n$ re-derivation: centripetal force + $L=n\hbar$ → $r_n=n^2a_0$ →
   $E_n=-\tfrac12 k_ee^2/r_n=-13.6\,\text{eV}/n^2$. Confirmed via the
   equivalent closed form $E_n=-\tfrac12 m_ec^2\alpha^2/n^2$ (not shown in
   file, used only as a private cross-check): $\tfrac12(511{,}000\,
   \text{eV})(1/137.036)^2\approx13.6\,\text{eV}$. Matches.
2. Three processes correctly mapped to $B_{12}$ (absorption), $A_{21}$
   (spontaneous), $B_{21}$ (stimulated).
3. Ionization frequencies: from $n=1$, $13.6\,\text{eV}\to
   3.29\times10^{15}\,\text{Hz}$; from $n=2$, $3.4\,\text{eV}\to
   8.22\times10^{14}\,\text{Hz}$ (exactly 1/4 of the first, as expected
   since energy scales as $1/n^2$).
4. Ratio $=1/(e^{hf/k_BT}-1)$. Visible ($hf\approx2\,\text{eV}$, $T=300\,
   \text{K}$, $k_BT\approx1/40\,\text{eV}$): $hf/k_BT\approx80$, ratio
   $\approx e^{-80}$ — utterly negligible (order $10^{-35}$), consistent
   with the brief's "~$e^{-77}$" order of magnitude for visible light.
   Microwave (10 GHz): $hf/k_BT\approx1.66\times10^{-3}$, ratio
   $\approx1/x\approx604$ — order hundreds, matching the brief's
   expectation.
5. Two-level rate argument: $dN_2/dt=N_1Bu-N_2Bu-N_2A=0$ at steady state
   $\Rightarrow N_1-N_2=N_2A/(Bu)\ge0$ for all $u>0$ — no inversion
   possible via the same transition, confirming the brief's expected
   result.

Worked-example numbers cross-checked: Bohr $n=1$ ($a_0=5.29\times10^{-11}
\,\text{m}$, $E_1=-13.6\,\text{eV}$, $v_1\approx2.19\times10^6\,
\text{m/s}\approx0.0073c$); Balmer α $=656\,\text{nm}$ (matches known
Hα); Compton at 0.1 nm/90°: $\Delta\lambda=2.43\,\text{pm}$,
$\lambda'=102.43\,\text{pm}$, electron recoil KE $\approx294\,\text{eV}$.

## Concerns
- None blocking. Days 12 and 13 (`content/day12.md`, `content/day13.md`)
  did not yet exist in the repo at write time (only day01–day11 present);
  per instructions I did not read them and relied solely on the facts
  given in the task brief (Boltzmann $N_2/N_1=e^{-\Delta/k_BT}$,
  $k_BT\approx1/40\,\text{eV}$; $E=hf$; Planck's spectral form). If those
  files, once written, use different symbols or a different Planck-law
  normalization, a quick consistency pass against day14's Section 6 may
  be worth doing later.
- No git commands were run at any point, per hard constraint.
