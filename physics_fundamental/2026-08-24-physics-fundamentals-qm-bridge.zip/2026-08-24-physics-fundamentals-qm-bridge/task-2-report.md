# Task 2 Report — Day 1: Newton as Differential Equations

File created: `physics_fundamental/content/day01.md` (480 lines, within the
350–600 target).

## Sections written (anatomy, in order)

1. `# Day 1 — Newton as Differential Equations`
2. `## Learning objectives` — 7 testable bullets + "Time budget: ~3 hours."
3. `## Reference material` — Morin Ch. 1–3 / Halliday-Resnick-Walker Ch. 2–3,
   5–6; self-contained note; note that Day 1 has no prior-day dependencies
   and is itself the foundation days 5, 9, 12, 16 build on.
4. `## Theory` — six `###` subsections in the brief's order:
   - Kinematics as definitions, not laws
   - Newton's three laws, and the master ODE (boxed framing)
   - Constant force: integrating twice, and projectile motion (incl. range
     formula derivation, vacuum-fall aside)
   - Linear drag: terminal velocity and the exponential approach (boxed
     result)
   - Spring force preview: the ODE that gets its own day
   - Dimensional analysis as a checking habit (worked micro-example)
5. `## Worked examples` — 3 numbered: projectile range + optimal angle;
   raindrop terminal velocity/time constant; incline with kinetic friction.
6. `## Exercises` — 5, tiered **Retrieval** (1–2), **Standard** (3–4),
   **Stretch** (5), opening with the required closed-book line.
7. `## Hints` — 5, one per exercise, non-spoiling (name the tool/first move).
8. `## Solutions` — 5, full worked sketches with final numeric answers.
9. `## Connection to QM` — 3 paragraphs (Schrödinger-as-F=ma analogy;
   exponential-approach pattern reappearing as $e^{-iEt/\hbar}$; dimensional
   analysis habit transfer).

No `## Simulation` section — Day 1 has no simulation per the brief.

## Checklist results (day-file-contract.md, item by item)

1. **Anatomy present, in order, correctly headed** — PASS (verified via
   `grep -n '^#'`; matches required order exactly).
2. **Every named equation derived or motivated** — PASS. $v=\dot x$,
   $a=\ddot x$ motivated as definitions; $m\ddot x=F$ stated as the second
   law; constant-force $v(t)$, $x(t)$ derived by direct integration;
   projectile ODEs and range formula $R=v_0^2\sin(2\theta)/g$ derived;
   drag ODE $m\dot v=mg-bv$ solved by separation to
   $v(t)=v_{\rm term}(1-e^{-t/\tau})$; spring ODE $m\ddot x=-k_sx$
   physically motivated (restoring force) though explicitly deferred, per
   brief; dimensional-analysis check worked on the range formula.
3. **Exercise count/tiers/hints/solutions** — PASS. 5 exercises (within
   4–6), tiers bold-labeled, every exercise has exactly one matching hint
   and one full solution; hints checked to name only the first move/tool,
   not the answer; solutions verified to actually solve the stated problem
   (see exercise-by-exercise verification below).
4. **Exercises use only this day + prior days** — PASS (day 1 has no prior
   days; every exercise draws only on today's constant-force integration,
   linear-drag separation-of-variables, $F=ma$ algebra, or dimensional
   analysis).
5. **Notation matches conventions** — PASS. $x,v,a$ for kinematics; $k_s$
   used for the spring constant (matches brief's own notation, consistent
   with days 3/5/16/17's convention); no clashing use of $T$, $L$, $H$, etc.
   ($T$ is used only for Atwood-machine tension, standard and non-clashing).
6. **≥2 misconception callouts** — PASS. Exactly 2: "no force means no
   motion" (placed right after the first/second law statement) and
   "heavier objects fall faster" (placed right after the drag/terminal-
   velocity derivation, explicitly contrasting vacuum vs. air).
7. **Time budget stated and plausible** — PASS. "~3 hours" stated, correct
   for a day-1–4 file per the contract.
8. **Sim days: script + section** — N/A, no simulation this day.

## Exercise-by-exercise solution verification (worked independently)

1. **Retrieval — state the three laws.** First law: $\sum F=0\Rightarrow
   \dot v=0$; Second law: $F=ma$ (i.e. $m\ddot x=F$); Third law:
   $\vec F_{1\to2}=-\vec F_{2\to1}$. Correct by definition/statement.
2. **Retrieval — dimensional check of $v_{\rm term}=mgb$.** $[b]=MT^{-1}$
   from $F=bv$; $[mgb]=M^2LT^{-3}\ne LT^{-1}$ — dimensionally impossible,
   confirms the proposed formula is wrong; correct structure is $mg/b$
   ($[mg/b]=LT^{-1}$, checks out). **Final answer: $mgb$ is wrong; correct
   dimensional form divides by $b$.**
3. **Standard — two-stage thrust-then-coast.** Stage 1: $a_1=F/m=10\,{\rm
   m/s^2}$, $v_1=v(2\,{\rm s})=20\,{\rm m/s}$, $x_1=20\,$m. Stage 2 (pure
   drag, $\tau=m/b=2\,$s): $v(4\,{\rm s})=20e^{-1}\approx7.36\,$m/s,
   coast distance $=v_1\tau(1-e^{-1})\approx25.3\,$m. **Final answer:
   $v(4\,{\rm s})\approx7.36\,$m/s; total distance $\approx45.3\,$m.**
   Recomputed independently — matches.
4. **Standard — Atwood machine, $m_1=2$, $m_2=3$ kg.** $a=(m_2-m_1)g/
   (m_1+m_2)=9.8/5=1.96\,{\rm m/s^2}$; $T=2m_1m_2g/(m_1+m_2)=23.52\,$N,
   cross-checked via both mass equations ($m_1(a+g)$ and $m_2(g-a)$, both
   give $23.52\,$N). **Final answer: $a\approx1.96\,{\rm m/s^2}$,
   $T\approx23.5\,$N.**
5. **Stretch — quadratic drag.** Separation gives $v(t)=v_0/(1+(cv_0/m)t)$;
   verified by direct substitution back into $m\dot v=-cv^2$. Long-time
   behavior $v\sim m/(ct)$ (power-law $1/t$), contrasted against linear
   drag's exponential decay (exponential always eventually beats any power
   law), plus the noted qualitative difference that the quadratic-drag
   time scale $t^*=m/(cv_0)$ depends on $v_0$ while linear drag's $\tau=
   m/b$ does not. **Final answer: $v(t)=v_0/(1+(cv_0/m)t)$, decaying as
   $1/t$ vs. linear drag's $e^{-t/\tau}$.**

All five re-derived independently during review; no discrepancies found.

## Self-review findings

- Re-derived every Theory equation from scratch by hand (kinematics
  definitions, both laws-derived ODE solutions, drag separation-of-
  variables integral, range formula, dimensional check) — all correct.
- Verified the interface-required artifacts are present verbatim/near-
  verbatim: the boxed sentence now reads exactly "**Classical mechanics
  is: given $F(x,v,t)$, solve $m\ddot{x}=F$.**" (edited after first draft
  to match the brief's exact wording character-for-character, so days 5,
  9, 16 can quote it directly); the drag result is boxed as
  $v(t)=v_{\rm term}(1-e^{-t/\tau})$, $\tau=m/b$, matching day 12's reuse.
- Checked worked-example numbers twice each (projectile range/angle,
  raindrop $v_{\rm term}/\tau$, incline acceleration) — all consistent
  between two independent computation routes where a cross-check was
  possible (e.g. range via direct substitution vs. the closed-form
  formula; Atwood tension via both masses' equations).
- Verified math-delimiter balance (`$$` occurrences even, total `$`
  occurrences even) and absence of TBD/TODO/placeholder text.
- Initial draft was written as long unwrapped paragraph lines (211 lines
  despite ~4,200 words of content); rewrapped programmatically to ~78-
  column lines matching the house exemplar's wrap width, bringing the
  file to 480 lines — a pure formatting pass, no content was added,
  removed, or altered by the rewrap (verified by reading the rewrapped
  file in full afterward).

## Concerns

None outstanding. One judgment call worth flagging: the brief's
Worked-Example list item (1) "maximize over θ" is treated as part of
Worked Example 1 (with the derivative argument done there) rather than in
Theory, since Theory beat 3 only asked to "derive the range formula" —
Theory derives $R$, the worked example does the maximization. This keeps
Theory from front-running content the brief placed in the worked-example
list.

---

# Fix Report (post-review pass)

File now 514 lines (still within the 350–600 target). All 11 items from the
coordinator's review applied; no git commands run.

## MUST FIX

**1. Self-containedness gap (Coulomb friction, ideal-string constraints
never introduced).** Added a new paragraph to the Theory section, under
"### Newton's three laws, and the master ODE," right after the "no force
means no motion" misconception callout and before "### Constant force":

> **Building $F$: empirical force laws and constraints.** Not every force
> that goes into $F(x,\dot x,t)$ comes from a fundamental law like gravity.
> Two other ingredients recur constantly when you build a real $F$, and both
> deserve names now, before you meet them in the worked examples below.
> **Constraint forces**, like the normal force $N$ a surface exerts, are not
> given by a formula in advance — their magnitude is whatever value makes
> some other motion impossible (e.g. an object not passing through a rigid
> surface), so you solve for $N$ from that requirement (typically, zero
> acceleration perpendicular to the surface) rather than looking it up.
> **Empirical force laws**, like the linear drag $F_{\text{drag}}=-bv$
> already used above, are rules fit to how a real material behaves rather
> than derived from something more basic; **kinetic friction** is the same
> kind of rule — once two surfaces slide against each other, experiment
> shows the friction force has magnitude $f=\mu_kN$, proportional to the
> normal force pressing the surfaces together and opposing the sliding,
> with $\mu_k$ (the coefficient of kinetic friction) a measured material
> property, exactly the same status as $b$ in the drag law. Finally, an
> **ideal string and pulley** — massless, inextensible, frictionless — is a
> constraint idealization: because the string is massless, $F=ma$ applied
> to any tiny piece of it forces the tension $T$ to be the same all along
> its length (any imbalance on a massless piece would produce infinite
> acceleration); because the string is inextensible and wraps a fixed
> pulley, the two ends must move with equal speed and the same acceleration
> magnitude, $|a_1|=|a_2|$. None of this changes the day's thesis — it
> sharpens it. $F$ in $m\ddot x=F$ is rarely one clean formula read off a
> table; it is often assembled from constraint conditions, experimental
> rules, and idealizations like these, exactly as Worked Example 3 and
> Exercise 4 below do.

(Shown here as a blockquote only for report formatting; in the file it is
plain Theory prose, bold-labeled like "First law."/"Second law."/"Third
law.," not an actual `>` blockquote — blockquotes are reserved for the two
misconception callouts, per fix 8.) This closes the gap: kinetic friction,
the normal force, and the ideal-string/pulley facts used by Worked Example
3 and Exercise 4 are now derived/motivated in Theory before they're used.

## MINOR

**2. L320–321 (incline threshold used $\mu_k$ for a static question).**
Reframed as the condition to keep accelerating once already sliding, not
whether it starts:
> "(This is the condition for the block to keep accelerating once already
> sliding, not a statement about whether static friction lets it start
> moving in the first place: $\tan\phi > \mu_k$ means gravity's pull
> down-slope exceeds what kinetic friction can supply, so the block keeps
> speeding up rather than slowing down; check: $\tan 30^\circ = 0.577 >
> 0.2$, consistent with the acceleration assumed here.)"

**3. L193–196 (63%/95% mixed "remaining distance" vs. total gap).**
Both clauses now reference the same "total gap to $v_{\rm term}$":
> "...closing $1-e^{-1}\approx 63\%$ of the total gap to $v_{\mathrm{term}}$
> by $t=\tau$, and $1-e^{-3}\approx 95\%$ of that same total gap by
> $t=3\tau$, and never (in the model) exactly reaching the asymptote."

**4. L290–293 (raindrop realism overclaim).** Softened:
> "(These numbers were chosen to make the arithmetic clean; a real
> millimetre-scale raindrop is actually in the quadratic-drag regime, which
> you'll meet in Exercise 5, not this linear one — and note the identity
> $v_{\mathrm{term}} = g\tau$...)"

**5. L222–226 ("it doesn't separate" too strong).** Added the requested
qualifying clause:
> "...and it doesn't separate the way the drag equation did — not as a
> first-order equation in $v$ alone, though an energy trick exists that
> Day 2 hints at (the right side depends on $x$, not on $\dot x$...)"

**6. L322–323 (3.20×2≈6.41 arithmetic mismatch).** Carried a third
significant figure through so the displayed multiplication is consistent:
> "$a = \dots \approx 3.203\text{ m/s}^2$" and "$v(2) = 3.203\times 2
> \approx 6.41\text{ m/s}$" (3.203×2 = 6.406 ≈ 6.41, no longer mismatched
> against a rounded 3.20).

**7. L38–39 (forward interface bookkeeping in Reference material).**
Removed the "days 5, 9, 16... day 12 reuses..." aside; now simply:
> "No prior days: this is Day 1 of the path, so there is nothing to build
> on yet — everything below is derived from scratch."

**8. L93 vs L192 (framing sentence in blockquote, drag result in
`\boxed{}`; inconsistent visual treatment).** Framing sentence converted
to the same display-box form:
> "$$\boxed{\text{Classical mechanics is: given } F(x,v,t)\text{, solve }
> m\ddot{x}=F.}$$"
> followed by the explanatory prose as plain paragraph text (no longer a
> blockquote). Blockquotes in the file are now used only for the two
> misconception callouts, confirmed by grepping for lines starting with
> `>` — exactly the two misconception blocks remain.

**9. Exercise 3 / Exercise 4 precision.** Exercise 3 now reads "A particle
of mass $m=1\text{ kg}$, moving horizontally, starts at rest..."; Exercise
4 now reads "...over a massless, frictionless pulley ($g=9.8\text{
m/s}^2$). Using $F=ma$..."

**10. L441–443 (drag result mislabeled "decay" instead of "approach").**
Reordered/relabeled in Solution 5:
> "...a **power-law ($1/t$) decay**, in contrast to linear drag's
> **exponential approach** to a nonzero asymptote,
> $v_{\mathrm{term}}(1-e^{-t/\tau})$ (or, in a no-source-term case like
> Exercise 3's coast phase, an **exponential decay** to zero,
> $v=v_0e^{-t/\tau}$). Either way, an exponential eventually falls below
> any power law..."

**11. Hint 4 (handed over the elimination trick).** Trimmed to point at
the setup, not the algebra move:
> "Draw a free-body diagram for each mass on its own and write Newton's
> second law for each mass separately (the ideal-string discussion in
> Theory tells you both masses share the same tension $T$ and the same
> acceleration magnitude $a$; careful with signs — one mass accelerates
> up, the other down). You now have two equations in the two unknowns $a$
> and $T$."

## Re-verified checklist after edits

1. **Anatomy present, in order** — PASS. No heading was added or removed;
   the new Theory content is prose under the existing "### Newton's three
   laws, and the master ODE" subsection, bold-labeled like the surrounding
   First/Second/Third law text, not a new heading.
2. **Every named equation derived or motivated** — PASS, and the gap is
   now closed: $N$ (constraint reasoning), $f=\mu_kN$ (empirical rule,
   explicitly paralleled to drag's $b$), uniform tension $T$ and
   $|a_1|=|a_2|$ (derived from $F=ma$ on a massless string element and the
   inextensibility/fixed-pulley geometry) are all introduced in Theory
   before Worked Example 3 and Exercise 4 use them.
3. **Exercise count/tiers/hints/solutions** — PASS, unchanged: 5 exercises,
   tiers intact, every exercise still has exactly one hint and one
   solution; Hint 4 re-checked non-spoiling (states the setup, withholds
   the elimination step).
4. **Exercises use only this day** — PASS, strengthened: Exercise 4 and
   Worked Example 3 now draw on Theory-introduced friction/constraint
   content instead of outside knowledge.
5. **Notation matches conventions** — PASS. New symbols ($N$, $f$,
   $\mu_k$, $T$ for tension) are standard and non-clashing with the day's
   symbol table.
6. **≥2 misconception callouts, blockquotes reserved for them** — PASS.
   Confirmed via `grep -n '^>'`: exactly the two misconception blocks are
   blockquoted; the framing sentence is no longer a blockquote.
7. **Time budget stated and plausible** — PASS, unchanged: "Time budget:
   ~3 hours."
8. **Sim days** — N/A, no simulation this day.
9. **Line count** — PASS: 514 lines, within 350–600 after the new Theory
   paragraph.

No new arithmetic was introduced without being checked: the Worked
Example 3 / Exercise-4-adjacent numbers were re-verified ($a\approx
3.203\,{\rm m/s^2}$, $v(2)\approx6.41\,{\rm m/s}$; Atwood $a\approx1.96\,
{\rm m/s^2}$, $T\approx23.5\,$N — unchanged by this pass, only the
friction-threshold framing and the displayed-precision issue were fixed).

## Concerns

None outstanding.
