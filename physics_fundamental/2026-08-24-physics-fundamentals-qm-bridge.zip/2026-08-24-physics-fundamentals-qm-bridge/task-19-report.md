# Task 19 report — Day 18: The Rosetta Stone

**File:** `physics_fundamental/content/day18.md`, 593 lines (target 350–600).

## Sections (anatomy order, verified via grep)
1. `# Day 18 — The Rosetta Stone`
2. `## Learning objectives` — 7 bullets + "Time budget: ~4 hours."
3. `## Reference material` — 4 bullets (Griffiths, Nielsen & Chuang, Hecht, self-contained/cross-reference note).
4. `## Theory` — subsections: the dictionary (8-row table + row-by-row commentary), Day 11's table reprinted, two-level truncation, photonic qubit #1 (polarization), photonic qubit #2 (MZ as circuit), the course map. 2 `> **Misconception:**` blockquotes (wave/matrix mechanics same theory; photon-splits-vs-amplitude-splits).
5. `## Worked examples` — 3 numbered: (1) full MZ matrix product symbolic + φ=0,π/2,π; (2) two-level truncation on the box with a weak coupling, diagonalized; (3) QWP on |H⟩ vs. diagonal input.
6. `## Readiness self-test` — replaces Exercises tiers, labeled as such; 12 questions in the brief's exact distribution (2 mechanics, 2 waves, 2 analytical, 2 quantum evidence, 2 wave mechanics, 2 bridge); pass bar "9/12 unaided" stated up front.
7. `## Hints` — 12, one per question, no spoilers.
8. `## Solutions` — 12, compressed sketch level, each ending with "(If missed: revisit Day N...)".
9. `## Connection to QM` — "What you can now do" + standing instruction to re-read Day 11 after course week 2.

No `## Simulation` section (not required/requested for Day 18).

## MZ verification (hand-checked, all three φ)
Matrix product $M P(\phi) M \lvert0\rangle$ with $M=\frac{1}{\sqrt2}\begin{pmatrix}1&1\\1&-1\end{pmatrix}$, $P(\phi)=\mathrm{diag}(1,e^{i\phi})$:
- Result: $\frac12\binom{1+e^{i\phi}}{1-e^{i\phi}}$, giving $P_1=\cos^2(\phi/2)$, $P_2=\sin^2(\phi/2)$.
- φ=0: state → (1,0)ᵀ, P₁=1, P₂=0 — port 1 fully bright. Matches Day 6.
- φ=π/2: (1+i, 1−i)/2, P₁=P₂=½. Matches Day 6.
- φ=π: state → (0,1)ᵀ, P₁=0, P₂=1 — ports fully reversed. Matches Day 6.
Port labels (port 1 = cos², bright at φ=0) match Day 6 exactly; the symmetric-matrix variant is noted in one sentence per the controller ruling, correctly flagged as swapping port roles (verified separately: with M'=(1/√2)[[1,i],[i,1]], port 1 becomes the sin² port).

## Table-reprint diff check
`sed -n '199,205p' day11.md` vs. the reprinted table in day18.md (including the "for f with no explicit t" caveat row): `diff` returns no differences — byte-for-byte identical.

## Self-test verification (final answers, all hand-recomputed)
1. Turning points x=±0.71 m, bound SHM.
2. ω₀ ≈ 11.2 rad/s (k_s=V₀/a²=12.5 N/m).
3. f₁=62.5 Hz, f₂=125 Hz, f₃=187.5 Hz.
4. v_g=450 m/s, v_p=350 m/s.
5. H = p²/(2m) + mg sinθ·s.
6. {x²,p} = 2x.
7. ⟨E⟩ ≈ 1.68×10⁻²¹ J ≈ 40% of k_BT.
8. KE_max ≈ 1.10 eV, V_stop ≈ 1.10 V.
9. E₁=0.0941 eV, E₂=0.376 eV, E₃=0.847 eV.
10. KE estimate ≈ 0.0024 eV vs. exact E₁=0.0941 eV — ratio checked to be exactly 4π² (≈39.5), explained in the solution as the minimum-uncertainty bound vs. the true ground-state spread.
11. P₁=0.25, P₂=0.75 at φ=2π/3 — cross-checked against the general matrix-product formula.
12. Born-rule probability ≈0.933, cross-checked against Malus's law with the 15° angle between the two states — both methods agree.
All 12 solutions independently recomputed and match the stated answers.

## Checklist (day-file-contract, per-day verification)
1. Anatomy sections present, in order, correctly headed — pass.
2. Every named equation derived/motivated in-line — pass (dictionary rows explained one by one; two-level truncation, MZ, QWP all derived, not dropped in).
3. "Exercise" tier substitute: 12 self-test questions, each with matching hint and solution, solutions verified to solve the stated problems — pass (grep confirms 12/12/12).
4. Self-test uses only this path's prior days (1–17) plus today — pass; no forward references introduced.
5. Notation matches conventions (no period symbol, no ℒ, Jones-vector labels, ħ/h, etc.) — pass; spot-checked.
6. ≥2 `> **Misconception:**` callouts — pass, exactly 2 (the brief's two mandated ones).
7. Time budget stated and plausible for a day-16–18 file (~4h) — pass.
8. Not a simulation day — N/A, no `## Simulation` section, consistent with brief (none requested).

## Cross-reference verification (Step 2 of brief)
Confirmed via `head` on the actual files that all four exist with the exact claimed titles:
- `quantum_computing_foundations/content/day03.md` → "Complex Vector Spaces & the Qubit"
- `day04.md` → "Normal Matrices, Spectral Theorem, Single-Qubit Unitaries & the Bloch Sphere"
- `day06.md` → "Measurement, the Born Rule & Density Matrices"
- `day07.md` → "Multi-Qubit States, Entanglement & No-Cloning"
No other QCF files were referenced.

## Concerns
- Days 16 and 17 of `physics_fundamental/content/` do not yet exist on disk (only day01–day15 are present); day18 cites their pinned facts (box E_n, φ_n, Born rule, QHO ladder, uncertainty) per the controller's instruction not to read them, so this is expected given the plan's task ordering, but it means day18's self-test "revisit Day 16/17" pointers cannot be smoke-tested against the actual files yet.
- The self-test's per-question "revisit day N" mapping (e.g., Day 12 = Planck, Day 13 = photoelectric, Day 9–11 = analytical mechanics) was inferred from the brief's category labels and the pinned facts for Days 6, 8, 11, 14, 16, 17; it is internally consistent with everything pinned but was not verified against the actual unread day files for topics outside the pinned set (Days 1–5, 7, 9, 10, 12, 13).
- No git commands were run, per instructions.
