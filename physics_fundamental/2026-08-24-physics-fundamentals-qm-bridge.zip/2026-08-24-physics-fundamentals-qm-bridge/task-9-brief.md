### Task 9: Day 8 — Light and Polarization as a Two-State System

**Files:**
- Create: `content/day08.md`

**Interfaces:**
- Consumes: day 5's wave equation, day 6's superposition.
- Produces: Jones-vector conventions — $|H\rangle = \binom{1}{0}$, $|V\rangle=\binom{0}{1}$, diagonal $\tfrac{1}{\sqrt2}\binom{1}{1}$, circular $\tfrac{1}{\sqrt2}\binom{1}{\pm i}$ — and Malus's law $I = I_0\cos^2\theta$. Day 18 builds the polarization qubit from exactly these.

- [ ] **Step 1: Draft `content/day08.md` (~3.5h day) with this content brief:**

*Learning objectives:* say what each Maxwell equation means physically; describe an EM wave's anatomy and why $c$ is forced; compute with Jones vectors; derive Malus's law; explain wave plates' action on polarization states.

*Theory beats:*
1. Fields as physical objects: $\vec E$ and $\vec B$ defined by the force law $\vec F = q(\vec E + \vec v\times\vec B)$; fields carry energy and momentum.
2. The four Maxwell equations, each in one sentence of physics (what it says, what it forbids): Gauss (charges source E), no monopoles, Faraday (changing B makes E), Ampère–Maxwell (currents and changing E make B). NO PDE manipulation — state that the wave solution follows from combining the last two, and quote $c = 1/\sqrt{\mu_0\varepsilon_0}$ with the numerical punchline (compute it: it equals the measured speed of light — "light is an electromagnetic wave" was a *calculation* before it was a doctrine).
3. EM wave anatomy: $\vec E \perp \vec B \perp \vec k$, in phase, $|E|=c|B|$; intensity $\propto E_0^2$.
4. Polarization as the direction of $\vec E$: linear, and then circular as two linears $90°$ out of phase.
5. **Jones vectors:** polarization state = normalized 2-component complex vector; the four standard states listed above; polarizer as a projection; general rotation. Make the punchline explicit: "polarization is a 2-dimensional complex vector space — the same arena as the qubit you met in the quantum computing path."
6. Malus's law derived as projection-then-square: $I = I_0\cos^2\theta$.
7. Wave plates conceptually: birefringence delays one component; quarter-wave plate turns diagonal into circular (show it with Jones vectors — one line).
8. *Consolidation survey* (labeled, one paragraph each): DC circuits (what V, I, R are and Kirchhoff in words); geometric optics (rays, lenses, images — why we skip it: QM needs wave optics, not ray optics).
- Misconceptions: "polarizers act as sieves passing aligned light unchanged" (they *project*: transmitted light is re-aligned to the polarizer axis — this is why the three-polarizer puzzle works); "circular polarization is a mixture of H and V" (it's a coherent superposition with a definite phase — mixture vs. superposition, flagged as a preview of a central course distinction).

*Worked examples:* (1) the three-polarizer puzzle: $0°$ then $90°$ blocks all; insert $45°$ between them → $I_0/8$ passes — computed via successive Malus projections; (2) quarter-wave plate on diagonal input: Jones-vector computation ending in circular; (3) laser-pointer photon flux: 1 mW at 650 nm → photons/second (uses $E=hf$ with a forward flag to day 13; label as an estimate).

*Exercises:* Retrieval: (1) match each Maxwell equation to its one-sentence meaning, closed book; (2) verify the circular Jones vector is normalized and orthogonal to the opposite circular. Standard: (3) Malus cascade: N polarizers each rotated $90°/N$ — transmitted fraction, and its $N\to\infty$ limit; (4) decompose diagonal polarization in the H/V basis and in the ±45° basis. Stretch: (5) show that ANY normalized Jones vector can be written as $\alpha|H\rangle + \beta|V\rangle$ with $|\alpha|^2+|\beta|^2=1$, and explain in one paragraph why the global phase of the vector has no physical meaning for intensity measurements.

*Connection to QM:* Malus's law IS the Born rule for the polarization qubit ($\cos^2\theta$ = transition probability); the three-polarizer puzzle is your first non-commuting-measurements phenomenon; wave plates are single-qubit unitaries you can hold in your hand. Your course's photonics experiments live in exactly this formalism.

- [ ] **Step 2: Run the per-day verification checklist**; fix failures.

---

