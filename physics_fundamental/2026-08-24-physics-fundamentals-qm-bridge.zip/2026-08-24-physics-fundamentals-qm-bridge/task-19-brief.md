### Task 19: Day 18 — The Rosetta Stone

**Files:**
- Create: `content/day18.md`

**Interfaces:**
- Consumes: essentially everything — by name: day 6 (MZ laws), day 8 (Jones vectors, Malus), day 11 (dictionary table), day 14 (two-level atom), day 16 (box eigenstates, Born rule), day 17 (QHO/photons); plus, read-only, `quantum_computing_foundations/content/day03.md` (complex vector spaces & the qubit), `day04.md` (unitaries & Bloch sphere), `day06.md` (measurement, Born rule & density matrices), `day07.md` (multi-qubit & entanglement).
- Produces: the finished path; the readiness self-test.

- [ ] **Step 1: Draft `content/day18.md` (~4h day) with this content brief:**

*Learning objectives:* translate fluently between wave mechanics and Dirac/matrix formalism; realize a qubit three ways (truncated well, polarization, MZ paths); read a Mach–Zehnder as a single-qubit circuit; locate every upcoming course topic on this path's map; pass the readiness self-test.

*Theory beats:*
1. **The dictionary**, as a full two-column table with a worked row-by-row commentary: $\psi(x)$ | $|\psi\rangle$; $\int \phi_n^*\psi\,dx$ | $\langle n|\psi\rangle$; $\int|\psi|^2dx=1$ | $\langle\psi|\psi\rangle=1$; operators $-i\hbar\partial_x$ | matrices; TISE $\hat H\phi_n = E_n\phi_n$ | eigenvalue problem $H|n\rangle = E_n|n\rangle$; expansion $\psi = \sum c_n\phi_n$ | $|\psi\rangle = \sum c_n|n\rangle$; $|c_n|^2$ | Born rule; $e^{-iEt/\hbar}$ phases | unitary evolution $U = e^{-iHt/\hbar}$. Cross-reference: "the right-hand column is precisely the formalism of `quantum_computing_foundations` days 3–6 — re-skim day03's inner-product section with today's left column in mind."
2. Also reprint day 11's classical↔quantum table (Poisson→commutator) beneath it: the two tables together are the whole conceptual map.
3. **Two-level truncation:** take the box's lowest two levels, ignore the rest (justified when energies/drives only reach those two) → states $\alpha|1\rangle + \beta|2\rangle$, all observables $2\times2$ matrices → the qubit; the same truncation on an atom = day 14's two-level atom; "a qubit is not a thing — it's any quantum system you've agreed to use two levels of."
4. **Photonic qubit #1 — polarization:** day 8's Jones vectors REREAD as qubit states: $|H\rangle,|V\rangle \to |0\rangle,|1\rangle$; wave plates = single-qubit unitaries (give the quarter-wave plate's $2\times2$ matrix); Malus = Born rule (the sentence from day 8, now with full context); polarizing beam splitter = measurement in the H/V basis.
5. **Photonic qubit #2 — the Mach–Zehnder as a circuit:** which-path as the qubit basis (upper/lower arm = $|0\rangle/|1\rangle$); 50/50 beam splitter as a Hadamard-like $2\times2$ unitary (give the matrix $\frac{1}{\sqrt2}\begin{pmatrix}1 & i\\ i & 1\end{pmatrix}$, note convention variants in one sentence); phase shifter as $\mathrm{diag}(1, e^{i\phi})$; multiply the three matrices → output probabilities $\cos^2(\phi/2), \sin^2(\phi/2)$ — **exactly day 6's intensity laws**, now derived as a quantum circuit. Single-photon reading: one photon, both arms, interferes with itself; detector clicks follow the Born rule.
6. **The course map:** a table of likely course topics (postulates & Dirac formalism; two-level dynamics/Rabi oscillations; harmonic oscillator & quantized light; interferometry & photon statistics; measurement theory; entanglement) with, per row: which days of this path prepared it and which `quantum_computing_foundations` day connects.
7. **Readiness self-test** (replaces the standard exercise tiers, labeled as such): 12 questions spanning the whole path — 2 mechanics (V(x) reading; oscillator $\omega_0$ from a potential), 2 waves (standing-wave quantization; group velocity), 2 analytical (construct an $H$; a Poisson bracket), 2 quantum evidence (Planck's average; photoelectric numbers), 2 wave mechanics (box energies; uncertainty estimate), 2 bridge (MZ matrix product; polarization-qubit Born rule). Each with hint and full solution per house format. Pass bar stated: 9/12 unaided = ready; below that, the per-question solutions name which day to revisit.
- Misconceptions: "wave mechanics and matrix mechanics are different theories" (same theory, different bases — the dictionary is exact); "the photon splits at the beam splitter" (the *amplitude* splits; detection is always whole photons — this distinction is the course's entire measurement chapter in embryo).

*Worked examples:* (1) the full MZ matrix product, symbolic then at $\phi = 0, \pi/2, \pi$; (2) two-level truncation worked: box levels 1–2 with a weak driving term, written as a $2\times2$ matrix problem; (3) quarter-wave plate acting on $|H\rangle$-vs-diagonal inputs via its matrix.

*Connection to QM:* one closing page — "What you can now do": walk into the course able to read $\hat H|\psi\rangle = E|\psi\rangle$ as both a differential equation and a matrix equation, see every interferometer as a circuit, and know where each new topic hangs on the map. Plus the standing instruction: re-read day 11 after course week 2.

- [ ] **Step 2: Verify cross-references:** every `quantum_computing_foundations/content/dayXX.md` file named in day18 exists with the topic claimed (day03 complex vector spaces/qubit; day04 unitaries/Bloch; day06 measurement/Born/density matrices; day07 entanglement).

- [ ] **Step 3: Run the per-day verification checklist** (self-test counts as the exercise tiers: 12 questions, each with hint + solution); fix failures.

---

