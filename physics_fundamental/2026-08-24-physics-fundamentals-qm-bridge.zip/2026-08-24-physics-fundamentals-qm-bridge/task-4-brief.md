### Task 4: Day 3 — The Harmonic Oscillator (deep) + sim

**Files:**
- Create: `content/day03.md`
- Create: `code/day03_oscillator_zoo.py`

**Interfaces:**
- Consumes: day 2's $V(x)$ minima and small-oscillation preview.
- Produces: SHM solution conventions $x(t)=A\cos(\omega_0 t+\phi)$, $\omega_0=\sqrt{k_s/m}$; the complex-exponential method $x = \mathrm{Re}[\tilde A e^{i\omega t}]$; the Taylor-expansion-around-a-minimum argument. Days 5, 10, 13, 17 all quote these.

- [ ] **Step 1: Draft `content/day03.md` (~3h day) with this content brief:**

*Learning objectives:* show any potential minimum yields SHM with $\omega_0=\sqrt{V''(x_0)/m}$; solve $\ddot x = -\omega_0^2 x$ completely and fluently, including via complex exponentials; describe energy sloshing $K\leftrightarrow V$; classify damped regimes; explain resonance and Q qualitatively and quantitatively.

*Theory beats:*
1. Universality: Taylor-expand $V$ about a minimum, drop the constant, kill the linear term (it's a minimum) → $V \approx \tfrac12 V''(x_0)(x-x_0)^2$ → every small oscillation is SHM. Box $\omega_0 = \sqrt{V''(x_0)/m}$.
2. Full solution of $\ddot x = -\omega_0^2 x$: general solution, amplitude/phase form, fixing constants from initial conditions.
3. The complex-exponential method: guess $e^{i\omega t}$, connect to the learner's linear-algebra/quantum background explicitly ("the same $e^{i\theta}$ machinery as qubit phases").
4. Energy: $E = \tfrac12 m\dot x^2 + \tfrac12 k_s x^2$ constant; K and V each oscillate at $2\omega_0$; average equality $\langle K\rangle = \langle V\rangle$.
5. Damping: $\ddot x + 2\beta\dot x + \omega_0^2 x = 0$ via the complex guess → under/critical/over-damped regimes from the discriminant.
6. Driving + resonance: steady-state amplitude $A(\omega_d)$ derived with complex exponentials; resonance peak near $\omega_0$; phase lag behavior (in phase far below, $90°$ at resonance, $180°$ far above); Q factor as ring-down count and as peak sharpness.
- Misconceptions: "resonance means the drive frequency equals $\omega_0$ exactly" (peak shifts with damping; and the $90°$ phase point is $\omega_0$); "damping always reduces amplitude gradually" (overdamped systems don't oscillate at all).

*Worked examples:* (1) $V(x) = V_0[(a/x) + (x/a)]$-style two-term potential (pick one cleanly differentiable): find minimum, compute $\omega_0$ via Taylor; (2) ring-down: given amplitude halves in N cycles, extract $\beta$ and Q; (3) driven oscillator: compute steady-state amplitude at three drive frequencies, locate the peak.

*Simulation section:* run `python3 code/day03_oscillator_zoo.py`; predict-prompts: "halve the damping — how much taller and narrower does the resonance peak get?", "set $\beta > \omega_0$ — predict the shape of $x(t)$ before looking", "double $k_s$ — which way does the resonance peak move?"

*Exercises:* Retrieval: (1) derive $\omega_0=\sqrt{V''/m}$ from Taylor expansion (closed book); (2) verify $x = A\cos\omega_0 t + B\sin\omega_0 t$ solves the SHM ODE and fix A, B from $x(0), \dot x(0)$. Standard: (3) mass between two springs (spring constants $k_1, k_2$) — find $\omega_0$ both in series and parallel arrangements; (4) pendulum period from Taylor-expanding its exact $V(\theta)=mgl(1-\cos\theta)$. Stretch: (5) derive the driven steady-state phase lag $\tan\delta = 2\beta\omega_d/(\omega_0^2-\omega_d^2)$ via complex exponentials and interpret its three regimes.

*Connection to QM:* the quantum harmonic oscillator (day 17) inherits everything: $\omega_0$ sets the level spacing $\hbar\omega_0$; photons are quanta of an EM field mode that IS this oscillator; the course's ladder-operator algebra is today's complex-exponential trick promoted to operators.

- [ ] **Step 2: Write `code/day03_oscillator_zoo.py`** per Global Constraints (numpy+matplotlib, ≤150 lines, Euler–Cromer, TWEAK header). Three panels: (a) undamped $x(t)$ with $K(t), V(t)$ overlaid to show sloshing; (b) $x(t)$ for the three damping regimes at fixed $\omega_0$ (β = 0.2ω₀, ω₀, 2ω₀); (c) steady-state amplitude vs. drive frequency sweep for 3 damping values (compute amplitude analytically from the derived formula — no need to integrate the driven case).

- [ ] **Step 3: Run `python3 code/day03_oscillator_zoo.py`** — expect: clean run, three panels, resonance peaks visibly taller/narrower for smaller β.

- [ ] **Step 4: Run the per-day verification checklist**; fix failures.

---

