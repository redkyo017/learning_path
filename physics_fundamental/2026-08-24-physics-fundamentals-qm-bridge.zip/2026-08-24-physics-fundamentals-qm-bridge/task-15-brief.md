### Task 15: Day 14 — Atoms, Spectra, and Atom–Light Interaction

**Files:**
- Create: `content/day14.md`

**Interfaces:**
- Consumes: day 4's reduced-mass and angular momentum, day 12's Boltzmann populations, day 13's $E=hf$ and Planck's law.
- Produces: Bohr levels $E_n = -13.6\,\mathrm{eV}/n^2$; the two-level atom + Einstein $A$/$B$ coefficient relations; photon momentum $p = E/c = h/\lambda$; Compton shift $\Delta\lambda = \frac{h}{m_ec}(1-\cos\theta)$ (stated). Day 15 consumes Bohr + photon momentum; day 18 consumes the two-level atom.

- [ ] **Step 1: Draft `content/day14.md` (~3.5h day) with this content brief:**

*Learning objectives:* explain why classical atoms can't exist; derive the Bohr levels from quantized angular momentum; compute spectral-line wavelengths; distinguish absorption, spontaneous emission, stimulated emission and derive the Einstein A/B relations; explain a laser in one page; use photon momentum and the Compton formula.

*Theory beats:*
1. Rutherford's atom and its classical death sentence: accelerating charge radiates (state as fact from day 8's fields carrying energy); estimate quoted — the classical electron spirals in within $\sim10^{-11}$ s. Atoms shouldn't exist; they do.
2. Spectral lines: discrete emission/absorption lines as the second scandal; Balmer's numerology $1/\lambda = R(1/4 - 1/n^2)$ stated as the pattern begging for a mechanism.
3. Bohr: postulates stated honestly as inspired guessing ($L = n\hbar$ + classical circular orbits + radiation only on jumps); derive $r_n$ and $E_n = -13.6\,\mathrm{eV}/n^2$ completely; recover Balmer; note the reduced-mass refinement (day 4 exercise 5 cashed in, one sentence).
4. Why Bohr is wrong-but-useful: right energies (for hydrogen only), right size scale, wrong picture (no orbits — day 15 and your course replace them); its real legacy is "stationary states + quantum jumps emitting $E=hf$ photons."
5. **Atom–light interaction (the photonics payload):** the two-level atom abstraction introduced explicitly as "the model your course will use constantly." Three processes defined: absorption ($B_{12}$), spontaneous emission ($A_{21}$), stimulated emission ($B_{21}$ — emitted photon is a *copy*: same frequency, direction, phase). Einstein's equilibrium argument fully derived: two-level populations in Boltzmann ratio (day 12) + rate balance in a Planck field (day 13) → $B_{12}=B_{21}$ and $A/B = 8\pi h f^3/c^3$ — emphasize what the argument shows: spontaneous emission is *forced to exist* by thermodynamic consistency.
6. The laser in one page: population inversion (why two levels can't lase, three/four can — Boltzmann says $N_2<N_1$ at any temperature), the cavity as a mode selector (day 6's standing waves), stimulated emission's copying as the source of coherence.
7. Relativity teaser (labeled as such, results-with-motivation not derivations): $E=mc^2$ meaning; photon: massless, $E = pc$ → $p = h/\lambda$; Compton scattering as photon-electron billiards, formula $\Delta\lambda = \frac{h}{m_ec}(1-\cos\theta)$ stated and used — its significance: photons carry momentum like particles, interference notwithstanding.
- Misconceptions: "electrons orbit like planets" (Bohr's picture is scaffolding; stationary states are standing waves — tomorrow); "stimulated emission is exotic" (it's the majority process inside every laser pointer; spontaneous emission is the strange one — it's stimulated by vacuum, as your course will show).

*Worked examples:* (1) Bohr-level derivation from $L=n\hbar$ start to finish with numbers for $n=1$; (2) Balmer α wavelength ($n=3\to2$) computed, located in the visible; (3) Einstein-relations derivation as a worked argument (populations + rates + Planck matching); (4) Compton: 0.1 nm X-ray at $90°$ — compute $\Delta\lambda$ and the electron's kinetic energy.

*Exercises:* Retrieval: (1) re-derive $E_n$ from Bohr's postulates closed book; (2) state the three atom–light processes and which coefficient governs each. Standard: (3) hydrogen ionization: minimum photon frequency from $n=1$, and from $n=2$; (4) ratio of stimulated to spontaneous emission rates in a thermal field at given $T$ and $f$ (uses $A/B$ + Planck occupancy) — evaluate for visible light at room temperature and for microwaves, interpret the contrast. Stretch: (5) why can't a two-level system lase in steady state? Rate-equation argument sketch showing $N_2 \le N_1$ under any pumping via the same $B$ both ways.

*Connection to QM:* the two-level atom IS the physical qubit of many photonics platforms; your course's Rabi oscillations are the coherent version of today's rate-equation story; and quantized $L = n\hbar$ is the first appearance of the angular-momentum quantization the course derives properly.

- [ ] **Step 2: Run the per-day verification checklist**; fix failures. (Note: this is the densest day — if it exceeds 600 lines, trim the relativity teaser first, never the Einstein-relations derivation.)

---

