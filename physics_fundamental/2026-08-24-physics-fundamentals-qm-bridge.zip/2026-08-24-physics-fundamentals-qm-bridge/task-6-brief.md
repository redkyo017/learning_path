### Task 6: Day 5 — From Oscillators to Waves

**Files:**
- Create: `content/day05.md`

**Interfaces:**
- Consumes: day 3's SHM machinery (normal-mode language builds on it).
- Produces: the wave equation $\partial_t^2 y = v^2\partial_x^2 y$; sinusoidal-wave conventions $y = A\cos(kx-\omega t)$ with $k=2\pi/\lambda$, $\omega=2\pi f$, $v_{\mathrm{ph}}=\omega/k$; dispersion-relation concept. Days 6, 7, 8, 16 quote all of these.

- [ ] **Step 1: Draft `content/day05.md` (~3.5h day) with this content brief:*

*Learning objectives:* derive the wave equation for a string from Newton on a mass element; verify $f(x\pm vt)$ solves it; work fluently with $k, \omega, \lambda, f, v_{\mathrm{ph}}$; find normal modes of two coupled oscillators; state what a dispersion relation is.

*Theory beats:*
1. Two coupled oscillators: solve for normal modes (symmetric/antisymmetric) via ansatz or symmetry; the moral "N coupled oscillators have N modes; each mode is one big SHM."
2. Continuum limit: string under tension, Newton on an element → $\partial_t^2 y = (T_s/\mu)\,\partial_x^2 y$ (use $T_s$ for tension to avoid the kinetic-energy $T$ collision — state this).
3. General solution $f(x-vt)+g(x+vt)$; verify by chain rule.
4. Sinusoidal waves: definitions of $k, \omega$; phase velocity $v_{\mathrm{ph}} = \omega/k$; the traveling-phase picture.
5. Dispersion relations: for the ideal string $\omega = vk$ (non-dispersive); the *idea* that other systems give $\omega(k)$ nonlinear, and that this will matter enormously (day 7's group velocity, day 16's matter waves).
6. Energy transport in a wave (result + intuition; brief derivation for the string's power).
- Misconceptions: "the medium travels with the wave" (the wave pattern moves; elements oscillate in place); "wave speed depends on how hard you shake" (it's a property of the medium: $\sqrt{T_s/\mu}$).

*Worked examples:* (1) verify $y=f(x-vt)$ solves the wave equation via chain rule, explicitly; (2) guitar string numbers: given $T_s, \mu, L$, compute wave speed and fundamental frequency (uses standing-wave $\lambda=2L$ informally, formalized day 6); (3) two coupled pendulums: find both mode frequencies.

*Exercises:* Retrieval: (1) derive the string wave equation from Newton on an element (closed book); (2) for $y = 0.02\cos(4\pi x - 200\pi t)$ (SI), extract $\lambda, f, v_{\mathrm{ph}}$, direction. Standard: (3) same pulse on two joined strings of different $\mu$ — what changes across the joint ($f$ fixed, $\lambda$ and $v$ change); (4) three coupled masses: write the equations of motion and verify the given middle mode. Stretch: (5) given the dispersion relation $\omega = \sqrt{gk}$ (deep-water waves), compute $v_{\mathrm{ph}}(k)$ and observe longer waves travel faster — one paragraph on why this makes wave *packets* interesting (sets up day 7).

*Connection to QM:* the Schrödinger equation is a wave equation for matter with a *different* dispersion relation ($\omega \propto k^2$) — first-order in time, and that difference is why quantum wave packets spread; "each mode is one big SHM" returns as "each field mode is one quantum oscillator."

- [ ] **Step 2: Run the per-day verification checklist**; fix failures.

---

