# Task 7 report — Day 6: Superposition, Standing Waves, Interferometers

## Files produced

- `physics_fundamental/content/day06.md` — 497 lines (within 350–600 target).
- `physics_fundamental/code/day06_interference_standing_waves.py` — 65 lines (≤150 limit).

## Section-by-section summary

Anatomy followed the contract order exactly: Learning objectives → Reference
material → Theory (5 `###` subsections: superposition-as-theorem, two-source
interference, beats, standing waves, interferometers) → Worked examples (3) →
Simulation → Exercises (5, three tiers) → Hints (5) → Solutions (5) →
Connection to QM. No Journal-template section, matching `day04.md`'s
established pattern in this path (the contract's anatomy list does not
include one).

Theory beats followed the brief's order: (1) linearity of the wave equation
⇒ superposition, proved by direct substitution; (2) two-source interference
via sum-to-product, path difference → phase δ=kΔL, constructive/destructive
conditions, two-slit fringe spacing Δy=λL/d, phasor picture; (3) beats via
sum-to-product, with an explicit note on the "period is halved by |·|" trap
that gives f_beat=|f1−f2| rather than half that; (4) standing waves from two
counter-propagating waves (sum-to-product with sin), fixed-end BCs →
k_n=nπ/L, f_n=nv/2L, with the exact boxed sentence from the brief; (5)
Michelson (survey depth) then Mach–Zehnder (full derivation with explicit
beam-splitter matrix, propagation, recombination, and port labeling).

## Checklist results

1. Anatomy sections present, correctly headed, in order — pass.
2. Every named equation derived/motivated in-line (wave-equation linearity,
   two-source amplitude/intensity, fringe spacing, beat envelope and beat
   frequency, standing-wave form, k_n/f_n, beam-splitter unitarity, MZ
   amplitudes/intensities) — pass. Trig/half-angle identities used are cited
   as standard identities, not re-derived (consistent with house style, e.g.
   day04.md's use of a²−b²=(a−b)(a+b) without proof).
3. Exercise count 5 (within 4–6); tiers labeled Retrieval/Standard/Stretch;
   hints checked individually — none states the final numeric/symbolic
   answer, only the first move; every exercise has a matching hint and
   solution; solutions verified to actually solve the stated problem (see
   Exercise verification below) — pass.
4. Exercises solvable from Day 6 + prior days only (all use today's
   standing-wave form, beam-splitter matrix, or beat derivation; Exercise 5's
   unitarity side-check only needs matrix transpose/multiplication) — pass.
5. Notation matches conventions block (k = wavenumber, ω angular frequency,
   A amplitude, λ, f, v, L, I intensity — no collision with spring-constant
   $k_s$ or other reserved symbols on this day) — pass.
6. 2 `> **Misconception:**` callouts present ("standing waves transport
   energy" in the Standing waves section; "destructive interference destroys
   energy" in the Interferometers section) — pass (≥2 required).
7. Time budget stated: "~3.5 hours" — correct for a day-5–15 file — pass.
8. Sim: script exists, runs clean (see below), `## Simulation` section
   present with 3 predict-before-run prompts — pass.

## Exercise verification (final answers)

1. $y_R+y_L=2A\sin(kx)\cos(\omega t)$ via angle-sum expansion, cross terms
   cancel. Verified by hand.
2. $k_n=n\pi/L$ from $\sin(kL)=0$; $f_n=nv/(2L)$ from $\omega=vk_n$. Verified.
3. Fork B's original frequency = **444 Hz** (436 Hz is ruled out because
   lowering it would increase, not decrease, the beat frequency). Verified
   both branches by hand.
4. Odd-harmonics-only spectrum: $k_n=(2n-1)\pi/(2L)$,
   $f_n=(2n-1)v/(4L)=(2n-1)f_1$. Verified.
5. $I_1=I_0\cos^2(\phi/2)$, $I_2=I_0\sin^2(\phi/2)$, $I_1+I_2=I_0$ for all
   $\phi$ (Pythagorean identity); at $\phi=\pi$ all light is at port 2, none
   destroyed. Hypothetical all-$+1$ beam-splitter matrix gives
   $M'^TM'=\begin{pmatrix}1&1\\1&1\end{pmatrix}\ne I$, confirming it is not
   unitary and the $\pi$-phase convention is required. Verified by explicit
   matrix multiplication (see below).

## Mach–Zehnder convention statement + algebra check

**Convention:** both beam splitters use the real, symmetric, unitary matrix
$M=\frac{1}{\sqrt2}\begin{pmatrix}1&1\\1&-1\end{pmatrix}$ — transmission
carries no phase; one reflection face carries a $\pi$ phase shift ($-1$),
the other none. Verified $M^TM=\tfrac12\begin{pmatrix}1&1\\1&-1\end{pmatrix}\begin{pmatrix}1&1\\1&-1\end{pmatrix}=\tfrac12\begin{pmatrix}2&0\\0&2\end{pmatrix}=I$
by hand — unitary, as required.

**End-to-end algebra:**
- Input $(E_0,0)$ into BS1 → arms $(E_0/\sqrt2,\,E_0/\sqrt2)$ (checked:
  $M(E_0,0)^T=\tfrac1{\sqrt2}(E_0,E_0)$).
- Arm 2 accumulates phase $\phi$ → $(E_0/\sqrt2,\,(E_0/\sqrt2)e^{i\phi})$.
- BS2: $M\cdot(\text{arms}) = \tfrac{E_0}{2}(1+e^{i\phi},\,1-e^{i\phi})$
  (checked by direct multiplication).
- $I_1=\tfrac{I_0}{4}|1+e^{i\phi}|^2=\tfrac{I_0}{4}(2+2\cos\phi)=I_0\cos^2(\phi/2)$;
  $I_2=\tfrac{I_0}{4}(2-2\cos\phi)=I_0\sin^2(\phi/2)$ — checked via
  $1\pm\cos\phi=2\cos^2(\phi/2)$ or $2\sin^2(\phi/2)$.
- $I_1+I_2=I_0$ identically for every $\phi$ — checked symbolically, not just
  at special points.
- **Port labeling:** port 1 ($\cos^2$) is the bright port ($I_1=I_0$ at
  $\phi=0$); port 2 ($\sin^2$) is the dark port ($I_2=0$ at $\phi=0$) — this
  matches the brief's $I_1\propto\cos^2(\phi/2)$, $I_2\propto\sin^2(\phi/2)$
  exactly, with the labeling stated unambiguously for Day 18 to match.

**Standing-wave sum-to-product identity check:** $y_R=A\sin(kx-\omega t)$,
$y_L=A\sin(kx+\omega t)$; expanding both via the sine angle-sum formula and
adding, the $\cos(kx)\sin(\omega t)$ terms are equal and opposite and cancel,
leaving $y=2A\sin(kx)\cos(\omega t)$ — verified by hand, matches the brief's
stated form exactly.

## Sim run output

Command: `MPLBACKEND=Agg python3 code/day06_interference_standing_waves.py`

Environment note: the sandboxed system's default `python3` (Command Line
Tools) had no numpy/matplotlib, and `pip install` failed on a broken TLS cert
chain. Installed both via `brew install numpy` and
`brew install python-matplotlib` (brew's own bottle-fetch path was unaffected
by the pip TLS issue), landing on `/opt/homebrew/bin/python3` (3.14). Ran
with that interpreter:

```
.../code/day06_interference_standing_waves.py:65: UserWarning: FigureCanvasAgg is non-interactive, and thus cannot be shown
  plt.show()
EXIT:0
```

Exit code 0. The single warning is the standard, benign `FigureCanvasAgg`
notice produced by any matplotlib script run under `MPLBACKEND=Agg` — I
confirmed it also appears identically when running the pre-existing
`day03_oscillator_zoo.py` under the same headless invocation, so it is an
artifact of the forced headless backend, not an issue introduced by this
script. No other warnings or exceptions. Three panels generated: (a)
two-source interference intensity vs. screen position (annotated with the
computed fringe spacing), (b) beats with $y(t)$ and $\pm$envelope overlay
(annotated with $f_{\text{beat}}$), (c) MZ $I_1,I_2$ vs. $\phi\in[0,4\pi]$
plus their flat sum at $I_0$ — all analytic, no integration used anywhere.

## Concerns

- None outstanding. Content, sim, and math all verified. The only friction
  was environmental (no numpy/matplotlib preinstalled, pip TLS broken) —
  worked around via `brew install numpy` / `brew install python-matplotlib`,
  no repo files affected by that workaround.
- Per instructions, no git commands were run at any point.
