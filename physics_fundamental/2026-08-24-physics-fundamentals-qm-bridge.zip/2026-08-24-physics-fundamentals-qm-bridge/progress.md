# SDD ledger — plan: physics_fundamental/docs/superpowers/plans/2026-08-24-physics-fundamentals-qm-bridge.md

Spec: physics_fundamental/docs/superpowers/specs/2026-08-24-physics-fundamentals-qm-bridge-design.md (read; binding authority)

## Session adaptations (user-mandated, override skill defaults)
- NO git commands anywhere: no worktree, no commits, no BASE/HEAD, no diff packages.
  "Review package" = the task's created files, read directly by the reviewer (all tasks create new files; Task 22 is fix-only).
- Implementers: Sonnet. Task reviewers: Opus (physics derivations fail subtly). Final whole-branch review: session model (Fable).
- Work happens directly in the repo working tree (pattern of prior paths in this repo).

## Pre-flight conflict scan (task pairs sharing interfaces → produced vs consumed → verdict)
| Producer → Consumer | Interface | Verdict |
|---|---|---|
| T2(d1) → T6,T10,T17 | "F=ma as ODE" framing boxed in d1 | consistent |
| T3(d2) → T4,T11,T17 | V(x) reading, F=-dV/dx, forbidden region | consistent |
| T4(d3) → T6,T11,T13,T18 | ω0 conventions, complex exponentials, Taylor√(V''/m) | consistent |
| T6(d5) → T7,T8,T9,T17 | wave eq, k/ω/v_ph conventions, T_s tension | consistent (notation matches Global Constraints) |
| T7(d6) → T14,T16,T17,T19 | f_n=nv/2L; MZ laws cos²(φ/2)/sin²(φ/2) | VERIFIED by matrix computation: BS·P(φ)·BS on |0⟩ gives ports sin²(φ/2), cos²(φ/2). Consistent, but port labeling is convention-dependent → carry note into T19 dispatch: state port assignment explicitly and match day 6's I₁/I₂ labels. |
| T8(d7) → T18(d17) | Δx·Δk≳1, Gaussian =1/2 → ×ħ → Δx·Δp≥ħ/2 | consistent |
| T9(d8) → T19 | Jones basis vectors, Malus | consistent |
| T10(d9) → T11 | p=∂L/∂q̇; L/T notation flag days 9–11 | consistent (flag required in all three) |
| T11(d10) → T12,T17 | H, Hamilton's eqs; relativistic H stretch → d14 Compton | consistent (d14 states, doesn't derive) |
| T12(d11) → T19 | dictionary table reprinted in d18 | consistent |
| T13(d12) → T14,T18 | Boltzmann/Z/equipartition; d12 ex4 freeze-out closed by d17 worked ex2 | consistent |
| T14(d13) → T15,T16 | E=hf; d13 ex4 closes d8 worked-ex3 forward flag | consistent |
| T15(d14) → T16,T19 | Bohr levels, p=h/λ, two-level atom | consistent |
| T16(d15) → T17 | d15 stretch E_n=n²h²/8mL² vs d16 E_n=n²π²ħ²/2mL² | VERIFIED identical (π²ħ²=h²/4) |
| T17(d16) → T18,T19 | box results, Born, TISE; dispersion ω=ħk²/2m matches d7 ex3 ω=αk² | consistent |
| T18(d17) → T19 | QHO ladder, uncertainty | consistent |
| T20,T21 → corpus | glossary/README consume all 18 files; reconciliation steps present | consistent (sequencing: after T19) |

Per-task self-consistency: each task creates only its own files per the File Structure map; no cross-task file writes except T22 (fix-only by design); no plan-mandated rubric defects found (no assert-nothing tests, no mandated duplication; commits already stripped from plan).

Ruling: sims must be verified headlessly — implementers run `MPLBACKend note: MPLBACKEND=Agg python3 code/<file>.py` (plt.show() would block a dispatch). Carried into every sim-day dispatch. — Cost if wrong: a sim that renders oddly in a live window; mitigated at user smoke-test.
Ruling: reviewer model Opus for task reviews (not Sonnet): content is derivation-heavy; wrong-physics escaping review is the project's main risk. — Cost if wrong: higher review spend.

## Progress
Task 1: review = Approved w/ 1 Important (L128 stretch over-promise) + minors.
Task 1: Ruling: minors L105/L108/L111 (physics-precision cells) promoted into fix round 1 — teaching artifact, precision is the quality bar. Cost if wrong: slight scope creep in one fix round.
Task 1: deferred minors: H1 is filename not title; L219 overrun advice non-sequitur; bare-Unicode notation in prose front door (fine, deliberate).
Task 1: fix round 1/5 dispatched (4 findings) — resumed original implementer.
Task 1: fix round 1/5 (4 addressed, 0 open)
Task 1: complete (STRATEGY.md, review clean after round 1)
Ruling (user-directed): parallel dispatch enabled. No git + disjoint files per task = no tree conflicts; briefs pin all cross-day interfaces. Waves by phase: A=T2-5(d1-4), B=T6-9(d5-8), C=T10-12(d9-11), D=T13-16(d12-15), E=T17-19(d16-18), then T20+T21 parallel, T22 last. Next wave starts when current wave's implementations report (reviews may overlap). Cost if wrong: cross-reference wording drift — caught by T22 sweep + final review.
Task 2: implementer dispatched (in flight).
Task 3: implementer dispatched (in flight).
Task 4: implementer dispatched (in flight).
Task 5: implementation DONE (day04.md, 525 lines); Opus review dispatched.
Task 3: implementation DONE (day02.md, 502 lines); Opus review dispatched.
Task 5: review = Approved w/ 2 Important (centripetal underived; hints 2&5 spoil) + 9 minors.
Task 5: Ruling: a=v²/r motivated inline in day04 (day 1 brief has no circular motion — reviewer's "attribute to day 1" ⚠️ resolved this way). Cost if wrong: slight day-4 length growth.
Task 5: Ruling: ex-4 redundancy fixed by trimming survey pre-derivation, keeping exercise tier per plan. Cost if wrong: survey slightly thinner.
Task 5: accepted-as-is: forward signpost to days 9–11 (benign signposting).
Task 5: fix round 1/5 dispatched (2 Important + 8 minors promoted — all one-line text fixes).
Task 2: implementation DONE (day01.md, 480 lines); Opus review dispatched.
Task 3: review = Approved w/ 1 Important (wrong Morin chapter citation) + 9 minors.
Task 3: Ruling: a=v²/R in day02 ex4 motivated inline as labeled kinematics-fact w/ forward pointer to day 4 survey (keeps files self-contained; consistent w/ Task 5 ruling). Cost if wrong: one redundant sentence across two days.
Task 3: fix round 1/5 dispatched (1 Important + 9 minors, all small text fixes).
NOTE for T22 coherence pass: verify reference-material citations across all 18 days against real textbook chapters (fabricated-citation risk surfaced twice-adjacent: Morin ch. mislabel).
Task 5: fix round 1/5 fixes applied (day04.md now 539 lines); scoped re-review dispatched.
Task 5: fix round 1/5 (10 addressed, 0 open)
Task 5: complete (day04.md 539 lines, review clean after round 1)
Task 3: fix round 1/5 fixes applied (day02.md now 515 lines); scoped re-review dispatched.
Task 3: fix round 1/5 (9 addressed, 1 residual)
Task 3: minor (deferred to final fix wave): day02.md L337 intermediate digit 1.2513e8 should be 1.2512e8 (2GM/R full-precision); final v_esc unaffected. Ruling: demoted back to minor — was promoted by controller choice, no downstream dependency, not worth a loop round.
Task 3: complete (day02.md 515 lines, review clean modulo 1 deferred minor)
Task 2: review = Needs fixes: 1 Important (friction + string-tension force laws unintroduced, self-containedness broken) + 10 minors (all promoted; precision pattern).
Task 2: fix round 1/5 dispatched — resumed original implementer.
Ruling (user: continue autonomously): Wave B launched before T4 implementation lands — all wave-B interfaces are pinned in briefs; disk-state of day03.md is not a dependency. Cost if wrong: none identified.
Tasks 6-9: implementers dispatched in parallel (Sonnet).
Task 4: implementation DONE (day03.md 496 lines + day03_oscillator_zoo.py 80 lines; sim exits 0 in venv). Opus review dispatched.
ENV NOTE for all sim tasks: system python3 lacks numpy/matplotlib, pip SSL broken — verify sims via Homebrew-Python venv in scratchpad (T4 did this). Wave-B sim implementers (T7, T8) will rediscover; carry note into wave D/E sim dispatches (T14, T17, T18).
Ruling: the benign matplotlib Agg UserWarning from plt.show() under MPLBACKEND=Agg is acceptable in headless verification (user runs sims live). Cost if wrong: none — cosmetic.
Task 2: fix round 1/5 fixes applied (day01.md now 514 lines); scoped re-review dispatched.
Task 2: fix round 1/5 (11 addressed, 0 open)
Task 2: complete (day01.md 514 lines, review clean after round 1)
Task 6: implementation DONE (day05.md 541 lines); Opus review dispatched w/ controller flag: adjudicate τ-for-period notation (collides w/ day01 τ=m/b).
NOTE for T22: pin period notation corpus-wide once day05 review rules on it.
Task 9: implementation DONE (day08.md 554 lines); Opus review dispatched (input-polarization ambiguity explicitly in reviewer's method — recurring defect class).
Task 6: review = Needs fixes: 3 Important (τ-period collision; unflagged L-length; wrong 2k_c prose) + 4 minors (promoted).
Task 6: Ruling: NO dedicated period symbol corpus-wide — periods expressed as 1/f or 2π/ω; day 16/17 dispatches must carry this. Cost if wrong: slightly wordier phrasing in later days.
Task 6: fix round 1/5 dispatched — resumed original implementer.
Task 9: review = Approved w/ 1 Important (mixture-vs-superposition callout self-referential) + 9 minors (7 promoted; ex-4b triviality + hint 4 + citations ruled acceptable).
Task 9: Ruling: Griffiths/Hecht citations acceptable ("as appropriate per day"); day13-ex4 pointer matches plan (T22 verifies against file).
Task 9: fix round 1/5 dispatched — resumed original implementer.
Task 9: fix round 1/5 fixes applied (day08.md now 583 lines); scoped re-review dispatched.
Task 9: fix round 1/5 (8 addressed, 0 open)
Task 9: complete (day08.md 583 lines, review clean after round 1)
Task 6: fix round 1/5 fixes applied (day05.md now 558 lines, τ gone); scoped re-review dispatched.
Task 4: review = Needs fixes: 2 Critical (WE3 A(5) numeric error; asymmetry claim backwards) + 1 Important (normalized sim axis defeats predict-prompt) + 4 minors. Fix round 1/5 dispatched.
Task 6: fix round 1/5 (7 addressed, 0 open)
Task 6: complete (day05.md 558 lines, review clean after round 1)
Task 7: implementation DONE (day06.md 497 lines + sim 65 lines, exit 0). Opus review dispatched.
Task 7: Ruling (plan override, carried into T19 dispatch): day06 uses BS convention M=(1/√2)[[1,1],[1,−1]], port1=bright/cos²(φ/2) at φ=0. Day 18 MUST adopt this same convention for its MZ-as-circuit derivation (the plan's suggested [[1,i],[i,1]] would swap ports); day 18 mentions the symmetric variant only in its one-sentence convention note. Cost if wrong: none — both unitary; consistency is what matters.
Task 4: fix round 1/5 fixes applied (day03.md 504 lines, sim 85 lines, K_S-doubling now visible); scoped re-review dispatched.
Task 7: Opus review dispatched (BS convention verification in method).
Task 4: fix round 1/5 (8 addressed, 0 open)
Task 4: complete (day03.md 504 lines + sim 85 lines, review clean after round 1)
Tasks 10-12 (wave C, days 9-11): implementers dispatched in parallel (Sonnet), carrying L/T notation switch, no-period-symbol ruling, env note (T11 sim), citation rule.
Task 7: review = Needs fixes: 1 Critical (Michelson λ/4 half-cycle error) + 3 Important (self-correction artifact; I₁ overload vs exported interface; complex amplitudes unbridged — resolved: bridge cites day 3's complex-exponential product) + 1 promoted (standing-wave panel missing vs plan sim table — Ruling: add 4th panel) + minors.
Task 7: fix round 1/5 dispatched — resumed original implementer.
Task 12: implementation DONE (day11.md 518 lines); Opus review dispatched (dictionary-table exactness + bracket signs + time-dependent-f handling in method).
Task 12: review = Approved, 0 Critical/Important; 6 minors (5 promoted to light fix round: L107 garble, dictionary-row explicit-t caveat [day 18 reprints it], 2 hint trims, Verify→Recall; 1 accepted: canonical-transformation lean).
Task 12: IMPORTANT REVIEWER NOTE preserved: exercise-3 bracket signs {L_z,x}=+y, {L_z,y}=−x, {L_z,p_x}=+p_y are CORRECT (standard ε_ijk identities) — controller's review brief had them backwards; nobody should "fix" these.
Task 12: light fix round 1/5 dispatched.
Task 11: implementation DONE (day10.md 543 lines + sim 87 lines, exit 0); Opus review dispatched.
NOTE for T19 dispatch: day11 dictionary table now carries "(for f with no explicit t)" caveat — the reprint must include it; also verify day10-attribution phrases ("Day 10's oscillator Hamiltonian") at T22.
Task 7: fix round 1/5 fixes applied (day06.md 519 lines, sim 89 lines/4 panels); scoped re-review dispatched. (Fix report in separate task-7-fix-report.md.)
Task 12: light fix round verified by controller grep (5/5 in place — ruling: verbatim one-line fixes from an Approved baseline are grep-verified, no re-review agent). 
Task 12: complete (day11.md 519 lines, review clean)
Ruling (economy, user near token limit; est. ~4-4.5M to finish): (1) minor-only fix rounds grep-verified by controller, no re-review agent; (2) pure-polish minors deferred to final fix wave, not promoted; (3) reviews stay Opus (3 Criticals caught), re-reviews Sonnet. Cost if wrong: slightly weaker verification on trivial fixes.
Task 7: fix round 1/5 (9 addressed, 0 open)
Task 7: complete (day06.md 519 lines + sim 89 lines/4 panels, review clean after round 1)
Task 11: review = content clean; sim: 2 Important (false TWEAK; hardcoded energies break double-ℓ prompt) + 1 Important pointer (saddle X) + minors. Fix round 1/5 dispatched (8 items; 3 polish minors deferred to final wave: convexity line, legend markers, marker clipping).
Task 8: implementation DONE (day07.md 519 lines + sim 97 lines, exit 0; implementer self-caught triangle-wave algebra error). Opus review dispatched (width-definition consistency in method).
Process note: T8 implementer appears to have run a read-only git status despite the rule — harmless; future dispatches keep the explicit ban.
Ruling (user-directed, token economy): SIMS DEFERRED for remaining tasks — T14/T17/T18 write day files only (## Simulation sections stay, scripts day13_blackbody_curves.py, day16_box_eigenstates.py, day17_packet_evolution.py NOT written this run; specs remain in plan for later generation). T22 runs only the 4 existing sims + lists pending; T21 README marks 3 pending sims and points to the plan's sim table. Existing sims (day03/06/07/10) unaffected.
Tasks 13-16 (wave D, days 12-15): implementers dispatched in parallel (Sonnet), T14 without sim.
Task 11: fix round 1/5 (8/8 verified by controller read+grep per economy ruling; sim re-run evidence at both L_PEND in fix report)
Task 11: complete (day10.md 558 lines + sim 93 lines, review clean after round 1)
Task 10: implementation DONE (day09.md 599 lines); Opus review dispatched.

## ===== RESUME HERE (cold-restart snapshot, 2026-08-24) =====
If this session was shut down, resume by: reading this ledger top to bottom, then continuing the task loop below. Plan: physics_fundamental/docs/superpowers/plans/2026-08-24-physics-fundamentals-qm-bridge.md. Spec: .../specs/2026-08-24-physics-fundamentals-qm-bridge-design.md. Briefs: task-N-brief.md in this directory. Reports: task-N-report.md.
COMPLETE (files ship-ready, reviews clean): T1 STRATEGY.md; T2 day01 (514L); T3 day02 (515L, 1 deferred minor: L337 digit 1.2513e8→1.2512e8); T4 day03+sim (504L+85L); T5 day04 (539L); T6 day05 (558L); T7 day06+sim (519L+89L); T9 day08 (583L); T11 day10+sim (558L+93L); T12 day11 (519L).
IN FLIGHT at snapshot: T8 day07 fix round 1 (findings sent: v_g-spread Critical, 2π wording, ex2 diffraction answer, NK/3-modes prompt, 5 minors — then Sonnet re-review or controller grep); T10 day09 implementation DONE (599L), Opus review in flight (verify E–L derivation, wedge, rotating hoop Ω_c=√(g/R)); T13 day12 / T14 day13(NO SIM) / T15 day14 / T16 day15 implementers in flight (wave D).
NOT STARTED: T17 day16 (SIM DEFERRED), T18 day17 (SIM DEFERRED), T19 day18, T20 GLOSSARY, T21 README, T22 coherence pass, final whole-branch review (Fable/most-capable) + one fix wave.
PROCESS: implementers Sonnet / task reviews Opus / re-reviews Sonnet or controller-grep for small fix rounds; NO git commands anywhere; user commits; parallel waves OK (briefs pin interfaces).
KEY RULINGS TO CARRY: sims day13/day16/day17 DEFERRED (## Simulation sections written, scripts later; README marks pending); no period symbol corpus-wide (1/f, 2π/ω); day18 MUST use day06's BS convention M=(1/√2)[[1,1],[1,−1]], port1=bright/cos²(φ/2) at φ=0, and reprint day11's dictionary table VERBATIM incl. "(for f with no explicit t)" caveat; day11 ex-3 signs {L_z,x}=+y etc. are CORRECT, don't "fix"; T22 must verify textbook citations + cross-day refs (day16 cites day07 ex3 + day15 stretch by number; day13 ex4 closes day08 WE3 flag; day17 closes day12 ex4).
## ===== END RESUME BLOCK =====
Ruling (user-directed, supersedes earlier reviewer-model ruling): ALL subagent actions now run on SONNET — implementers, task reviews, re-reviews, final whole-branch review. Only controller reasoning stays on the session model. The in-flight day12 Opus review is the last Opus dispatch. Mitigation for review quality: review prompts already carry explicit verify-this-computation checklists; T22 + final review remain as nets.
Task 10: review = Approved w/ 1 Important (WE1 is a pointer, not worked) + 6 minors promoted. Fix round 1/5 dispatched (file at 599/600 — space-reclaim instructions included).
Task 13: implementation DONE (day12.md 479 lines; kept accurate 517 m/s over brief's ~515). Review dispatched (Opus — last one, was in flight before user override).
Task 14: implementation DONE (day13.md 544 lines, sim deferred, ## Simulation section present); Sonnet review dispatched.
Task 16: implementation DONE (day15.md 544 lines); Sonnet review dispatched.
Task 15: implementation DONE (day14.md 565 lines); Sonnet review dispatched (A/B derivation checklist).
Wave D implementations all landed. Wave E (T17 day16 SIM-DEFERRED, T18 day17 SIM-DEFERRED, T19 day18) launching.
Task 13: review = Needs fixes: 1 Critical (ex-5/QM-box claim "discrete ladder saturates per mode" — wrong; freeze-out at fixed T is the mechanism; plan brief's loose phrasing overridden by Ruling) + 2 Important (73/27 typo; C_V/R undefined) + minors. Fix round 1/5 dispatched.
Task 13: Ruling: plan's ex-5 phrasing ("the exact move Planck makes" re: saturation) is a plan defect — reviewer physics adopted; day 13 already words the mechanism as freeze-out, so files converge. Cost if wrong: none — verified physics.
Task 8: fix round 1/5 fixes applied (day07.md 562L, sim 110L w/ NK); Sonnet re-review dispatched (Critical physics rewrite → full re-review, not grep).
Task 8: fix round 1/5 (9 addressed, 0 open); Task 8 complete (day07.md 562L + sim 110L, review clean after round 1)
Task 14: complete (day13.md 544L, Approved outright — 0 fixes; deferred minors: 2.52e9 rounding, Millikan sentence style)
Task 10: fix round 1/5 fixes applied (day09.md exactly 600L); controller grep verification in progress
Task 16: review = Needs fixes: 3 Important (λ_th evals missing + false cross-ref; grating relation dropped-in; day-7 packets underused) + 1 numeric slip (30→~24 orders) + style minor. Fix round 1/5 dispatched.
Task 10: fix round 1/5 (7/7 verified by controller grep: WE1 full equation run, half-period, strict-inequality w/ coincides-note, back-and-forth, Cartesian clause, rewrap — 600L exactly, 0 overlong lines)
Task 10: complete (day09.md 600L, review clean after round 1)
Task 15: complete (day14.md 565L, Approved outright — 0 fixes; deferred minor: "evaluates to exactly" → "evaluates to" re: Rydberg R∞ vs R_H)
Task 16: fix round 1/5 message sent (λ_th evals, grating motivation, day-7 packet use, 24-orders fix, misconception format).
Status snapshot: COMPLETE = T1-T15 except T16-T19 pending → complete: 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15. IN FLIGHT: T13 day12 fix round; T16 day15 fix round; T17 day16 + T18 day17 implementers. NOT STARTED: T19 day18, T20-T22.
Ruling (user cost pressure, 3rd signal): REMAINING LOOP CUT — T17/T18/T19 get NO individual reviews/fix-rounds (implementer self-verification stands); T20/T21 likewise; ONE consolidated Sonnet review at the end covers days 16-18 + GLOSSARY + README + deferred-minors triage, followed by ONE batched fix dispatch + controller grep verification. In-flight fix rounds (T13 day12, T16 day15) finish and are controller-grep-verified. Cost if wrong: errors in days 16-18 caught only at the consolidated pass (their briefs carried explicit self-verification checklists as mitigation).
Task 16: fix round 1/5 (5/5 verified by controller grep: λ_th 4.3nm/0.5Å inline L276/287, false cross-ref gone, path-difference motivation L391-396, day-7 packet tie-in L215, 24 orders L338, misconception format 2/2)
Task 16: complete (day15.md 586L, review clean after round 1)
Task 13: fix round 1/5 (Critical physics rewrite verified by controller grep: freeze-out L367/400, mode-sum catastrophe L374, 73/27 L290 (71/29 gone), C_V/R defined L208-209, correspondence limit L470; minors confirmed in fix report)
Task 13: complete (day12.md 534L, review clean after round 1)
STATUS: 17/22 complete (T1-T16 all done). IN FLIGHT: T17 day16, T18 day17, T19 day18 (no individual reviews per loop-cut). NEXT: T20+T21 parallel (no reviews) → controller-run T22 mechanical checks → ONE consolidated Sonnet review → one fix wave → final report to user.
Task 17: complete (day16.md 545L, sim deferred, implementer self-verified; no individual review per loop-cut). NOTE: implementer correctly rejected controller-dispatch typo c1=8√2/(3π) — true value 4√2/(3π)≈0.600, |c1|²≈0.360 (controller re-derived, confirmed). Consolidated review should spot-check day16's box numbers (E1≈0.376 eV, middle-third 0.609, 2→1 photon ≈1.10 μm).
Ruling (user-directed): T20 GLOSSARY CANCELLED. Remaining required scope: T18 day17 + T19 day18 (in flight); T21 README written COMPACT by controller directly (~60 lines: index, usage, pending-sims note) — cheaper than any dispatch; T22 mechanical checks run by controller in bash; ONE lean Sonnet review of days 16-18 only (sole unreviewed physics); fixes via one dispatch only if that review finds Critical/Important. Everything else dropped.
Ruling (user-directed): CONSOLIDATED/FINAL REVIEW CANCELLED; T21 README also dropped. Remaining scope = T18 (day17) + T19 (day18) implementers landing, then a controller bash sanity check (file existence + line counts only), ledger/memory close-out, final summary with all rulings. Days 16-18 ship on implementer self-verification alone (user-accepted risk).
Task 19: complete (day18.md 593L; MZ product hand-verified at φ=0,π/2,π matching day06 port laws; day11 table reprint diff-verified byte-identical incl. explicit-t caveat; 12/12/12 self-test verified; 4 QCF cross-ref titles verified). No individual review per loop-cut.
Ruling (user hard cap 200k for day17 completion): T18 implementer ordered to STOP immediately — day17.md ACCEPTED at 623 lines (350-600 band ruled a guideline; overage stands), long report waived, short status only. Cost if wrong: day17 slightly over length target, self-checks possibly incomplete past what it already ran — user-accepted trade.
Task 18: complete (day17.md 611L accepted by ruling; implementer self-verified all numbers pre-stop; long report waived; implementer corrected controller-brief slip: packet-doubling ≈3.3e27 s not 3e24 — controller re-derived, implementer right).
=== RUN CLOSED 2026-08-24 ===
Final state: ALL 18 day files + STRATEGY.md + 4 sims COMPLETE (10,204 content lines + 377 sim lines). Days 1-15 fully reviewed+fixed; days 16-18 implementer-self-verified only (reviews cancelled by user). CANCELLED by user: 3 sims (day13/16/17 — specs in plan §Simulations), GLOSSARY.md, README.md, T22 coherence pass, consolidated + final reviews.
Outstanding deferred minors (never fixed; final wave cancelled): day02 L337 digit 1.2513e8→1.2512e8; STRATEGY H1-is-filename + overrun-advice + bare-unicode; day13 2.5e9 rounding + Millikan sentence style; day14 "evaluates to exactly" (R∞ vs R_H); day10 convexity one-liner + legend markers + edge clipping; day07 WE1/2-vs-Theory duplication + panel-b cosmetics.
NOT VERIFIED (cancelled passes): cross-day reference wording days 16-18 (written in parallel against pinned briefs); textbook citations corpus-wide; day16-cites-day07-ex3/day15-stretch and day17-closes-day12-ex4 confirmed by implementer reports only.

## ===== RESUMED SESSION 2026-08-25 (controller-direct, no subagents) =====
Scope (user-approved, bounded path): verify days 16-18 (the three files that shipped
unreviewed when the loop was cut); write T20 GLOSSARY.md and T21 README.md. Sims stayed
cancelled — README marks the 3 pending. Deferred minors from days 1-15 explicitly NOT
in scope (user declined to widen).

VERIFICATION days 16-18 — method: full read of each file + recomputation of every number
+ cross-reference resolution against the actual target files + contract checklist.
NUMERIC RESULT: zero errors. All recomputed and confirmed —
  d16: E1=0.376 eV, E2=1.504, 2->1 photon 1099 nm/1.10 um, middle-third 0.609,
       ex5 c1=4sqrt2/3pi=0.600 |c1|^2=0.360, |c2|^2=0.5, sum 0.86, ex3 8.2 MeV.
  d17: WE1 alpha=m w0/2h and A=(m w0/pi hbar)^{1/4}; CO E0=0.133 eV, kT=0.026, ratio ~10;
       hydrogen a0=5.29e-11 and -13.6 eV; sol3 0.95 eV; sol4 kappa=5.12e9, T~6e-3,
       proton 2 kappa d=219, T~1e-96, 93 orders; sol5 t_double=3.3e27 s = 7.6e9 x universe.
  d18: MZ product at phi=0,pi/2,pi matches d6 ports; WE2 lambda_pm=0.385/0.0855 eV;
       all 12 self-test answers; Q10 ratio is exactly 4pi^2 (verified analytically).
  Structure: 5/5/5 ex-hint-sol on d16+d17, 12/12/12 on d18, 2 misconceptions each,
  anatomy order correct, time budgets 4h correct. d11 table reprint in d18 diff'd
  BYTE-IDENTICAL (7/7 lines incl. explicit-t caveat). QCF course-map titles 4/4 exact.
DEFECTS FOUND: 9, all cross-reference/notation, all FIXED at the referencing end:
  d16-1 IMPORTANT: beat 5 wrote "= delta_nm, n != m" (self-contradictory) -> restated as
        orthonormality with the 0/1 cases spelled out.
  d16-2 minor: "Day 3's lesson from the sister quantum-computing path" collided with THIS
        path's Day 3 -> reworded to "the sister quantum-computing path's day 3".
  d17-1 IMPORTANT: beat 1 pointed at "beat 2" for the field-mode/photon argument; it is
        beat 4 -> fixed.
  d17-2 IMPORTANT: cited "Day 8's evanescent light waves" twice (L39 + L206). Day 8 has NO
        evanescent waves and no total internal reflection — the phrase appears nowhere in
        the corpus outside d17. Broke self-containedness (reader sent to find nonexistent
        material) -> reframed as an optical effect introduced here, acting on d8's EM waves.
  d17-3 IMPORTANT: WE3 used bare k for the Coulomb constant, colliding with the wave number
        k used in beat 6 of the same file; Day 14 already uses k_e -> switched to k_e
        corpus-wide-consistent, with an inline note.
  d17-4 minor: hint 1 said the spectrum was "boxed" in beat 4; it is a display eq -> "stated".
  d18-1 IMPORTANT: dictionary row 4 credited "Day 15's momentum operator" — p-hat=-i hbar d_x
        is introduced Day 16 beat 1 -> Day 16.
  d18-2 IMPORTANT: dictionary row 8 credited Day 17 for the stationary-state phase (x2);
        stationary states + e^{-iEt/hbar} are Day 16 beat 3 -> Day 16. (Rows 4 and 8 are on
        the path's flagship table — wrong day pointers there are load-bearing.)
  d18-3 IMPORTANT: self-test Q5 said s is "measured along the incline from the top", but the
        hint and solution both use V=+mg s sin(theta) (s increasing UP the slope). As written
        the solution's H gives a block decelerating downhill. Fixed the QUESTION (top -> "upward
        from the base"), the one-word fix that makes hint+solution correct verbatim.
  d18-4 IMPORTANT: Q7 remediation pointer "revisit Day 12, blackbody radiation" — Day 12 is
        Minimal Thermal Physics; Day 13 is Blackbody Radiation and the Photon -> Day 13.
  d18-5 minor: Q4 (labeled "group velocity") pointed at Day 5; Day 5 explicitly DEFERS
        v_g=dw/dk to Day 7, which derives it -> Day 7.
Post-fix line counts: d16 547, d17 614 (was 611; the 350-600 band overage stands per the
earlier ruling), d18 593. No overlong lines introduced (only pre-existing d17 title at 86).

T20 GLOSSARY.md: content/GLOSSARY.md, 234 lines, 79 entries (band 60-80). QCF house style
(notation table -> jump index -> "**term** — plain sentence." entries) + the brief's
alphabetical ordering and "(Day N)" locator. All 50 mandated terms present. Notation table
carries the corpus's real symbol collisions (k / k_s / k_e; L as Lagrangian vs angular
momentum vs length; T as kinetic energy on days 9-11).
RECONCILIATION (brief Step 3) RUN: 79/79 entries grep-verified against their cited day, 0
unverified. 6 that matched only on a weak fallback word were re-checked by exact phrase; 1
genuine defect found and fixed: "Rydberg formula" -> Day 14 actually calls it BALMER's
formula with R the "Rydberg constant" -> entry renamed to "Rydberg constant". Noted: the
exact phrase "Planck's constant" appears nowhere in the corpus (days use h/hbar and
"Planck's law/fix/curve"); entry kept under the standard name, cited Day 13 where E=hf and
E_n=nhf are introduced. Every day 1-18 is cited by at least one entry.

T21 README.md: path root, 139 lines (band 120-180). All 8 brief items present. Day-index
table VERIFIED programmatically: 18/18 titles byte-match the actual "# Day N — <Title>"
headings; 18/18 hours match phase budgets; total sums to exactly 62.5 h; all 4 existing sim
links resolve; the 3 pending scripts are marked pending AND confirmed absent from code/;
zero broken relative links in the whole file.

STILL NOT DONE (unchanged, user-cancelled earlier): 3 sims (day13/16/17 — specs in plan
Simulations section); T22 full corpus coherence pass; textbook-citation audit corpus-wide;
the deferred-minors list from days 1-15 (user declined to include it this session).
=== SESSION CLOSED 2026-08-25 ===
