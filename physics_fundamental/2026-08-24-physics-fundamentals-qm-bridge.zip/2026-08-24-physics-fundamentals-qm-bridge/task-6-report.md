# Task 6 Report — Day 5: From Oscillators to Waves

**File:** `/Users/hunghan/han_git/docker-tools/github-sandbox/repos/learning_path/physics_fundamental/content/day05.md`
**Length:** 541 lines.

## Sections written (in contract order)

1. Learning objectives (6 bullets + "Time budget: ~3.5 hours.")
2. Reference material (French *Vibrations and Waves*; Halliday/Resnick/Walker wave chapters; self-contained note; pointer to Day 3's SHM machinery and complex-exponential method)
3. Theory, six `###` subsections matching the brief's theory-beat order exactly:
   - Two coupled oscillators: normal modes (ansatz/determinant route + faster add/subtract normal-coordinate route; "N coupled oscillators have N modes" moral stated)
   - The continuum limit: wave equation for a string (Newton on a mass element → boxed $\partial_t^2y=v^2\partial_x^2y$, $v=\sqrt{T_s/\mu}$; explicit statement of why $T_s$ is used instead of bare $T$)
   - The general traveling-wave solution $f(x-vt)+g(x+vt)$ (claim + superposition argument; explicit chain-rule verification deferred to Worked Example 1, as the brief structures it)
   - Sinusoidal waves: $k,\omega,\lambda,f,v_{\mathrm{ph}}$ (each relation derived from a periodicity/phase argument, not dropped in; period given the symbol $\tau$, explicitly to avoid colliding with $T_s$ or kinetic-energy $T$)
   - Dispersion relations (derives $\omega=vk$ for the ideal string by direct substitution; defines dispersive/non-dispersive; previews Day 7 group velocity and Day 16 matter waves)
   - Energy transport on a string (derives $P=-T_s\,\partial_xy\,\partial_ty$ from the same tension analysis used for the wave equation, then the average-power result)
4. Worked examples (3, matching the brief): (1) explicit chain-rule verification of $f(x-vt)$ [and the mirror $g(x+vt)$ case]; (2) guitar string wave speed + fundamental frequency; (3) two coupled pendulums, both mode frequencies
5. Exercises: 5 problems, tiers **Retrieval** (2), **Standard** (2), **Stretch** (1), opening with the required house line
6. Hints: 5, one per exercise, non-spoiling (name the first move, not the answer)
7. Solutions: 5, full worked sketches
8. Connection to QM: Schrödinger equation as a dispersive ($\omega\propto k^2$), first-order-in-time wave equation and why that causes wave-packet spreading; "each field mode is one quantum oscillator" as the return of today's normal-mode moral

No `## Simulation` section — Day 5 is not a sim day per the brief.

## Checklist results (day-file-contract's per-day checklist)

1. **Anatomy present, in order, correctly headed** — PASS (verified via `grep -n "^## "`: Learning objectives, Reference material, Theory, Worked examples, Exercises, Hints, Solutions, Connection to QM).
2. **Every named equation derived or explicitly motivated** — PASS. Wave equation derived from Newton's law on an element; $f(x-vt)$ solution motivated in Theory + explicitly verified in Worked Example 1; $k=2\pi/\lambda$, $\omega=2\pi f$, $v_{\mathrm{ph}}=\omega/k$ each derived from a periodicity/constant-phase argument; $\omega=vk$ derived by substitution; power formula $P=-T_s y_x y_t$ derived from the same tension analysis as the wave equation, then evaluated for the sinusoidal wave.
3. **Exercise count 4–6, tiers labeled, hints non-spoiling, every exercise has matching hint+solution, solutions actually solve the stated problem** — PASS. 5 exercises; tier labels **Retrieval**/**Standard**/**Stretch** present (I initially omitted the **Stretch** label before exercise 5 — caught and fixed during self-review). Hints name the first move only. See exercise-by-exercise verification below.
4. **Exercises use only this day + prior days** — PASS. All five exercises use only: Newton's law on an element (today), the $k,\omega,\lambda,f,v_{\mathrm{ph}}$ toolkit (today), the coupled-oscillator technique extended from 2→3 masses (today, direct extension, no new theory), and the dispersion-relation concept (today). Nothing from Days 6–18 is assumed; Day 3's SHM/complex-exponential machinery (explicitly licensed as a consumed product) is used only in the ansatz derivation and Worked Example 3.
5. **Notation matches conventions** — PASS. Tension is always $T_s$, never bare $T$; wave number is $k$; spring constants are $k_s$ (outer springs) and $k_c$ (coupling spring), kept distinct from wave number $k$; period is given its own symbol $\tau$ (not $T$) specifically to avoid the tension/kinetic-energy collision the brief calls out. Cross-checked against `day06.md` (already written, downstream), which quotes "Day 5" for $y=A\cos(kx-\omega t)$, $k=2\pi/\lambda$, $\omega=2\pi f$, $v_{\text{ph}}=\omega/k$, $\omega=vk$, and the wave equation — all match day05.md verbatim.
6. **≥2 misconception callouts** — PASS (exactly 2, both `> **Misconception:**`): "wave speed depends on how hard you shake the string" (placed right after $v=\sqrt{T_s/\mu}$) and "the medium travels along with the wave" (placed right after the $f(x-vt)+g(x+vt)$ general solution, before the traveling-phase discussion).
7. **Time budget stated and plausible** — PASS: "Time budget: ~3.5 hours" (correct band for days 5–15).
8. **Sim day requirements** — N/A, not a sim day.

## Exercise-by-exercise verification (worked myself)

1. **Derive wave equation.** Newton's law on element $\mu\Delta x$, tension forces at two ends, small-slope approx → $\mu\partial_t^2y = T_s\partial_x^2y \Rightarrow \partial_t^2y=v^2\partial_x^2y$, $v=\sqrt{T_s/\mu}$. Matches Theory derivation exactly.
2. **Extract $\lambda,f,v_{\mathrm{ph}}$, direction** from $y=0.02\cos(4\pi x-200\pi t)$: $k=4\pi$, $\omega=200\pi$ → $\lambda=2\pi/k=0.5$ m, $f=\omega/2\pi=100$ Hz, $v_{\mathrm{ph}}=\omega/k=50$ m/s (cross-checked $\lambda f=50$ m/s, consistent). Direction: $+x$ (form is $\cos(kx-\omega t)$).
3. **Joined strings, different $\mu$, same pulse.** $T_s$ continuous → $v=\sqrt{T_s/\mu}$ changes with $\mu$; $f$ fixed by the joint's shared boundary motion; $\lambda=v/f$ therefore changes in proportion to $v$. Matches the brief's stated expected answer ($f$ fixed; $\lambda,v$ change).
4. **Three coupled masses, verify given middle mode.** EOMs: $m\ddot x_1=-k_c(2x_1-x_2)$, $m\ddot x_2=-k_c(-x_1+2x_2-x_3)$, $m\ddot x_3=-k_c(2x_3-x_2)$. Substituting $x_1=A\cos\omega t,x_2=0,x_3=-A\cos\omega t$: eq. 1 gives $\omega^2=2k_c/m$; eq. 2 collapses to $0=0$ identically (consistent for any $\omega$, since it's a genuine node); eq. 3 gives $\omega^2=2k_c/m$, matching eq. 1. So $\omega=\sqrt{2k_c/m}$ — I independently cross-checked this against the general $N=3$ fixed-end uniform-chain formula $\omega_p=2\sqrt{k_c/m}\sin(p\pi/8)$ at $p=2$: $2\sqrt{k_c/m}\sin(\pi/4)=2\sqrt{k_c/m}\cdot(\sqrt2/2)=\sqrt2\sqrt{k_c/m}=\sqrt{2k_c/m}$. Matches exactly — confirms the "given" mode and frequency are correct.
5. **Deep-water dispersion $\omega=\sqrt{gk}$.** $v_{\mathrm{ph}}=\sqrt{g/k}$, decreasing in $k$ ⟹ increasing in $\lambda$: longer wavelengths travel faster (physically correct — matches real ocean-swell behavior). Packet-spreading paragraph correctly ties this to Day 7's group velocity, without borrowing any Day 7 content to solve the exercise itself.

## Self-review findings

- Coupled-oscillator mode frequencies verified two independent ways (determinant/ansatz method, and the add/subtract normal-coordinate shortcut) and both agree: $\omega_s=\sqrt{k_s/m}$, $\omega_a=\sqrt{(k_s+2k_c)/m}$.
- Chain-rule verification of $f(x-vt)$ done explicitly in Worked Example 1: $\partial_x y=f'(u)$, $\partial_x^2y=f''(u)$, $\partial_t y=-vf'(u)$, $\partial_t^2y=v^2f''(u)$, so $\partial_t^2y=v^2\partial_x^2y$. Confirmed the mirror computation for $g(x+vt)$ also works (sign of $\partial u/\partial t$ flips but squares away).
- Average power formula cross-checked against the known textbook result: derived $\langle P\rangle=\tfrac12T_sA^2k\omega$, then substituted $T_s=\mu v^2$, $k=\omega/v$ to get $\langle P\rangle=\tfrac12\mu v\omega^2A^2$, which matches the standard Halliday-style result for power on a string.
- Guitar numbers ($T_s=80$ N, $\mu=5$ g/m, $L=0.65$ m → $v\approx126.5$ m/s, $f_1\approx97.3$ Hz) and pendulum numbers ($L=1$ m, $m=0.5$ kg, $k_c=2$ N/m → $\omega_s\approx3.13$, $\omega_a\approx4.22$ rad/s) recomputed independently and match the file.
- Caught and fixed one omission during self-review: the **Stretch** tier label was missing before exercise 5 in the first draft; added it.
- Confirmed via `grep` that day06.md (already-existing downstream file) quotes Day 5's conventions ($y=A\cos(kx-\omega t)$, $k=2\pi/\lambda$, $\omega=2\pi f$, $v_{\mathrm{ph}}=\omega/k$, $\omega=vk$, the wave equation, intensity $\propto$ amplitude$^2$) and all match this file exactly — no retroactive inconsistency introduced.

## Concerns

None outstanding. No git commands were run. No forward references beyond Day 3 (explicitly licensed) were used in the exercises.

---

## Fix report (post-review)

The task review (physics verified correct) found one notation-safety
issue, one wrong explanation, and five minor items. All were applied
directly to `content/day05.md`. File is now **558 lines** (was 541). No
git commands were run.

### MUST-FIX

**1. τ-for-period collided with Day 1's drag time constant $\tau=m/b$ — deleted the period symbol entirely.**
Old: "**Period and frequency.** ... defines the temporal period $\tau$
(written $\tau$, not $T$...); requiring $\omega\tau=2\pi$ gives
$\omega=2\pi/\tau$. The frequency $f=1/\tau$..."
New:
> **Frequency.** The frequency $f$ is the number of cycles per second, so
> one full cycle takes $1/f$ seconds; requiring $\omega\cdot(1/f)=2\pi$
> (one full cycle of the cosine advances its phase by exactly $2\pi$, the
> same periodicity argument used for $\lambda$ above, now applied in time
> instead of space) gives
> $$\omega = 2\pi f.$$
Confirmed by `grep -n '\\tau\|τ'` on the whole file: zero matches. No
`T`-for-period usage anywhere either.

**2. Unflagged $L$ for length (collides with angular momentum $L$ outside days 9–11) — flagged at first use.**
First use of $L$-as-length is Worked Example 2 (guitar string, formerly
around L330, now line 342), not the pendulum example. Added the clause
there only (one clause at first use, per the instruction):
> "...and vibrating length $L=0.65\text{ m}$ **(here $L$ is a length —
> not Day 4's angular momentum)**. The wave speed is..."
The later pendulum Worked Example 3 reuses the same already-flagged $L$
and was left unchanged.

**3. Wrong/circular justification for the factor of 2 in $\omega_a=\sqrt{(k_s+2k_c)/m}$ — rewritten.**
Old (circular): "the coupling spring stretches by *twice* the relative
displacement (as mass 1 moves right by $\delta$, mass 2 moves left by
$\delta$, so the spring between them changes length by $2\delta$), which
is exactly why $2k_c$... adds to the effective stiffness."
New:
> "The coupling spring's own extension is exactly the relative
> displacement $d=x_1-x_2$ itself — nothing doubled there. The factor of
> $2$ instead comes from how $d$'s equation of motion is assembled:
> dividing each original equation by $m$, mass 1's coupling force
> contributes $-(k_c/m)\,d$ to $\ddot x_1$, while mass 2's coupling force
> (the same spring, pulling the other way) contributes $+(k_c/m)\,d$ to
> $\ddot x_2$. Subtracting $\ddot x_2$ from $\ddot x_1$ turns that
> difference into a sum, $-(k_c/m)d - (k_c/m)d = -(2k_c/m)d$, which is
> exactly why $2k_c$, not $k_c$, ends up multiplying $d$."
Re-verified algebraically: dividing $m\ddot x_1=-k_sx_1-k_c(x_1-x_2)$ by
$m$ gives $\ddot x_1=-(k_s/m)x_1-(k_c/m)d$; dividing
$m\ddot x_2=-k_sx_2-k_c(x_2-x_1)$ by $m$ gives
$\ddot x_2=-(k_s/m)x_2+(k_c/m)d$; subtracting:
$\ddot x_1-\ddot x_2=-(k_s/m)d-(k_c/m)d-(k_c/m)d=-[(k_s+2k_c)/m]d$ —
matches the equation already in the file, confirming the new prose is
consistent with the (unchanged, always-correct) equations.

### MINOR

**4.** L318 "Comparing the two boxed results" → "Comparing the two
results" (nothing is boxed in Worked Example 1). Done verbatim.

**5.** Exercise 3 restated for a long sinusoidal wave train of frequency
$f$ from the start, rather than "a pulse" with a later "sinusoidal
continuation":
> "A long sinusoidal wave train of frequency $f$ travels along a string
> of mass density $\mu_1$, which is joined end-to-end to a second string
> of a different mass density $\mu_2$, both under the same tension $T_s$.
> As the wave crosses the joint onto the second string, which of $f$,
> $\lambda$, $v_{\mathrm{ph}}$ stay fixed and which change, and why?..."
Solution 3's text required no change (it never used "pulse" language).

**6.** Solution 4, Equation 2, given the half-clause that it collapses to
$0=0$ because $x_1+x_3=0$ in this mode:
> "*Equation 2:* LHS $=m\ddot x_2=0$. RHS
> $=-k_c(-x_1+2x_2-x_3)=-k_c(-x_1-x_3)$ since $x_2\equiv0$, and in this
> mode $x_1+x_3=A\cos\omega t+(-A\cos\omega t)=0$ at every instant, so RHS
> $=-k_c\cdot0=0$ too. ... — consistent with $x_2\equiv0$ requiring no
> restoring dynamics of its own in this particular mode, precisely because
> $x_1$ and $x_3$ always cancel."

**7.** Added a one-line sketch of the $u=x-vt,\ w=x+vt$ change of
variables to motivate (not just cite) the "$f(x-vt)+g(x+vt)$ is the fully
general solution" claim:
> "...follows from switching coordinates to $u=x-vt,\ w=x+vt$: by the
> chain rule the wave-equation operator $\partial_t^2-v^2\partial_x^2$
> becomes proportional to $\partial^2/\partial u\,\partial w$, so the
> wave equation reduces to $\partial^2y/\partial u\,\partial w=0$;
> integrating once in $w$ shows $\partial y/\partial u$ can depend on $u$
> alone, and integrating once more in $u$ gives $y=f(u)+g(w)$ for some
> single-variable functions $f,g$ — exactly the general solution above,
> with nothing left over."

### Checklist re-verification after edits

1. **Anatomy present, in order** — PASS (`grep -n "^## "` confirms all 8
   sections, same order as before).
2. **Every named equation derived/motivated** — PASS, strengthened by fix
   7 (general-solution claim now has a derivation sketch, not just a
   citation) and fix 3 (the $2k_c$ factor now has a correct, non-circular
   derivation).
3. **Exercise count 4–6, tiers labeled, hints non-spoiling, matching
   hint+solution, solutions actually solve the problem** — PASS. Still 5
   exercises, tiers **Retrieval**/**Standard**/**Stretch** present and
   correctly placed; exercise 3's rewording did not change its hint or
   solution's validity (re-checked: solution 3 still answers "which of
   $f,\lambda,v_{\mathrm{ph}}$ change" correctly for a sinusoidal train).
4. **Exercises use only this day + prior days** — PASS, unaffected by the
   edits.
5. **Notation matches conventions** — PASS, and now stricter: no $\tau$
   or bare-$T$-for-period anywhere (`grep` confirms zero matches); $L$
   for length is flagged at its first use against Day 4's angular
   momentum; tension remains $T_s$ throughout, never bare $T$.
6. **≥2 misconception callouts** — PASS, still exactly 2 (`grep -c
   Misconception` → 2), untouched by these fixes.
7. **Time budget stated and plausible** — PASS, unchanged ("~3.5
   hours").
8. **Sim day requirements** — N/A, unchanged.

`grep -n '\\tau\|τ'` on the full file after all edits: **no matches** —
confirmed the period symbol was deleted everywhere, not just at L215–218.

No new concerns. All edits are prose/labeling fixes; no equations, numeric
results, or exercise/solution correctness were altered in substance (fix
3's rewritten prose was checked against the unchanged, already-correct
equations of motion; fix 6 adds an explanatory clause to an already-correct
solution).
