# Task 4 Report — Day 3: The Harmonic Oscillator, Deep

## Files written
- `physics_fundamental/content/day03.md` (496 lines)
- `physics_fundamental/code/day03_oscillator_zoo.py` (80 lines)

## Sections written (in contract order)
Learning objectives (6 bullets + "~3 hours" time budget) → Reference material
(French *Vibrations and Waves* + Morin, self-contained note, Day 1/Day 2
pointers by number only) → Theory (6 subsections: universality of SHM near
any minimum; complete solution of ẍ=-ω₀²x; complex-exponential method;
energy K↔V slosh; damping's three regimes from the characteristic-equation
discriminant; driving and resonance) → Worked examples (3) → Simulation →
Exercises (5, tiered) → Hints (5) → Solutions (5) → Connection to QM.

Three `> **Misconception:**` callouts, placed where they bite: (1) taking
Re[·] partway through a complex calculation instead of at the very end;
(2) "damping always shrinks amplitude gradually" — overdamped systems don't
oscillate at all; (3) "resonance = drive frequency exactly ω₀" — the
amplitude peak sits at √(ω₀²−2β²), only the 90° phase point is exactly ω₀.

## Checklist results
1. Anatomy sections present, correctly headed, in contract order — pass.
2. Every named equation derived in-line (Taylor expansion → ω₀; general
   SHM solution both forms; complex-exponential re-derivation; K(t), V(t)
   from substitution; characteristic equation → 3 damping regimes; Q from
   both the ring-down and Lorentzian-width arguments; driven ODE →
   amplitude/phase via complex method) — pass.
3. 5 exercises (within 4–6), tiers bold-labeled (Retrieval/Standard/
   Stretch), hints name the first move without giving the answer, every
   exercise has a matching hint and full solution — pass.
4. Exercises solvable from Day 1–3 content only. Exercise 4 (pendulum)
   deliberately avoids requiring moment of inertia (a Day 4 topic) by using
   the arc-length coordinate s=lθ and tangential Newton's second law
   directly, so it stays self-contained — pass.
5. Notation: `k_s` used throughout (never bare `k`); grep for bare `k` (excl.
   `k_s`, `k_1`, `k_2`, `k_eff`) returned nothing — pass.
6. 3 misconception callouts (≥2 required) — pass.
7. Time budget "~3 hours" stated, matches contract's days 1–4 target —
   pass.
8. Sim exists, `## Simulation` section present with the brief's 3 verbatim
   predict-before-run prompts, script runs clean — pass.

## Exercise-by-exercise verification (final answers, worked by hand)
1. ω₀ = √(V''(x₀)/m) — from Taylor expansion, constant term drops (forces
   depend on derivatives only), linear term vanishes at a minimum, quadratic
   term matches a spring with k_s ≡ V''(x₀).
2. A = x(0), B = ẋ(0)/ω₀ (direct substitution confirms the ODE is solved
   for any A, B; initial conditions fix them uniquely).
3. (a) Parallel: ω₀ = √((k₁+k₂)/m). (b) Series: ω₀ = √(k₁k₂ / (m(k₁+k₂))).
4. ω₀ = √(g/l), T = 2π√(l/g) — the standard small-angle pendulum period,
   recovered via V(s) = mgl(1−cos(s/l)) and the universality argument, no
   separate rotational-dynamics derivation needed.
5. tan δ = 2βω_d/(ω₀²−ω_d²), via the complex substitution
   (−ω_d²+2iβω_d+ω₀²)X̃ = f₀. Regimes: δ→0 for ω_d≪ω₀ (in phase), δ=90° at
   ω_d=ω₀ exactly (denominator's real part vanishes regardless of β),
   δ→180° for ω_d≫ω₀ (out of phase).

Worked-example numbers double-checked by hand:
- Example 1: minimum at x=a, ω₀=√(2V₀/(ma²)).
- Example 2: β≈0.0693 s⁻¹, Q≈45.3 (cross-checked two ways: t_N=NT₁ and the
  closed form β=ω₀ln2/(2πN), Q=πN/ln2 — both give 45.3, consistent).
- Example 3 (ω₀=10, β=1, f₀=1): A(5)=0.0080, A(10)=0.0500, A(20)=0.0033,
  peak at ω_d=√98≈9.90 giving A_peak≈0.0503 — slightly above A(ω₀),
  confirming the peak sits just below ω₀ as derived in Theory.

## Sim run command + output
```
MPLBACKEND=Agg python3 code/day03_oscillator_zoo.py
```
Note on environment: this sandbox's system Python (`/usr/bin/python3`) has
no numpy/matplotlib and no working pip (broken SSL cert chain). Network
itself is up (`curl` to pypi.org succeeds), so I built a disposable venv
from Homebrew's `python3.14` (whose pip has a modern SSL stack), installed
numpy+matplotlib there only, and ran the exact required command against
`code/day03_oscillator_zoo.py` unmodified. Result: exit code 0, one benign
"FigureCanvasAgg is non-interactive" UserWarning (expected — the brief
itself notes `plt.show()` is a no-op under Agg), no exceptions. The
identical benign-warning behavior reproduces on the existing
`quantum_computing_foundations/code/day04_bloch_sphere.py`, confirming this
is a backend artifact, not a script defect. The scratchpad venv is not part
of the repo and was not added to it.

## Self-review findings
- Resonance-curve formula in the sim (`A = F0 / sqrt((OMEGA0**2-wd**2)**2 +
  4*beta**2*wd**2)`, panel c) matches the file's boxed formula
  `A(ω_d) = f₀/√((ω₀²−ω_d²)²+4β²ω_d²)` exactly, term for term.
- Sim's `K_S` is the primary tunable (with `OMEGA0 = sqrt(K_S/M)` derived
  from it) specifically so the brief's "double k_s" predict-prompt has a
  literal parameter to change.
- Euler–Cromer used for both integrated panels (a) undamped and (b) damped;
  panel (c) is analytic only, per the brief's explicit exemption ("no need
  to integrate the driven case").
- Verified no bare `k` (wave-number collision) appears anywhere in the day
  file — spring constant is `k_s` throughout, `k_1`/`k_2`/`k_eff` for the
  series/parallel exercise.
- Exercise 4 was the one exercise requiring care to keep within Day 1–3
  scope: solved it via the arc-length coordinate rather than angular
  dynamics/moment of inertia, which are Day 4 material.

## Concerns
- None outstanding. The only friction was environment tooling (verification
  Python needed a throwaway venv, as detailed above); it does not affect
  the delivered content or script, which run identically for the actual
  learner's own Python environment (assumed to have numpy/matplotlib per
  the global constraints).

## Fix report (post-review pass)

### CRITICAL

**1. Worked example 3, ω_d=5 bullet — double-squaring bug.**
The bug: $R=\sqrt{75^2+100^2}=\sqrt{15625}=125$ squared the already-squared
damping term $4\beta^2\omega_d^2=100$ a second time. Corrected: $R =
\sqrt{75^2+100}=\sqrt{5725}\approx75.66$, so $A(5)\approx1/75.66\approx0.0132$
(was $0.0080$). Verified numerically (see below): $A(0)=0.0100$,
$A(5)=0.0132$, $A(10)=0.0500$, $A(20)=0.0033$, peak $A_{\text{peak}}
\approx0.0503$ at $\omega_d\approx9.90$ — all four points now rise
monotonically from the $\omega_d=0$ floor to the peak, then fall away,
exactly as required.

**2. L336–338 asymmetry claim — was backwards.** Replaced "falls off more
gently above [resonance]" with the correct statement: the curve is gentler
*below* resonance (approaching the finite floor $A(0)=f_0/\omega_0^2=0.0100$
as $\omega_d\to0$) and steeper *above* resonance (decaying like
$A\sim f_0/\omega_d^2\to0$ as $\omega_d\to\infty$). New text sits directly
after the three sample-point results and the peak calculation, so the
$0.0132\to0.0500\to0.0033$ progression and the $0.0100$ floor are both
visible right where the claim is made.

### IMPORTANT

**3. Sim panel (c) — peak was invariant to K_S.** `BETAS_DRIVEN` was
defined as multiples of `OMEGA0` and plotted against `wd/OMEGA0`, so the
peak always rendered at the same normalized position regardless of `K_S`.
Fixed: `BETAS_DRIVEN = [0.1, 0.3, 0.6]` (absolute rad/s, no longer scaled
by `OMEGA0`), sweep is now `wd = np.linspace(0.01, WD_MAX, 400)` with fixed
`WD_MAX = 2.5` (absolute, independent of `OMEGA0`), plotted directly as
`axes[2].plot(wd, A, ...)` against absolute `w_d [rad/s]`; the `omega_0`
marker line now sits at the dynamic `OMEGA0` value instead of a fixed `1.0`.
Verified numerically in the venv: with `K_S=1.0`, `OMEGA0=1.000`, peak at
`w_d≈0.990`; with `K_S=2.0`, `OMEGA0=1.414`, peak at `w_d≈1.408` — the peak
visibly shifts right, matching the TWEAK line and the file's "double
k_s — which way does the peak move?" prompt. Re-ran
`MPLBACKEND=Agg python3 code/day03_oscillator_zoo.py` — exit 0 (see below).

**4. Hint 3 — series-junction idea wasn't cued.** Appended: "For the
series case, ask what force the massless junction between the springs can
sustain." to Hint 3, so the equal-tension move used in Solution 3(b) is now
foreshadowed without being handed to the reader.

### MINOR

**5. Sim variable names.** `F0` → `F0_OVER_M` (with a comment noting it
implements $f_0=F_0/m$, numerically equal to $F_0$ only because $M=1$);
`V0` → `VEL0` throughout (both integration call sites and the parameter
comment), removing the three-way `V`/`V0`/`V(t)` collision.
**6. L91 (now renumbered after edits) and every other occurrence.** All
`\varphi` replaced with `\phi` file-wide (14 occurrences: amplitude/phase
form, complex-exponential section, energy section, underdamped solution) —
grep for `\varphi` now returns zero hits.
**7. L158–161 — ⟨K⟩=⟨V⟩ justification.** Replaced "each spending equal
time above and below $E/2$" with the actual mechanism already exhibited one
line above: $\langle\cos2\theta\rangle=0$ over a full cycle, so averaging
$K(t)=\tfrac14k_sA^2(1-\cos2\theta)$ and $V(t)=\tfrac14k_sA^2(1+\cos2\theta)$
directly kills the oscillating term and leaves the shared mean $E/2$ in
each.
**8. Exercise 3 notation.** $k_1,k_2,k_{\text{eff}}$ → $k_{s1},k_{s2},
k_{s,\text{eff}}$ throughout the exercise statement, Hint 3, and Solution 3
(both parallel and series parts), keeping the day's "spring constant is
always $k_s$" rule airtight.

### Sim re-run after fixes
```
$ MPLBACKEND=Agg python3 code/day03_oscillator_zoo.py
.../code/day03_oscillator_zoo.py:85: UserWarning: FigureCanvasAgg is
non-interactive, and thus cannot be shown
  plt.show()
$ echo $?
0
```
Same benign Agg warning as before (expected, noted in the brief), exit 0,
no exceptions. Run via the same disposable scratchpad venv described above
(system Python still lacks numpy/matplotlib/working pip; not a code issue).

### Re-verified checklist (post-fix)
1. Anatomy sections present, in contract order — pass (headers unchanged
   by these fixes: Learning objectives → Reference material → Theory →
   Worked examples → Simulation → Exercises → Hints → Solutions →
   Connection to QM).
2. Every named equation derived/motivated — pass, unaffected by fixes
   (fixes were to worked-example arithmetic/prose and exercise notation,
   not to derivations).
3. 5 exercises, tiers labeled, hints non-spoiling, matching
   hint+solution per exercise — pass; Hint 3 now also correctly primes the
   series-junction move without stating the answer.
4. Exercises solvable from Day 1–3 only — pass, unaffected.
5. Notation matches conventions — pass, now stricter: bare `k` grep (excl.
   `k_s`, `k_{s1}`, `k_{s2}`, `k_{s,eff}`) returns zero hits; `\varphi`
   grep returns zero hits (file uses `\phi` exclusively for the SHM phase,
   matching the interface contract).
6. 3 misconception callouts (≥2 required) — pass, unchanged.
7. Time budget "~3 hours" stated — pass, unchanged.
8. Sim exists, runs clean (exit 0), `## Simulation` section present with
   the 3 verbatim predict-prompts, and panel (c)'s K_S TWEAK now actually
   does what the TWEAK line and predict-prompt claim — pass.

File line counts after fixes: `content/day03.md` 504 lines (was 496, still
within 350–600); `code/day03_oscillator_zoo.py` 85 lines (was 80, still
≤150).
