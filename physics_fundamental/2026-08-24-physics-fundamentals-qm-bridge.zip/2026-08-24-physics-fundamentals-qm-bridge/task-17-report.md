# Task 17 Report — Day 16: The Schrödinger Equation

## Scope note

Per instructions, `code/day16_box_eigenstates.py` was DEFERRED and not
written. The `## Simulation` section was written per the brief (run
instruction + three predict-prompts) and ends with the mandated italic
line: "*The script ships separately; the predict-prompts stand on their
own.*"

## File produced

`/Users/hunghan/han_git/docker-tools/github-sandbox/repos/learning_path/physics_fundamental/content/day16.md` — 545 lines (within the 350–600 phase-5 target).

## Sections (in contract order)

1. Title + Learning objectives (6 bullets) + "Time budget: ~4 hours."
2. Reference material (Griffiths QM ch. 1–2, French & Taylor, self-contained
   note, pointers to days 5/6/7/8/10/15).
3. Theory, six `###` subsections matching the brief's beats exactly:
   1. Constructing the TDSE (explicitly framed as motivation, not
      derivation; first-order-in-time flag vs. day 5; necessarily-complex
      argument; dispersion $\omega=\hbar k^2/2m$ cited to **Day 7,
      Exercise 3** by name, with the $v_g=2v_{ph}$ callback).
   2. Born rule + normalization + global-phase recall (**day 8, exercise
      5**, cited by name) + misconception #1 ($\psi$ not a physical wave;
      one-sentence 6D note for two particles).
   3. Separation → TISE, $\hat H$ stated as "day 10's Hamiltonian, the
      generator of time evolution," with hats + misconception #2
      (stationary ≠ at rest, $\langle p\rangle=0$ but $\langle
      p^2\rangle\ne0$).
   4. Particle in a box, complete: boundary conditions (day 6's fixed
      string, verbatim), $n=0$ exclusion reasoned explicitly, full
      normalization computed, match to **Day 15's stretch exercise**
      stated and the $n^2\pi^2\hbar^2/2mL^2 \equiv n^2h^2/8mL^2$
      equivalence shown algebraically, node count $n-1$.
   5. Orthogonality (stated, proved in Exercise 4) + expansion +
      linear-algebra callback + measurement postulate ($|c_n|^2$).
   6. Superposition/beats preview, one derivation paragraph, cites day 6's
      beats.
4. Worked examples (3, numbered): electron-in-1nm-box $E_1,E_2,\lambda$;
   normalization from scratch; ground-state middle-third probability.
5. Simulation section (script deferred, see scope note above).
6. Exercises: 2 Retrieval, 2 Standard, 1 Stretch (5 total).
7. Hints (5, non-spoiling — name the first move only).
8. Solutions (5, full sketches, no skipped steps).
9. Connection to QM (2 paragraphs: TISE as the course's eigenvalue
   problem/spectral theorem generalized to infinite dimensions +
   measurement postulate; box as recurring perturbation-theory base case;
   photonics/cavity-mode tie to days 6/13/14).

## Checklist results

1. Anatomy present, correctly ordered, correctly headed. Pass.
2. Every named equation derived or explicitly motivated (TDSE explicitly
   flagged "motivated, not derived"; Born rule stated as a postulate
   validated by a century of experiment; TISE derived by separation; box
   fully derived; orthogonality proved by integral in Exercise 4). Pass.
3. Exercise count 5 (in 4–6 range); tiers labeled; hints checked against
   solutions — none give away the final answer, each names only the first
   move; every exercise has a matching hint and solution; solutions were
   independently re-derived (see verification below) and match the stated
   problems. Pass.
4. Exercises use only day 16 content plus prior days (5, 6, 7, 8, 10, 15
   citations only — no forward references). Pass.
5. Notation: $L$ flagged "(here $L$ is a length)"; no spring-constant
   symbol needed (none appear); $\phi_n$ used for eigenfunctions, $\psi$
   for general/time-dependent states, consistently; no bare period symbol
   $T$ used (checked via grep — only the English word "period" appears in
   prose, wavelength/frequency expressed via $1/f$-style relations
   ($hc/\lambda$, $E=hf$-style), never a period symbol). Pass.
6. Misconception callouts: exactly 2 (`> **Misconception:**`), both
   brief-mandated: "$\psi$ is a physical wave in space" (with the 6D
   two-particle sentence) and "stationary means at rest." Pass (meets the
   ≥2 minimum).
7. Time budget: "~4 hours" stated, correct for a phase-5 day (16–18 band).
   Pass.
8. Sim day: script deferred by explicit scope instruction (noted above,
   not a checklist failure — this is the user-mandated exception); `##
   Simulation` section present with run instruction and 3 predict-before-run
   prompts, ending with the required deferral sentence. N/A/waived per
   scope change, not a gap.

No failures requiring fixes.

## Exercise verification (worked independently, final answers)

- **Worked example 1** (electron, $L=1\,\text{nm}$): $E_1\approx
  0.376\,\text{eV}$, $E_2 = 4E_1\approx1.504\,\text{eV}$, $\Delta E =
  3E_1\approx1.128\,\text{eV}$, $\lambda = hc/\Delta E\approx1099\,\text{nm}
  \approx1.10\,\mu\text{m}$. Confirmed against the brief's target numbers.
- **Worked example 2** (normalization): $\int_0^L\sin^2(n\pi x/L)dx=L/2$
  for every integer $n$ (via substitution, $\sin(2n\pi)=0$), so
  $A=\sqrt{2/L}$. Confirmed.
- **Worked example 3** (middle-third probability): $P = 1/3+\sqrt3/(2\pi)
  \approx0.609$. Confirmed against target.
- **Exercise 3** (proton vs. electron): same-box spacing ratio $m_e/m_p
  \approx1/1836$; using $L_{\text{atom}}\sim1\,\text{nm}$ and
  $L_{\text{nucleus}}\sim5\,\text{fm}$, nuclear ground energy
  $\approx8.2\,\text{MeV}$ — lands cleanly in the MeV range the brief
  asked for, order-of-magnitude correct for a 1D toy model.
- **Exercise 4** ($\phi_1\perp\phi_2$): both product-to-sum cosine
  integrals vanish independently over $[0,L]$; integral $=0$ exactly.
  Confirmed.
- **Exercise 5** (sudden box doubling): $c_1 = 4\sqrt2/(3\pi)\approx0.600$,
  $|c_1|^2 = 32/(9\pi^2)\approx0.360$ — matches the brief's target
  $\approx0.36$ exactly. (Note: the brief's own hint text wrote
  "$c_1=8\sqrt2/(3\pi)$…", which is numerically impossible as a
  probability amplitude since it exceeds 1 in magnitude — I independently
  re-derived the overlap integral from scratch via the product-to-sum
  identity and got $c_1=4\sqrt2/(3\pi)$, whose $|c_1|^2\approx0.360$
  matches the brief's mandated checkable numeric target. This value also
  matches the well-known textbook result for this classic "sudden box
  expansion" problem, cross-checked via the companion identity that the
  new box's $n=2$ eigenstate exactly reproduces the old ground state's
  shape on $[0,L]$, giving the sanity-check value $|c_2|^2=1/2$.)

## Concerns

- The brief's stretch-exercise hint text contained an apparent arithmetic
  slip ($c_1=8\sqrt2/(3\pi)>1$, impossible for a probability amplitude).
  The file uses the correct, independently re-derived value
  $c_1=4\sqrt2/(3\pi)\approx0.600$, whose squared value matches the
  brief's own mandated numeric checkpoint ($\approx0.36$), so no
  correction to the plan is needed — flagging only so it's not mistaken
  for an inconsistency on re-review.
- No other concerns; all citations, notation constraints, and structural
  requirements were satisfied on first pass.
