# Task 5 report — Day 4: Momentum, Angular Momentum, Symmetry

File written: `physics_fundamental/content/day04.md` (525 lines).

## Sections written (in contract order)

1. Learning objectives — 6 testable bullets + "Time budget: ~3 hours."
2. Reference material — Halliday/Resnick/Walker + Morin chapter pointers, self-contained note, builds-on note (Day 1 Newton, Day 2 energy).
3. Theory (### subsections):
   - Momentum conservation from N2+N3 (two-body, then N-body generalization)
   - Collisions in 1D: perfectly inelastic (derived $v_f$) and elastic (derived relative-velocity-reversal and closed-form $v_{1f},v_{2f}$)
   - The center-of-mass frame trick (derived: zero total momentum in that frame ⇒ velocities simply reverse)
   - Angular momentum and torque (derived $d\vec L/dt=\vec\tau$)
   - Central forces conserve $\vec L$; Kepler's second law (derived $\tau=0$ for central force; $dA/dt=|L|/2m$)
   - The symmetry dictionary (informal Noether: translation→momentum, rotation→angular momentum, time-translation→energy; "why these three" explanation)
   - Consolidation survey: rigid-body rotation (explicitly labeled survey, paragraph depth, no derivation — $I$, $L=I\omega$, $K=\tfrac12I\omega^2$)
   - Consolidation survey: gravity and orbits (explicitly labeled survey; Kepler's 3 laws stated; circular-orbit speed derived in 3 lines as the one permitted exception)
4. Worked examples (3): elastic collision with numbers + equal-mass swap check; skater pulling arms in ($I\omega$ conservation + energy-source explanation); comet perihelion/aphelion via $L$ conservation.
5. Exercises (5, tiers labeled, opens with house line): Retrieval ×2, Standard ×2, Stretch ×1.
6. Hints (5, one per exercise, non-spoiling — name the tool/first move only).
7. Solutions (5, full sketches, numbers worked through).
8. Connection to QM (2 paragraphs: conserved quantities → operators commuting with $\hat H$, $L$ quantization; reduced-mass reduction → Day 14 hydrogen atom, with the required forward-flag sentence naming Day 14 explicitly).

No Simulation section (brief did not request one for Day 4; contract only requires it for sim days).

## Checklist results

1. Anatomy present, in order, correctly headed — pass (verified via grep on `## ` headers).
2. Every named equation derived or motivated — pass: momentum conservation (from N2+N3), inelastic $v_f$, elastic $v_{1f},v_{2f}$ (from momentum+KE difference-of-squares trick), COM-frame velocity reversal, $d\vec L/dt=\vec\tau$, central-force $\tau=0$, Kepler's 2nd ($dA/dt=|L|/2m$), circular-orbit $v(r)$ and $T(r)$ (3-line survey exception, explicitly flagged as such). Rigid-body $I$, $L=I\omega$, $K=\tfrac12I\omega^2$ are explicitly labeled survey-level (not derived) per brief's exception.
3. Exercise count 5 (within 4–6); tiers labeled; hints don't give away answers (checked — each hint names only the first move/tool); every exercise has matching hint + solution; solutions verified numerically (below).
4. Exercises solvable from Day 4 + prior days only — pass: exercises 1–2 use only today's derivations; 3 uses today's collision + energy tools; 4 uses today's central-force/circular-orbit tool + Day-1-level kinematics; 5 uses only today's N2/N3 + central-force setup, no forward references except the *explanatory* (not solving) paragraph about Day 14, which the brief explicitly requires.
5. Notation matches conventions — pass: $K$ used for kinetic energy (not $T$, since this isn't an analytical-mechanics day); $L$ used for angular momentum with no Lagrangian collision (Lagrangian doesn't appear until Day 9); $V(x)$ not needed here but no conflicting use; $v,x,a$ kinematic symbols; no $\mathcal L$.
6. ≥2 misconception callouts — pass, 2 present: "momentum and KE are interchangeable bookkeeping" (line ~101) and "angular momentum requires circular motion" (line ~174), each with a concrete counterexample.
7. Time budget stated and plausible — pass: "~3 hours" (matches days 1–4 guideline).
8. Sim day — N/A, no simulation required or included.

## Exercise-by-exercise verification (final answers, self-checked independently)

1. Two-body momentum conservation: $d(\vec p_1+\vec p_2)/dt = \vec F_{12}+\vec F_{21}=0$ by N3. Generalizes to $N$ particles via pairwise cancellation in the double sum. Correct.
2. $d\vec L/dt=\vec v\times\vec p+\vec r\times\vec F = 0+\vec\tau$ (first term zero since $\vec v\times\vec v=0$); central force gives $\vec\tau=\vec r\times f(r)\hat r=0$ since $\vec r\parallel\hat r$. Correct.
3. Ballistic pendulum: $v_f=\sqrt{2gh}=\sqrt{2(9.8)(0.05)}=0.9899\text{ m/s}$ (energy, swing phase only); $v_0=(M+m)v_f/m = 2.01(0.9899)/0.01 \approx 198.98\text{ m/s} \approx 199\text{ m/s}$ (momentum, collision phase only). Verified numerically with a script — matches exactly. Phases correctly flagged as using different conservation laws.
4. Circular orbit: $v=\sqrt{GM_E/r}$, $T=2\pi\sqrt{r^3/GM_E}$. Numerically verified with a script: $GM_E=3.984\times10^{14}$, $v\approx7545\text{ m/s}$ ($7.54$ km/s), $T\approx5830\text{ s}\approx97.2$ min — consistent with real LEO periods (~90–100 min). File corrected from an initial rounding pass (7550/5825/"97 min") to the more precise 7545/5830/"97.2 min" during self-review.
5. Reduced mass: $\mu\ddot{\vec r}=f(r)\hat r$ derived exactly (divide-and-subtract the two N2 equations); $1/\mu=1/m_1+1/m_2$. CM motion is separately free (ties back to theory beat 1). Forward-flag sentence included verbatim in spirit: "Day 14 will use exactly this reduction to turn the two-body proton–electron Coulomb problem into a one-body central-force problem with reduced mass $\mu$, which is what makes the hydrogen atom solvable as a single-particle Schrödinger equation..." — appears in both the Solutions (Exercise 5) and Connection to QM sections.

## Self-review findings

- Elastic-collision general formula $v_{1f}=\frac{(m_1-m_2)v_{1i}+2m_2v_{2i}}{m_1+m_2}$, $v_{2f}=\frac{(m_2-m_1)v_{2i}+2m_1v_{1i}}{m_1+m_2}$ re-derived independently from the momentum + KE equations (difference-of-squares trick) — confirmed correct.
- Equal-mass limit ($m_1=m_2$): formulas reduce to $v_{1f}=v_{2i}$, $v_{2f}=v_{1i}$ — exact swap. Confirmed in Worked Example 1.
- Heavy-target-at-rest limit ($m_2\gg m_1$, $v_{2i}=0$): formulas give $v_{1f}\to-v_{1i}$ (light projectile reflects) and $v_{2f}\to0$ (heavy target barely moves) — confirmed algebraically during self-review (this limit is not spelled out in the file text itself, only the equal-mass swap is; the brief's Worked Example 1 spec only explicitly asks for the equal-mass check, so the heavy-target limit was verified as a self-review sanity check per the task instructions but not added as extra file content, to avoid padding beyond the brief's spec).
- Worked Example 1 numbers double-checked: before/after momentum both $10$, before/after KE both $26$ J — exact.
- Worked Example 2 numbers double-checked: $\omega_2=8$ rad/s, $K_1=10$ J, $K_2=40$ J — exact.
- Worked Example 3 numbers double-checked: $v_a=0.4$ km/s — exact.
- Caught and fixed one rounding imprecision in Exercise 4's solution (orbit speed/period) during self-review, per the script above.

## Concerns

None outstanding. The file is self-contained, uses only Day 1–4 material for every exercise, hits the exact forward-flag content Day 14 needs, and stays within the 350–600 line budget (525 lines, now 539 after the fix pass below).

---

## Fix report (post-review pass)

All 10 requested fixes applied to `physics_fundamental/content/day04.md`. File is now 539 lines.

**IMPORTANT fixes**

1. **$a=v^2/r$ never derived; day-1 misattribution risk; gravitation not flagged as empirical.** Rewrote the "Consolidation survey: gravity and orbits" paragraph. It now reads (excerpt): *"For a body in uniform circular motion, the centripetal acceleration $a=v^2/r$ (directed inward) follows from one geometric fact: over a short time $\Delta t$ the velocity vector turns through the same small angle $\Delta\theta=v\Delta t/r$ that the position vector does, so $|\Delta v|=v\,\Delta\theta=v^2\Delta t/r$, giving $a=|\Delta v|/\Delta t=v^2/r$. Newton's law of gravitation, $F=GMm/r^2$ — which we take as given, an experimentally established force law — then supplies exactly this centripetal force for a circular orbit; balancing the two determines the orbital speed $v(r)$ and, from it, the period-radius relation... Exercise 4 below works through that algebra in full."* No attribution to Day 1 anywhere (confirmed via grep — the only two "Day 1" mentions are both about $\vec F=m\vec a$, not circular motion). Exercise 4's solution now opens: *"Using the survey's $a=v^2/r$ for uniform circular motion, the centripetal force required is $ma=mv^2/r$. Setting Newton's gravitational force equal to this: ..."* — citing the survey fact rather than re-introducing it unsourced.

2. **Hints 2 and 5 spoiled their exercises.** Hint 2 trimmed to exactly: *"Product rule on $\vec r\times\vec p$ — one of the two terms dies by a property of the cross product."* Hint 5 trimmed to exactly: *"Divide each body's equation of motion by its own mass, then subtract."*

**MINOR fixes**

3. L335 (now): *"kinetic energy exactly quadrupled ($K_2/K_1=4$)"* — replaces "nearly quadrupled."
4. Exercise 4 solution: $GM_E\approx3.984\times10^{14}$ (was $3.985\times10^{14}$) — now consistent with the value used two lines later.
5. Exercise 3 problem statement now states *"Take $g=9.8\text{ m/s}^2$."* before "Find $v_0$."
6. Exercise 3 solution's energy-loss citation repointed: *"energy is lost to deformation and heat, exactly as in the perfectly-inelastic-collision paragraph and the momentum/KE misconception callout in Theory"* — replaces the incorrect "per Worked Example material" (WE1 is elastic, not inelastic).
7. Added a closing clause to the COM-frame energy step: *"(This kinetic-energy step in the COM frame is legitimate because $K_{\text{lab}}=K_{\text{cm}}+\tfrac12(m_1+m_2)V_{\text{cm}}^2$, and $V_{\text{cm}}$ is constant through the collision, so conserving total kinetic energy in the lab frame is exactly equivalent to conserving the internal kinetic energy $K_{\text{cm}}$ in the COM frame — the bulk term $\tfrac12(m_1+m_2)V_{\text{cm}}^2$ cannot change either way.)"*
8. Rigid-body survey now reads: *"Momentum $p=mv$ is replaced by angular momentum $L=I\omega$ for rotation about a fixed axis (a general asymmetric body can have $\vec L$ not parallel to $\vec\omega$, but that subtlety doesn't arise for the fixed-axis case used here), and kinetic energy..."*
9. Worked Example 2 now reads: *"gravity (acting through her center of mass) and the normal force from the ice (acting at her blades) both have lines of action *parallel* to the vertical rotation axis, and a force parallel to a chosen axis produces zero torque about that axis regardless of where it's applied — so neither contributes any torque about the spin axis, and $L=I\omega$ is conserved"* — replaces the imprecise "act along the vertical rotation axis."
10. Orbits survey trimmed to state Kepler's laws and the $a=v^2/r$ motivation only (no full $v(r)$/$T(r)$ algebra); the full derivation now lives solely in Exercise 4's solution (see fix 1's excerpt above — same edit serves both).

## Re-verified checklist (post-fix)

1. Anatomy present, in order, correctly headed — pass (re-checked via grep on `## ` headers: Learning objectives, Reference material, Theory, Worked examples, Exercises, Hints, Solutions, Connection to QM, in that order).
2. Every named equation derived or motivated — pass, including the newly-added $a=v^2/r$ motivation and the explicit "taken as given" flag on Newton's gravitation.
3. Exercise count 5; tiers labeled; hints re-checked — Hints 2 and 5 now name only the first move, no spoilers; all 5 exercises still have matching hints and solutions (grep count: 5/5/5).
4. Exercises solvable from Day 4 + prior days only — pass, unchanged; Exercise 4 no longer relies on unexplained circular-motion tooling since the survey now motivates $a=v^2/r$ before the exercise uses it.
5. Notation matches conventions — pass, unchanged.
6. ≥2 misconception callouts — pass, still 2 (unchanged by this fix pass).
7. Time budget stated and plausible — pass, unchanged ("~3 hours").
8. Sim day — N/A, unchanged.

No git commands were run.
