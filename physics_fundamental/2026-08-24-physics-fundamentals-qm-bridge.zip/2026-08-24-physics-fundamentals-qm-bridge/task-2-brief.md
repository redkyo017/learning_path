### Task 2: Day 1 — Newton as Differential Equations

**Files:**
- Create: `content/day01.md`

**Interfaces:**
- Produces: the framing sentence "classical mechanics is: given $F(x,v,t)$, solve $m\ddot{x}=F$" — quoted back by days 5, 9, 16. Also the drag time-constant result $v(t)=v_{\mathrm{term}}(1-e^{-t/\tau})$, $\tau=m/b$, reused as the exponential-approach archetype in day 12.

- [ ] **Step 1: Draft `content/day01.md` (~3h day) with this content brief:**

*Learning objectives:* translate between kinematics language and ODE language; solve $m\ddot{x}=F$ for constant force, linear drag, and spring force (preview); use dimensional analysis to check any result; state all three Newton laws precisely and as ODE statements.

*Theory beats (in order):*
1. Kinematics as definitions, not laws: $v=\dot x$, $a=\dot v$; position/velocity/acceleration graphs read together.
2. Newton's three laws stated precisely; the second as the ODE $m\ddot{x}=F(x,\dot x,t)$ — "the rest of classical mechanics is choosing $F$ and solving." Box this framing.
3. Constant force: integrate twice → projectile motion as two independent ODEs; derive range formula.
4. Linear drag: solve $m\dot v = mg - bv$ by separation → terminal velocity $v_{\mathrm{term}}=mg/b$ and $v(t)=v_{\mathrm{term}}(1-e^{-t/\tau})$ with $\tau=m/b$; the exponential-approach picture.
5. Spring force preview: $m\ddot x = -k_s x$ stated, solution deferred to day 3 deliberately ("the most important ODE in physics gets its own day").
6. Dimensional analysis as a checking tool: worked micro-example (check the range formula's dimensions); the habit statement.
- Misconception callouts (≥2): "no force means no motion" (vs. no *acceleration*); "heavier objects fall faster" (drag vs. vacuum, tie to the drag section).

*Worked examples:* (1) projectile launched at angle θ — derive time of flight, range, maximize over θ; (2) raindrop with linear drag — compute $v_{\mathrm{term}}$ and $\tau$ for given m, b, sketch $v(t)$; (3) block on incline with kinetic friction — set up and solve the ODE for $v(t)$.

*Exercises:* Retrieval: (1) state the three laws as one sentence + one equation each; (2) dimensional-check a given (slightly wrong) formula and find the error. Standard: (3) two-stage motion: constant thrust then drag-only coast; (4) Atwood machine acceleration from $F=ma$ on each mass. Stretch: (5) quadratic drag $m\dot v = -cv^2$: solve by separation, contrast $1/t$ decay with the linear-drag exponential.

*Connection to QM:* Schrödinger's equation plays the exact role $F=ma$ plays here — the dynamical rule you solve given the setup; "given the potential, find the motion" survives into QM as "given the potential, find the allowed states."

- [ ] **Step 2: Run the per-day verification checklist** (Global Constraints) against the file; fix anything failing before done.

---

