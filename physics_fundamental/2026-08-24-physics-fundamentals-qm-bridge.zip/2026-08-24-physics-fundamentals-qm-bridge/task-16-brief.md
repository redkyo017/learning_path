### Task 16: Day 15 — Matter Waves and the Synthesis

**Files:**
- Create: `content/day15.md`

**Interfaces:**
- Consumes: day 6's standing-wave quantization sentence, day 7's packets, day 13's $E=hf$, day 14's Bohr levels + photon momentum.
- Produces: de Broglie $\lambda = h/p$; the synthesis sentence "quantization = boundary conditions on matter waves"; thermal de Broglie estimate. Day 16 opens from exactly here.

- [ ] **Step 1: Draft `content/day15.md` (~3.5h day) with this content brief:**

*Learning objectives:* state and use $\lambda = h/p$; describe Davisson–Germer and why it's decisive; re-derive Bohr's $L=n\hbar$ from a standing matter wave; estimate when quantum effects matter; articulate the synthesis in one's own words.

*Theory beats:*
1. de Broglie's symmetry bet: light — long thought a wave — carries particle attributes ($E=hf$, $p=h/\lambda$, days 13–14); perhaps matter — long thought particles — carries wave attributes with the SAME relations read backwards: $\lambda = h/p$, $f = E/h$.
2. Numbers immediately: electron at 100 eV → $\lambda \approx 0.12$ nm (atomic scale — measurable); thrown baseball → $\lambda \sim 10^{-34}$ m (hopeless — why nobody noticed).
3. Davisson–Germer: electrons off a nickel crystal show diffraction peaks at angles matching $\lambda = h/p$ — matter waves measured; electron two-slit interference (single electrons, fringes build up dot by dot) as the cleaner modern statement.
4. **The synthesis (centerpiece):** electron in a Bohr orbit as a wave that must close on itself: $2\pi r = n\lambda$ + $\lambda = h/p$ → $L = rp = n\hbar$ — Bohr's mystery postulate DERIVED from the standing-wave condition. Then the general chain, boxed: *particles are waves (de Broglie) → confined waves form discrete modes (day 6) → therefore confined particles have discrete energies. Quantization is boundary conditions applied to matter waves.*
5. Wave–particle straight talk: the electron is neither a classical wave nor a classical particle; it's described by a wavefunction whose mode structure gives energies and whose modulus gives probabilities (Born, formalized tomorrow); what "duality" does and doesn't mean, without mysticism.
6. When is quantum relevant: compare $\lambda_{\mathrm{dB}}$ to the system size; thermal de Broglie wavelength $\lambda_{th} = h/\sqrt{2\pi m k_BT}$ (motivated from $p \sim \sqrt{mk_BT}$, day 12) — evaluate for an electron and for a helium atom at room temperature.
- Misconceptions: "the electron travels along the wave" (the wave IS the electron's description, not its trail); "wave–particle duality means sometimes-wave-sometimes-particle" (one consistent object — a quantum state — with wave-like propagation and particle-like detection).

*Worked examples:* (1) electron vs. baseball $\lambda$ computed; (2) the Bohr-condition-from-standing-waves derivation in full; (3) Davisson–Germer: given crystal spacing, predict the diffraction angle for 54 eV electrons (the historical numbers).

*Exercises:* Retrieval: (1) state both de Broglie relations and compute $\lambda$ for a 1 keV electron; (2) reproduce the standing-wave → $L=n\hbar$ derivation closed book. Standard: (3) neutron diffraction: what kinetic energy gives $\lambda = 0.1$ nm? Compare to $k_BT$ at room temperature (thermal neutrons — flag the connection); (4) electron microscope resolution argument: why electrons beat light at the same "optics." Stretch: (5) particle confined to a 1D box of size $L$ treated by pure standing-wave reasoning: allowed $\lambda_n = 2L/n$ → $p_n = nh/2L$ → $E_n = n^2h^2/8mL^2$ — derive it TODAY from waves alone; tomorrow the Schrödinger equation reproduces it exactly (this exercise is deliberately day 16's headline result, obtained a day early with 1924-era tools).

*Connection to QM:* you now hold every ingredient of the course's day one: states are waves, observables from mode structure, probabilities from amplitudes, quantization from confinement. Tomorrow assembles them into THE equation.

- [ ] **Step 2: Run the per-day verification checklist**; fix failures.

---

