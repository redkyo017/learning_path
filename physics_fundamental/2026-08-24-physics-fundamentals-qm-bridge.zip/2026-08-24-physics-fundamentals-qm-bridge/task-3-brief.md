### Task 3: Day 2 — Energy and Potential Wells

**Files:**
- Create: `content/day02.md`

**Interfaces:**
- Consumes: day 1's $m\ddot x = F$ framing.
- Produces: the V(x)-diagram reading skills (turning points, stable/unstable equilibria, bound vs. free motion) that days 3, 10, 16 quote; the relation $F=-dV/dx$.

- [ ] **Step 1: Draft `content/day02.md` (~3h day) with this content brief:**

*Learning objectives:* derive the work–energy theorem from Newton; define conservative forces and construct $V(x)$; read any $V(x)$ diagram fluently (turning points, equilibria, bound vs. free); use energy conservation as a solving tool that skips the ODE.

*Theory beats:*
1. Work–energy theorem derived: $\int F\,dx = \Delta(\tfrac12 mv^2)$ via chain rule $\ddot x = v\,dv/dx$.
2. Conservative forces; $V(x) = -\int F\,dx$; $F = -dV/dx$; gravity and spring potentials derived.
3. Energy conservation $E = K + V$ derived from Newton (differentiate, show $\dot E = 0$ for conservative $F$).
4. **The core skill:** reading $V(x)$ diagrams. Given an arbitrary bumpy $V(x)$ figure (describe it precisely in words + a simple ASCII/described figure): turning points where $E=V$; allowed/forbidden regions; stable equilibrium at minima ($V''>0$), unstable at maxima; bound motion between two turning points vs. free (escaping) motion. Walk through one figure at three different energies.
5. Small-oscillation preview: near a minimum, motion is oscillatory (full treatment day 3).
6. Escape velocity as an energy argument.
- Misconceptions: "energy is a substance stored in objects" (it's bookkeeping of one conserved number); "a particle at a turning point has zero force" (zero *velocity*; force is $-dV/dx \ne 0$).

*Worked examples:* (1) double-well $V(x)$ described concretely (e.g., $V(x) = x^4 - 2x^2$): classify the motion at $E=-0.5, 0, +1$ — turning points, bound-or-free, which well; (2) pendulum by energy: speed at bottom given release angle, no ODE; (3) escape velocity from Earth derived and computed.

*Exercises:* Retrieval: (1) derive $F=-dV/dx$ from the definition of $V$; (2) for $V(x)=\tfrac12 k_s x^2$, find turning points at energy $E$. Standard: (3) given $V(x)=x^3-3x$ find equilibria, classify stability, sketch motion at two energies; (4) ball rolling off a hemisphere — where does it leave? (energy + circular-motion condition). Stretch: (5) period of oscillation between turning points as the integral $T = 2\int_{x_1}^{x_2} dx/\sqrt{2(E-V)/m}$ — derive the formula, evaluate for the spring to recover day 3's answer in advance.

*Connection to QM:* the potential well IS the stage of every QM problem; bound states ↔ discrete energies, scattering states ↔ continuum; "classically forbidden region" gets its meaning from today's turning points — QM particles leak into it (tunneling, day 17).

- [ ] **Step 2: Run the per-day verification checklist**; fix failures.

---

