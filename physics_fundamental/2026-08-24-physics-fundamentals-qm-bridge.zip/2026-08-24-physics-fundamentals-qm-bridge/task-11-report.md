# Task 11 report — Day 10: The Hamiltonian + sim

## Files produced

- `physics_fundamental/content/day10.md` — 543 lines
- `physics_fundamental/code/day10_phase_space.py` — 87 lines

## Structure

Followed the day-file contract anatomy exactly, in order: title, Learning
objectives (time budget ~3.5h), Reference material (Taylor/Goldstein +
self-contained note + Day 9/2/3 pointers), Theory (10 `###` subsections),
Worked examples (3), Simulation, Exercises (5, three bold tiers: Retrieval
2 / Standard 2 / Stretch 1), Hints (5), Solutions (5), Connection to QM.

Theory beats, in the brief's order: motivation for trading $(q,\dot q)$ for
$(q,p)$ → Legendre transform geometric picture (tangent-line encoding of a
convex function) → recipe + one fully-worked scalar example
($f(v)=\tfrac12mv^2\to g(p)=p^2/2m$) *before* any mechanics → building
$H(q,p)$ from $L$ → Hamilton's equations derived from $dH$ (two ways of
writing $dH$, matched term by term, closed with Day 9's Euler–Lagrange
equation) → SHM check → when $H=T+V$ (Euler's-theorem argument for natural
systems + rotating-frame caution) → phase space as flow + determinism →
oscillator ellipses + full pendulum portrait (fixed points, libration,
rotation, separatrix, infinite-period meaning) → Liouville's theorem
derived from zero divergence of the Hamiltonian vector field (one
paragraph, ties to Day 12).

Notation: `L`/`T` override stated explicitly at the top of Theory
(Lagrangian / kinetic energy, days 9–11 only); pendulum length written
$\ell$ specifically to avoid colliding with the Lagrangian $L$; spring
constant $k_s$ throughout; no `\mathcal{L}` anywhere (grepped, zero hits).

## Checklist results

1. Anatomy present, in order, correctly headed — pass.
2. Every named equation derived/motivated (Legendre transform, both
   Hamilton's equations, natural-system $H=T+V$ condition, Liouville
   zero-divergence, every worked-example and solution formula) — pass.
3. Exercise count 5 (within 4–6); tiers bold-labeled (Retrieval/Standard/
   Stretch — fixed a miss where exercise 5 was inline-tagged `**(Stretch)**`
   instead of having its own tier header; added a proper `**Stretch**`
   header); hints don't spoil (name the first move only); every exercise
   has a matching hint and solution; solutions solve the stated problems —
   pass.
4. Exercises use only Day 10 + Day 2/3/9 material — pass, no forward refs.
5. Notation matches conventions block — pass.
6. Misconception callouts: 2 ("$H$ is always the energy"; "phase-space
   trajectories can cross") — meets the ≥2 minimum.
7. Time budget "~3.5 hours" stated, correct for a day-10 file (5–15 range)
   — pass.
8. Sim exists, runs clean, `## Simulation` section present with 3
   predict-before-run prompts (brief's exact three) — pass.

## Exercise self-verification (final answers)

1. Hamilton's equations rederived from two expressions for $dH$: matching
   coefficients gives $\partial H/\partial p=\dot q$ directly, and
   $\partial H/\partial q=-\partial L/\partial q=-\dot p$ via Day 9's
   Euler–Lagrange equation.
2. $H=p^2/2m+\tfrac12k_sx^2\Rightarrow\ddot x=-\omega_0^2x$,
   $\omega_0=\sqrt{k_s/m}$ — SHM reproduced.
3. Bead on $y=ax^2$: $H=\dfrac{p^2}{2m(1+4a^2x^2)}+mgax^2$ — position-
   dependent effective mass $m_{\rm eff}(x)=m(1+4a^2x^2)$, still $T+V$
   (time-independent constraint, natural system).
4. $V=x^4-2x^2$: centers at $(\pm1,0)$, saddle at $(0,0)$; $E<0$ → two
   separate loops (one per well); $E=0$ → figure-eight separatrix through
   the saddle; $E>0$ → single loop encircling both wells.
5. Relativistic: $p=m\gamma\dot x$; inverted $\dot x=pc/\sqrt{m^2c^2+p^2}$;
   algebra closes exactly to $H=\sqrt{p^2c^2+m^2c^4}$ (verified by direct
   substitution, no approximation used).

Cross-checks specifically requested: pendulum separatrix
$E_{\rm sep}=mg\ell(1-\cos\pi)=2mg\ell$, consistent with the file's
$V(\theta)=mg\ell(1-\cos\theta)$ convention (bottom = 0). Legendre scalar
example checked in both directions (forward: $p=mv$; back-substitution
reproduces $g(p)=p^2/2m$ exactly). SHM recovery re-derived independently in
both Theory and Worked Example 1 (matches). Bead effective-mass term
confirmed by direct algebra. Relativistic Legendre algebra reproduced twice
independently (symbolic here and in-file) with identical result.

## Sim run

```
MPLBACKEND=Agg python3 code/day10_phase_space.py
```
via a Homebrew-Python 3.14 venv (numpy 2.5.2, matplotlib 3.11.1) built in
the scratchpad — no repo files touched, system `python3` untouched. Exit
code 0. Only output: the expected benign
`UserWarning: FigureCanvasAgg is non-interactive, and thus cannot be shown`.
Panel (a) streamplot + 4 analytic ellipses; panel (b) contour plot with a
distinctly colored/widened separatrix (red, lw=2.8) separating green
libration ovals from orange rotation bands, with center/saddle markers and
a legend. No trajectory-crossing artifacts (each panel uses disjoint level
sets / a single vector field, so curves cannot cross by construction).

## Concerns

None blocking. Minor judgment calls, noted for transparency:
- Kept the "check on the oscillator" derivation short in Theory (a few
  lines) and did the full from-scratch Legendre construction + explicit
  $q(t)$ solution in Worked Example 1, to avoid duplicating the same
  algebra twice at length — the brief's beat 3 checkbox and Worked Example
  1 both explicitly ask for this recovery, so I treated the theory version
  as the "check" and the worked example as the "full construction."
- Did not add a `## Journal template` section — cross-checked
  `physics_fundamental`'s own day02.md and day08.md (neither has one; that
  section only appears in the quantum-computing-foundations exemplar path)
  and the day-file contract's anatomy list also omits it, so day10 matches
  this course's own established convention instead.

## Fix report (post-review)

Files after fixes: `content/day10.md` — 558 lines; `code/day10_phase_space.py` — 93 lines. Both still within budget (350–600 / ≤150).

### Must-fix

1. **TWEAK 1 false claim.** Fixed the docstring: "multiply K_S by 4 ... the
   ellipses get narrower at the same height (the p semi-axis
   sqrt(2*m*E) doesn't depend on k_s at all; only the q semi-axis
   sqrt(2*E/k_s) shrinks)."
2. **Hardcoded pendulum levels/PMAX_PEND vs. scaling E_SEP.**
   `LIBRATION_ENERGIES` is now `[0.2, 0.5, 0.8] * E_SEP`,
   `ROTATION_ENERGIES` is now `[1.2, 1.6, 2.0] * E_SEP`, and `PMAX_PEND` is
   computed as `1.5 * sqrt(2*M_PEND*L_PEND**2*E_SEP)` — all defined in
   terms of `E_SEP`, so doubling `L_PEND` rescales the plot window and
   every level together. (Used 1.5, not the example 1.4: I checked
   numerically that the top rotation level, `2.0*E_SEP` at `theta=0`, needs
   `p_theta = sqrt(2*m*l^2*2*E_sep) = sqrt(2)*sqrt(2*m*l^2*E_sep) ≈
   1.4142*...` — the example 1.4 was ~1% too small and would have clipped
   the tip of the top rotation contour at `theta=0`; 1.5 gives comfortable
   margin at both `L_PEND=1.0` and `L_PEND=2.0`, verified numerically
   below.) Added a comment explaining why the levels are relative.
3. **day10.md `## Simulation`**: added a sentence — "The red curve appears
   to cross itself in an 'X' at each $\theta=\pm\pi$ — that crossing is
   only apparent: those are two branches asymptotically approaching the
   unstable equilibrium from opposite sides, never actually reaching it
   ..., which is consistent with the no-crossing misconception callout,
   not an exception to it."

### Minor

4. Set `K_S = 4.0` (`M` stays `1.0`) so the q- and p- semi-axes visibly
   differ at default energies — panel (a) now shows genuine ellipses, not
   circles.
5. Defined $\gamma$ at first use in Solution 5:
   "$= m\gamma\dot x,\ \gamma\equiv 1/\sqrt{1-\dot x^2/c^2}$."
6. Fixed the gravity-flow sentence: parabolas are "shifted along $x$ —
   horizontally in this $(x,p)$ plane, since $p$ is the vertical axis and
   $x$ the horizontal one — by its own conserved $H$-value" (was
   "shifted vertically").
7. Added the missing quantitative argument to Worked Example 2: linearizing
   $\ddot\theta=-(g/\ell)\sin\theta$ near the top ($\varphi\equiv\pi-\theta$
   small) gives $\ddot\varphi=(g/\ell)\varphi$ (positive coefficient, unlike
   the stable bottom), whose decaying solution
   $\varphi(t)=\varphi_0e^{-\sqrt{g/\ell}\,t}$ reaches $\varphi=0$ only as
   $t\to\infty$ — the exponential-approach argument the Theory section's
   "worked out quantitatively in Worked Example 2" now actually points to.
8. Trimmed Hint 1 to "Write $dH$ two ways and compare coefficients of $dq$
   and $dp$."

### Deferred (per controller instruction, not done)

Convexity one-liner; legend entries for center/saddle markers; marker
clipping at $\theta=\pm2\pi$.

### Sim re-run output

Default (`L_PEND=1.0`, in-repo file), via the same scratchpad Homebrew venv
(numpy 2.5.2 / matplotlib 3.11.1), `MPLBACKEND=Agg`:
```
code/day10_phase_space.py:93: UserWarning: FigureCanvasAgg is non-interactive, and thus cannot be shown
  plt.show()
EXIT_CODE=0
```

Doubled-$\ell$ check (`L_PEND=2.0`, scratch copy of the exact in-repo
script, edited only on that one line, run the same way):
```
day10_doubled_L.py:93: UserWarning: FigureCanvasAgg is non-interactive, and thus cannot be shown
  plt.show()
EXIT_CODE=0
```
Both exits 0, only the expected benign Agg warning. Numeric check (not
just visual) that nothing clips, run in the same venv:
```
L_PEND=1.0: E_SEP=19.60, PMAX_PEND=9.39, p_theta needed for top rotation level at theta=0 = 8.85, fits=True
L_PEND=2.0: E_SEP=39.20, PMAX_PEND=26.56, p_theta needed for top rotation level at theta=0 = 25.04, fits=True
```
confirming the highest rotation contour (`2.0*E_SEP`, the widest curve at
`theta=0`) stays inside the plotted `p_theta` window at both lengths, so
the separatrix and every level contour render uncut and truthfully labeled
in both cases.
