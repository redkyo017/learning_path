### Task 18: Day 17 — Quantum Oscillator, Tunneling, Uncertainty + sim

**Files:**
- Create: `content/day17.md`
- Create: `code/day17_packet_evolution.py`

**Interfaces:**
- Consumes: day 3's classical oscillator, day 7's bandwidth theorem and packet spreading, day 16's TISE and box.
- Produces: QHO ladder $E_n = \hbar\omega_0(n+\tfrac12)$; $\Delta x\,\Delta p \ge \hbar/2$; Gaussian free-packet spreading law $\Delta x(t) = \Delta x_0\sqrt{1 + (\hbar t/2m\Delta x_0^2)^2}$ (stated). Day 18 consumes the QHO ladder (photons) and uncertainty.

- [ ] **Step 1: Draft `content/day17.md` (~4h day) with this content brief:**

*Learning objectives:* state the QHO spectrum and ground state and explain (not re-derive) their structure; compute zero-point energies; explain tunneling via evanescent waves; convert day 7's bandwidth theorem into Heisenberg's relation and use it for estimates; describe Gaussian packet spreading quantitatively.

*Theory beats:*
1. QHO setup: $V = \tfrac12 m\omega_0^2 x^2$ into the TISE; solution *structure* presented, not the Hermite grind (say so): $E_n = \hbar\omega_0(n+\tfrac12)$, evenly spaced; ground state is a Gaussian $\phi_0 \propto e^{-m\omega_0 x^2/2\hbar}$ — VERIFY it satisfies the TISE by direct differentiation (that much is honest work, done fully); first excited state shown, node count rule carried over from day 16.
2. Why even spacing is the headline: a quantized field mode is an oscillator (day 13), so its levels $n\hbar\omega$ are *countable energy lumps* — photons; "add one photon" = "climb one rung"; ladder-operator names dropped as vocabulary for the course ($a, a^\dagger$, "creation/annihilation"), algebra deferred to the course.
3. Zero-point energy $\tfrac12\hbar\omega_0$: why the uncertainty principle forbids a resting particle at the bottom (the estimate: minimize $\langle E\rangle \sim \frac{\hbar^2}{2m(\Delta x)^2} + \tfrac12 m\omega_0^2(\Delta x)^2$ — done fully, lands within a factor of the exact answer); physical reality: molecular vibrations at $T\to0$, liquid helium never freezing at ambient pressure (one sentence each).
4. Tunneling qualitatively: in the classically forbidden region ($E < V$, day 2's language) the TISE gives decaying exponentials $e^{-\kappa x}$, $\kappa = \sqrt{2m(V-E)}/\hbar$, not oscillation; a thin barrier lets the tail through — transmission $\sim e^{-2\kappa d}$ (stated, with the analogy: frustrated total internal reflection — evanescent light waves jumping a gap, day 8's wave optics); consequences named: alpha decay, tunnel diodes, scanning tunneling microscope.
5. Heisenberg for real: $\Delta x\,\Delta k \ge \tfrac12$ (day 7, Gaussian equality) times $\hbar$: $\Delta x\,\Delta p \ge \hbar/2$; what it does and doesn't say (statistical spreads over repeated preparations, not measurement clumsiness — one careful paragraph); estimates it powers: hydrogen's size (minimize energy with $\Delta x$), why electrons can't live inside nuclei.
6. Free Gaussian packet: spreading law stated (formula above), with the physical reading — narrower start spreads faster (day 7's dispersion + big $\Delta k$); Ehrenfest teaser one paragraph: $\langle x\rangle$ obeys Newton, quantum corrections ride on the spread.
- Misconceptions: "zero-point motion is thermal jiggling that better cooling removes" (it survives $T=0$; it's structural); "tunneling particles briefly violate energy conservation" (energy is conserved; the forbidden region has amplitude, not a classical trajectory).

*Worked examples:* (1) verify the Gaussian ground state solves the QHO TISE and read off $E_0 = \tfrac12\hbar\omega_0$; (2) CO molecule vibration: given $\omega_0$ from spectroscopy, compute zero-point energy, compare with $k_BT$ at room temperature (vibrations frozen — day 12 exercise 4 closed); (3) uncertainty estimate of hydrogen's ground-state size and energy — land within a factor of 2 of Bohr's $-13.6$ eV.

*Simulation section:* run `python3 code/day17_packet_evolution.py`; predict-prompts: "halve the initial width — does it spread faster or slower?", "increase the mass tenfold — what happens to the spreading time?", "at what time has the width doubled? Predict from the formula, then measure on the plot."

*Exercises:* Retrieval: (1) state the QHO spectrum and sketch the two lowest $|\phi_n|^2$ (describe nodes and symmetry); (2) reproduce the zero-point uncertainty estimate for the QHO closed book. Standard: (3) electron trapped to $\Delta x = 0.1$ nm: minimum momentum spread and kinetic-energy scale in eV; (4) tunneling scaling: for an electron and a 1 eV, 0.5 nm barrier compute $\kappa$ and $e^{-2\kappa d}$; repeat for a proton — why chemistry has electron transfer but not proton teleportation. Stretch: (5) a thrown 0.1 kg ball localized to $\Delta x_0 = 1$ mm: compute the doubling time of its wave packet and compare to the age of the universe — write three sentences on why classical mechanics is safe.

*Connection to QM:* the QHO is the most-used system in your course (field modes, trapped ions, cavity photons); "n photons in a mode" now has exact meaning; and Heisenberg's relation arrived not as an axiom but as day 7's wave mathematics wearing $p = \hbar k$ — which is how your course will actually derive it too (Fourier + commutators).

- [ ] **Step 2: Write `code/day17_packet_evolution.py`** per Global Constraints. Two panels: (a) free Gaussian $|\psi(x,t)|^2$ snapshots at 4 times using the analytic complex-Gaussian evolution (code the closed-form $\psi(x,t)$ with complex numpy directly — no PDE solver), with $\Delta x(t)$ annotated per snapshot; (b) $\Delta x(t)$ curve vs. the stated formula for two initial widths, showing narrower-spreads-faster.

- [ ] **Step 3: Run `python3 code/day17_packet_evolution.py`** — expect clean run; both panels; narrower initial packet visibly overtakes the wider one's width.

- [ ] **Step 4: Run the per-day verification checklist**; fix failures.

---

