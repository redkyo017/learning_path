### Task 10: Day 9 — Action and the Lagrangian

**Files:**
- Create: `content/day09.md`

**Interfaces:**
- Consumes: day 1's ODE framing, day 3's oscillator, day 4's Noether-informal.
- Produces: Euler–Lagrange equation $\frac{d}{dt}\frac{\partial L}{\partial\dot q} = \frac{\partial L}{\partial q}$ with $L = T - V$; generalized-coordinate methodology. Day 10 consumes $p = \partial L/\partial\dot q$.

- [ ] **Step 1: Draft `content/day09.md` (~3.5h day) with this content brief:**

*Learning objectives:* state the principle of least action; derive Euler–Lagrange from stationarity (once, carefully); apply it to free particle, oscillator, pendulum; exploit generalized coordinates on a constrained system; connect symmetry of $L$ to conservation (Noether made semi-precise).

*Theory beats:*
1. Why reformulate: forces are clumsy with constraints; a scalar ($L$) beats vectors; and this road leads to QM. State $T$ = kinetic energy for days 9–11, tension/periods renamed accordingly (notation flag per Global Constraints).
2. The action $S[q] = \int_{t_1}^{t_2} L(q,\dot q)\,dt$ as a number assigned to each *path*; "nature picks the path making $S$ stationary."
3. Euler–Lagrange derived via the standard variation $q\to q+\epsilon\eta$, integration by parts, endpoints fixed — done slowly, every step shown; this is the day's one hard derivation.
4. $L = T - V$ justified by recovering Newton: E–L on $L = \tfrac12 m\dot x^2 - V(x)$ gives $m\ddot x = -dV/dx$. (State honestly: $T-V$ is justified by its consequences.)
5. Three applications in increasing slickness: free particle (straight line), harmonic oscillator (recover day 3), pendulum in $\theta$ — the exact equation $\ddot\theta = -(g/l)\sin\theta$ with zero force-decomposition.
6. Generalized coordinates: bead on a rotating/shaped wire or block-on-movable-incline — pick ONE and do it fully; the moral "choose coordinates that make constraints invisible."
7. Noether semi-precise: if $L$ doesn't depend on $q$ ($q$ cyclic), then $\partial L/\partial\dot q$ is conserved — prove in two lines from E–L; connect back to day 4's dictionary.
- Misconceptions: "nature minimizes the action" (stationary, not always minimal); "the Lagrangian is the energy" ($T-V$, not $T+V$ — and the difference is the whole point of day 10's Legendre transform).

*Worked examples:* (1) pendulum via E–L start to finish; (2) Atwood machine via one generalized coordinate; (3) block sliding on a frictionless movable wedge (two coordinates, the classic).

*Exercises:* Retrieval: (1) derive E–L closed book (the day's core retrieval act); (2) show a cyclic coordinate's conjugate momentum is conserved. Standard: (3) bead on a vertical circular hoop rotating about its diameter at $\Omega$: find the E–L equation and equilibrium angles; (4) projectile via E–L in $x, y$ simultaneously. Stretch: (5) write the double-pendulum Lagrangian (set up only, no solving) and count how much force-based bookkeeping this avoided.

*Connection to QM:* Feynman's path-integral formulation says the quantum particle takes ALL paths, each weighted by $e^{iS/\hbar}$; classical mechanics is the stationary-phase limit. Even before path integrals, tomorrow's Hamiltonian — the object your entire course revolves around — is built directly from today's $L$.

- [ ] **Step 2: Run the per-day verification checklist**; fix failures.

---

