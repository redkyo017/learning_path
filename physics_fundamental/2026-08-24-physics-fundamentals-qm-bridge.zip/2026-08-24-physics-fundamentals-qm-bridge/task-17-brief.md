### Task 17: Day 16 — The Schrödinger Equation + sim

**Files:**
- Create: `content/day16.md`
- Create: `code/day16_box_eigenstates.py`

**Interfaces:**
- Consumes: day 15's de Broglie relations and box exercise; day 10's $H = p^2/2m + V$; day 6's boundary-condition quantization; day 5's dispersion-relation concept.
- Produces: TDSE and TISE; Born rule + normalization; box results $E_n = n^2\pi^2\hbar^2/2mL^2$, $\psi_n = \sqrt{2/L}\sin(n\pi x/L)$; orthogonality. Days 17–18 consume all of it.

- [ ] **Step 1: Draft `content/day16.md` (~4h day) with this content brief:**

*Learning objectives:* motivate the TDSE from plane waves + $E = p^2/2m + V$; state the Born rule and normalize wavefunctions; separate variables to the TISE; solve the particle in a box completely; verify orthogonality of eigenstates; connect box modes to day 6's standing waves.

*Theory beats:*
1. The construction (honest about its status — a motivation, not a derivation; validated by experiment): free matter wave $\psi = e^{i(kx-\omega t)}$ with $p=\hbar k$, $E=\hbar\omega$. Notice: $-i\hbar\,\partial_x\psi = p\psi$ and $i\hbar\,\partial_t\psi = E\psi$. Demand $E = \frac{p^2}{2m} + V$ hold as an operator statement → $i\hbar\,\partial_t\psi = -\frac{\hbar^2}{2m}\partial_x^2\psi + V\psi$. Flag: first-order in time (unlike day 5's wave equation), complex-valued *necessarily*; the dispersion relation $\omega = \hbar k^2/2m$ is day 7 exercise 3's — matter waves disperse, packets spread.
2. What $\psi$ means: Born rule $|\psi(x)|^2 dx$ = probability; normalization $\int|\psi|^2dx = 1$; why complex $\psi$ still yields real predictions; global phase is unobservable (day 8 exercise 5 recalled).
3. Stationary states: separation $\psi(x,t) = \phi(x)e^{-iEt/\hbar}$ → TISE $\hat H\phi = E\phi$ with $\hat H = -\frac{\hbar^2}{2m}\partial_x^2 + V(x)$ — day 10's Hamiltonian with hats, stated in exactly those words; stationary means $|\psi|^2$ time-independent, not "nothing happens."
4. **Particle in a box, fully:** infinite well $V=0$ inside $[0,L]$; boundary conditions $\phi(0)=\phi(L)=0$ (day 6's fixed string verbatim) → $\phi_n = \sqrt{2/L}\sin(n\pi x/L)$, $E_n = \frac{n^2\pi^2\hbar^2}{2mL^2}$; normalization computed; match to day 15's stretch exercise triumphantly (same numbers, real theory now); zero-point energy ($n=0$ forbidden — and why: it would be $\phi\equiv0$); nodes count $n-1$.
5. Orthogonality $\int\phi_n\phi_m dx = \delta_{nm}$ verified by the integral (day 7's mode-basis inner product recalled); expansion of an arbitrary state in eigenstates = Fourier series = "the basis expansion from your linear algebra path, now with physical meaning: $|c_n|^2$ is the probability of measuring $E_n$."
6. Superposition dynamics preview: two-state superposition $\propto \phi_1 e^{-iE_1t/\hbar} + \phi_2 e^{-iE_2t/\hbar}$ → $|\psi|^2$ oscillates at $(E_2-E_1)/\hbar$ — day 6's beats, now in probability; one paragraph, sim shows it.
- Misconceptions: "$\psi$ is a physical wave in space like a water wave" (it's a probability amplitude; for 2 particles it lives in 6 dimensions — one sentence); "the particle in a stationary state is at rest" ($\langle p\rangle = 0$ but $\langle p^2\rangle \ne 0$; kinetic energy is real).

*Worked examples:* (1) electron in a 1 nm box: $E_1, E_2$ in eV and the $2\to1$ photon's wavelength; (2) normalize $\phi_n$ from scratch; (3) ground state: probability of finding the particle in the middle third (integral computed).

*Simulation section:* run `python3 code/day16_box_eigenstates.py`; predict-prompts: "double the box width — each $E_n$ changes by what factor?", "which $\phi_n$ has a node exactly at the center?", "in the superposition panel, predict the sloshing period from $E_2 - E_1$ before reading it off."

*Exercises:* Retrieval: (1) reconstruct the TDSE motivation from the plane wave closed book; (2) solve the box from boundary conditions closed book (the single most course-relevant retrieval act in the path). Standard: (3) proton vs. electron in the same box: level-spacing ratio, and why nuclei need MeV where atoms need eV; (4) verify $\phi_1 \perp \phi_2$ by explicit integration. Stretch: (5) box with one wall suddenly moved from $L$ to $2L$ (state frozen): expand the old ground state in the new basis — set up the $c_n$ integrals, compute $c_1$ numerically, interpret $|c_1|^2 < 1$.

*Connection to QM:* this is the course's first two weeks, pre-lived: TISE as eigenvalue problem (your linear-algebra spectral theorem, infinite-dimensional), measurement postulate via $|c_n|^2$, and the box as the toy model everything else perturbs. The photonics tie: a cavity's photon modes obey the same boundary-condition mathematics — day 6, day 13, and today are one story.

- [ ] **Step 2: Write `code/day16_box_eigenstates.py`** per Global Constraints. Two panels: (a) first 5 box eigenfunctions $\phi_n$ offset vertically at heights proportional to $E_n$ inside a drawn well, with the energy ladder marked on the axis (the standard textbook figure, plus $|\phi_n|^2$ as a lighter overlay); (b) two-state superposition $|\psi(x,t)|^2$ at 5 equally spaced times across half a sloshing period, showing probability sloshing left↔right (analytic evaluation — no integrator).

- [ ] **Step 3: Run `python3 code/day16_box_eigenstates.py`** — expect clean run; $E_n$ spacing grows quadratically; sloshing visible.

- [ ] **Step 4: Run the per-day verification checklist**; fix failures.

---

